# 管理、审批与正式更新：脱敏证据胶囊候选

本目录仅为待主代理审阅的发布准备，尚未写入 docs、Git 或对外发布。后续 App2 批尚未正式交付，其独立源码/前端检查与待执行更新不并入本559胶囊。

- 源码559：审批未知选项不猜批准/拒绝，管理写入结果及原目标核查保留，三写动作共享已核家族保护，恢复未发送请求首次poll前复核已收到状态。
- Mac最终完整七项均自然0：714文件9563前端项，Rust2364/0/7；2384声明输入前后/Git blobs及模式独核；原声明遗漏11个测试fixture（test-fixtures10/testdata1），后续跨批独审已补核559Git/当前bytes+mode与旧tracked状态；原11项before/after未捕获，不把后补核验冒称旧run端点或全部transitive输入。首轮2354/1/7、自然101原失败保留，窄回归不替代最终七项，也不称初失败唯一定因。
- Mac559正式更新已完成：候选机械9/9、五文件新inode分别原子替换0、安装机械6/6、三份关闭态清单各206275条且同字节。机械9/6不是9或6名独立读者。候选压缩包留在私有证据中，生成.app已移除；本包不含应用/数据库/完整用户清单。
- 启动后原稿、附件、意见保持，但两条所选恢复失败：一次initialize60秒无回复，另一次initialize成功后session/load收到5更新、120秒无最终回复。安全tap没有对象ID，按具体标签映射须用Root操作时间；未算历史读取成功，也未定账号/环境/新保护根因。关闭态清单相等不扩展到启动后。
- Windows41980895597固定559真实30原生（5+7+16+2）及前端2文件20项/类型检查通过；是所选共用路径，不是当前完整Windows、安装界面或真实Agent验收。
- Windows41980992954在PowerShell解析即自然1，helper/NSIS/安装未执行；最小一文件三处重命名提交5b9。41984263036随后被GitHub付款或额度条件挡在runner之前（runner0、steps空）；修复实际解析、安装卸载与进程保护仍未验证。用户选择先推进其他工作，不自动重派。

`summary.json`按来源区分事实、独审和未测范围；`progress-update-suggestions.json`只建议更新现有状态/计划/要求进度，不动151原题/条件、不另排队。29家×八项、NEW-24及既有后置范围保持。

`text/raw`保留允许清单中必要原始UTF-8 JSON/补丁；其中两份.stdout来源已实际解析为JSON，未把ZIP/二进制伪装成文字。CI原始压缩包不复制，只取9个已核JSON成员；远端二进制仅保存记录的hash，不含exe/dll/helper。失败摘录明确原日志hash、行号及去ANSI转换。content-free协议日志只含固定枚举/时间/字节数，无事件正文、stderr内容、env、完整Agent argv或秘密。

完整206275清单、SQLite/metadata备份、图片/UI树、草稿正文、用户附件名和账号材料均未复制；私有完整独审以原路径/SHA引用，公包不假称包含它们。严格UTF-8/NUL/秘密模式及用户内容边界的核查记录见`safety-review.json`，精确文本清单见`text-allowlist.json`。补充closure真实引用为`engineering-navigation/independent-engineering-review.json`（SHA256 `2ab39f0607b6facb3d0da11e64b742d38fbce293b4a5c94adf06cfa49b6c768c`）；它来自后续755批，仅引用Rust输入闭合及普通Cargo不读dist的范围纠偏，不并入该批源码/前端或交付结果。`capsule.zip`只含这些批准文本，`manifest.json`给出逐项SHA/CRC与ZIP摘要。
