from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
base=Path(__file__).resolve().parent/'downloads'
name,endpoint=sys.argv[1:]
assert '/' not in name and name not in ('','.','..')
command=['gh','api','--method','GET',endpoint]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
out=base/name;err=base/(name+'.stderr.log');receipt=base/(name+'.download.json')
with out.open('xb') as stdout,err.open('xb') as stderr:
 result=subprocess.run(command,stdout=stdout,stderr=stderr)
for path in [out,err]:path.chmod(0o600)
data={'command':command,'startedAtUtc':started,'finishedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'naturalExitCode':result.returncode,'elapsedSeconds':time.monotonic()-t,'output':{'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},'stderr':{'path':str(err),'bytes':err.stat().st_size,'sha256':hashlib.sha256(err.read_bytes()).hexdigest()}}
with receipt.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
receipt.chmod(0o600)
print(json.dumps({'name':name,'naturalExitCode':result.returncode,'bytes':out.stat().st_size,'elapsedSeconds':data['elapsedSeconds']}))
