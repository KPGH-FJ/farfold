from pathlib import Path
import datetime,fnmatch,hashlib,json,re,subprocess,zipfile
BASE=Path(__file__).resolve().parent
ART=BASE/'artifact';RAW=BASE/'downloads'
HEAD='fc1c297a1e191fa58b3b563874cf7bd8e6d446ba'
EXPECTED=['worktrees::remove_boundary_tests::removal_identity_recovered_repository_rejects_replaced_parent','worktrees::remove_boundary_tests::remove_cancelled_retirement_keeps_maintenance_until_worker_returns']
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def same(a,b):return a.lower()==b.lower()
checks=[]
def check(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
run=load(RAW/'run.json');jobs=load(RAW/'jobs.json')['jobs'];artifact_meta=load(RAW/'artifacts.json')['artifacts'];selection=load(ART/'build-selection.json');build=load(ART/'selected-build.result.json');phase=load(ART/'resume-BoundaryWaits.result.json');group=load(ART/'removal-boundary-waits.json');watch=load(BASE/'watch-result.json')
check('fixed run source and completed natural service success',run['head_sha']==HEAD and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1)
check('one expected selected job succeeded',len(jobs)==1 and jobs[0]['head_sha']==HEAD and jobs[0]['name']=='selected' and jobs[0]['status']=='completed' and jobs[0]['conclusion']=='success')
check('watch completed naturally and raw hashes match',watch['expectedHead']==HEAD and watch['watchExitCode']==0 and same(watch['watchLogSha256'],sha(BASE/'watch.log')) and same(watch['watchStderrSha256'],sha(BASE/'watch.stderr.log')))
check('single expected downloadable artifact',len(artifact_meta)==1 and artifact_meta[0]['name']=='farfold-windows-launch-prerequisites-41869099411-1' and not artifact_meta[0]['expired'])
check('artifact ZIP matches provider digest',same(sha(RAW/'artifact.zip'),artifact_meta[0]['digest'].split(':',1)[1]))
with zipfile.ZipFile(RAW/'artifact.zip') as z:
 check('artifact member bytes preserved and CRC valid',z.testzip() is None and all((ART/n).read_bytes()==z.read(n) for n in z.namelist()))
 check('executables absent from uploaded artifact',not any(n.lower().endswith(('.exe','.dll','.pdb')) for n in z.namelist()))
for name in ['run.json','jobs.json','artifacts.json','artifact.zip','job.log']:
 r=load(RAW/(name+'.download.json'));check('actual download natural0 and raw hash '+name,r['naturalExitCode']==0 and same(r['output']['sha256'],sha(RAW/name)) and same(r['stderr']['sha256'],sha(RAW/(name+'.stderr.log'))))
before=load(ART/'inputs-before.json');after=load(ART/'inputs-after.json');check('before and after source maps equal',before==after)
tree={}
for entry in filter(None,subprocess.check_output(['git','ls-tree','-r','-z',HEAD]).split(b'\0')):
 meta,path=entry.split(b'\t',1);mode,kind,oid=meta.split();tree[path.decode()]=(mode.decode(),kind.decode(),oid.decode())
def selected(name):
 return any(name.startswith(p+'/') for p in ['src-tauri/src','src-tauri/native','src-tauri/examples','.github/scripts']) or name in ['src-tauri/Cargo.toml','src-tauri/Cargo.lock','src-tauri/build.rs','.github/workflows/windows-launch-prerequisites.yml'] or (name.startswith('src-tauri/') and name.count('/')==1 and (name.endswith('.json') or name.endswith('.manifest')))
expected={name:row for name,row in tree.items() if selected(name)};check('complete fixed-source map inventory',set(before)==set(expected),{'actual':len(before),'expected':len(expected)})
oids=list(dict.fromkeys(row[2] for row in expected.values()));raw=subprocess.check_output(['git','cat-file','--batch'],input=('\n'.join(oids)+'\n').encode());offset=0;blobs={}
for oid in oids:
 end=raw.index(b'\n',offset);head=raw[offset:end].split();size=int(head[2]);offset=end+1;data=raw[offset:offset+size];offset+=size+1;assert head[0].decode()==oid and head[1]==b'blob';blobs[oid]=data
forms={'exactGitBlob':0,'CRLFCheckout':0};mismatches=[];source_rows={}
for name,expected_hash in before.items():
 if name not in expected:mismatches.append(name);continue
 data=blobs[expected[name][2]];lf=hashlib.sha256(data).hexdigest();crlf=hashlib.sha256(data.replace(b'\n',b'\r\n')).hexdigest();form='exactGitBlob' if same(expected_hash,lf) else 'CRLFCheckout' if same(expected_hash,crlf) else None
 if form is None:mismatches.append(name)
 else:forms[form]+=1
 source_rows[name]={'gitBlobSha256':lf,'crlfCheckoutSha256':crlf,'observedWindowsSha256':expected_hash,'form':form}
check('all mapped Windows bytes match fixed Git source or exact CRLF checkout',not mismatches,{'forms':forms,'mismatches':mismatches})
check('selection fixed source cohort and build exits',selection['sourceHead']==HEAD and selection['cohort']=='LaunchPrerequisites' and selection['selectedCohort']=='FrozenRetirementResume' and selection['testBuildExit']==0 and selection['fixtureBuildExit']==0 and selection['sourceInputsStable'])
check('selection input hashes match actual source maps',same(selection['inputsBeforeSha256'],sha(ART/'inputs-before.json')) and same(selection['inputsAfterSha256'],sha(ART/'inputs-after.json')))
check('selected build genuine natural success',build['sourceHead']==HEAD and build['runnerExitCode']==0 and build['testBuildExit']==0 and build['fixtureBuildExit']==0 and build['buildSucceeded'] and build['sourceInputsStable'] and build['failure'] is None and build['afterSnapshotFailure'] is None)
for name,digest in build['rawFileSha256'].items():check('selected build raw hash '+name,same(digest,sha(ART/name)))
expected_ps={'.github/scripts/windows-selected-build.ps1','.github/scripts/windows-stdio-eof.ps1','.github/scripts/windows-stdout-controls.ps1','.github/scripts/windows-launch-prerequisites.ps1'}
check('all four actual native PowerShell parser checks passed',len(build['syntaxChecks'])==4 and {x['path'] for x in build['syntaxChecks']}==expected_ps and all(x['parseErrors']==[] and same(x['sha256'],before[x['path']]) for x in build['syntaxChecks']))
for field,name in [('buildScriptSha256','.github/scripts/windows-selected-build.ps1'),('workflowSha256','.github/workflows/windows-launch-prerequisites.yml'),('stdioRunnerSha256','.github/scripts/windows-stdio-eof.ps1')]:check('selection source pin '+field,same(selection[field],before[name]))
records=[json.loads(l) for l in (ART/'test-build.stdout.jsonl').read_text().split('\n') if l.startswith('{')];exes=[x['executable'] for x in records if x.get('reason')=='compiler-artifact' and x.get('profile',{}).get('test') and x.get('executable') and x['target']['name']=='farfold_lib']
check('one actual built library test executable selected',exes==[selection['testBinary']],exes)
stdout=(ART/'removal-boundary-waits.stdout.log').read_text();prefix=re.split(r'(?m)^(?:successes|failures):\r?$',stdout,maxsplit=1)[0];actual=[{'name':m.group(1),'result':m.group(2)} for m in re.finditer(r'(?m)^test (\S+) \.\.\. (ok|FAILED|ignored)\r?$',prefix)]
check('one group actual two outer cases exactly match expected names',len(actual)==2 and {x['name'] for x in actual}==set(EXPECTED) and all(x['result']=='ok' for x in actual) and actual==group['actualCases'])
check('outer argv preserves parent isolation and paired execution',group['argv']==EXPECTED+['--show-output','--test-threads=2','--color=never'])
check('outer group naturally exited0 with exact successful summary',group['naturalExitCode']==0 and group['passed'] and group['exactNames'] and group['summary']==['test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 2464 filtered out; finished in 127.86s'] and group['summary'][0] in stdout)
check('group source and exact selection binding',group['sourceHead']==HEAD and group['cohort']=='FrozenRetirementResume' and group['phase']=='BoundaryWaits' and same(group['selectionSha256'],sha(ART/'build-selection.json')))
check('group logs match actual raw hashes',same(group['stdoutSha256'],sha(ART/'removal-boundary-waits.stdout.log')) and same(group['stderrSha256'],sha(ART/'removal-boundary-waits.stderr.log')))
check('phase exact one group two executions naturally returned',phase['sourceHead']==HEAD and phase['cohort']=='FrozenRetirementResume' and phase['phase']=='BoundaryWaits' and phase['expectedGroups']==1 and phase['completedGroups']==1 and phase['expectedExecutions']==2 and phase['allReturned'] and phase['exactAllPassed'] and phase['sourceInputsStable'] and phase['groups']==[{'name':'removal-boundary-waits','naturalExitCode':0,'expectedTests':2,'passed':True}])
check('group and phase use the same build binary fixture pins',all(same(row[k],selection[k]) for row in [group,phase] for k in ['testBinarySha256','fixtureSha256']))
lines=stdout.split('\n');headers=list(re.finditer(r'(?m)^---- (\S+) stdout ----\r?$',stdout));child=[]
for n,m in enumerate(headers):
 end=headers[n+1].start() if n+1<len(headers) else len(stdout);block=stdout[m.end():end];name=m.group(1);summaries=re.findall(r'(?m)^test result: ok\. 1 passed; 0 failed; 0 ignored;.*?finished in ([0-9.]+)s\r?$',block);markers=[i for i,l in enumerate(lines,1) if l.rstrip('\r')=='completed:'+name]
 child.append({'fqn':name,'capturedChildSeconds':float(summaries[0]) if len(summaries)==1 else None,'completedMarkerLines':markers,'childSuccessProvenByOuterAssertions':group['naturalExitCode']==0})
 check('captured exact child completed and successful '+name,name in EXPECTED and len(summaries)==1 and len(markers)==1 and bool(re.search(r'(?m)^test '+re.escape(name)+r' \.\.\. ok\r?$',block)))
check('both child bodies accounted once',len(child)==2 and {c['fqn'] for c in child}==set(EXPECTED))
check('fixed wrapper actually checks child status and completion marker',b'status.success() && out.contains(&format!("completed:{name}"))' in blobs[tree['src-tauri/src/worktrees/recycle_tests.rs'][2]])
source_output={'sourceHead':HEAD,'mappedFiles':len(before),'forms':forms,'rows':source_rows};report={'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runId':41869099411,'sourceHead':HEAD,'allChecksPassed':all(x['passed'] for x in checks),'checkCount':len(checks),'checks':checks,'actualOuterCases':actual,'actualChildBodies':child,'sourceBinding':{'mappedFiles':len(before),'beforeAfterEqual':before==after,'gitSourceMatchForms':forms,'inputsBeforeSha256':sha(ART/'inputs-before.json'),'inputsAfterSha256':sha(ART/'inputs-after.json'),'binaryRemoteReportedSha256':selection['testBinarySha256'],'fixtureRemoteReportedSha256':selection['fixtureSha256'],'binaryUploaded':False,'downloadedBinaryRehashPerformed':False},'limits':['Selected native test fixture result only; fullWindows suite is not rerun here.','Child process success is checked by the actual source-bound parent wrapper; no separate exact child OS exit-code receipt is invented.','Binary hashes originate from the source-bound native Get-FileHash receipts; executables were not uploaded/downloaded and cannot be independently rehashed locally.','No installed App, real Agent/account/model, Windows installer or29x8 acceptance is established.']}
for name,value in [('expected-source-binding.json',source_output),('native-verification.json',report)]:
 path=BASE/name
 with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
 path.chmod(0o600)
print(json.dumps({'allChecksPassed':report['allChecksPassed'],'checkCount':len(checks),'failures':[x for x in checks if not x['passed']],'sourceForms':forms,'cases':actual,'children':child},ensure_ascii=False))
