import { afterEach, beforeEach, expect, it, vi } from "vitest";

const h = vi.hoisted(() => ({ invoke: vi.fn() }));
vi.mock("@tauri-apps/api/core", () => ({
  invoke: h.invoke,
  Channel: class {
    onmessage = (_: unknown) => {};
  },
}));
import { threads } from "./sessions";
import type { ThreadState } from "./session_types";
import type { ConfigCheck } from "./config_check";
import { draftPersistence } from "./drafts";

let sequence = 0;
function event(s: ThreadState, check: ConfigCheck) {
  (
    threads as unknown as {
      applyChannelEvent(key: string, event: unknown): void;
    }
  ).applyChannelEvent(s.key, { kind: "configCheck", check });
}
function fixture() {
  const id = `receipt-before-pull-${sequence++}`;
  const s = threads.markOpenFailed(id, "ordering", "/fixture", id, "fixture");
  s.openError = null;
  s.connectionId = `connection-${id}`;
  s.configOptions = [
    {
      id: "model",
      category: "model",
      name: "Model",
      type: "select",
      currentValue: "a",
      options: [{ value: "b", name: "B" }],
    },
  ];
  const options = s.configOptions.map((option) => ({
    ...option,
    currentValue: "b",
  }));
  const check: ConfigCheck = {
    status: "ready",
    issues: [],
    protectedIds: ["model"],
    current: {
      choices: [{ id: "model", category: "model", type: "select", value: "b" }],
    },
  };
  event(s, { ...check, status: "record_failed" });
  h.invoke.mockImplementation(async (command) => {
    if (command === "session_confirm_config")
      return {
        ...check,
        configuration: {
          configOptions: options,
          configOptionsModern: true,
          configCheck: check,
          service: null,
          permissionConfigId: null,
          permissionState: "ready",
        },
      };
    return command === "settings_get" ? null : [];
  });
  return { s, check, options };
}

beforeEach(() => {
  vi.spyOn(draftPersistence, "flush").mockResolvedValue();
  h.invoke.mockReset();
});
afterEach(() => vi.restoreAllMocks());

it("accepts the matching complete RPC before the queued ready body is pulled", async () => {
  const { s, check, options } = fixture();
  await threads.confirmConfig(s.key);
  expect(s.configOptions).toEqual(options);
  expect(s.configCheck).toEqual(check);
  expect(s.queuePaused).toBeNull();
  expect(s.configError).toBeNull();
  event(s, check);
  expect(s.configOptions).toEqual(options);
  expect(s.configError).toBeNull();
  expect(
    h.invoke.mock.calls.some(([command]) => command === "session_prompt"),
  ).toBe(false);
});

it("keeps a later pulled difference authoritative while sidebar refresh is pending", async () => {
  const { s, check, options } = fixture();
  const invoke = h.invoke.getMockImplementation()!;
  let refresh!: () => void;
  h.invoke.mockImplementation((command, ...args) =>
    command === "session_index_list"
      ? new Promise((resolve) => {
          refresh = () => resolve([]);
        })
      : invoke(command, ...args),
  );
  const pending = threads.confirmConfig(s.key);
  await vi.waitFor(() => expect(s.configOptions).toEqual(options));
  const changed: ConfigCheck = {
    ...check,
    status: "blocked",
    issues: [
      { category: "model", reason: "changed", expected: "b", current: "c" },
    ],
    current: {
      choices: [{ id: "model", category: "model", type: "select", value: "c" }],
    },
  };
  event(s, changed);
  refresh();
  await pending;
  expect(s.configCheck).toEqual(changed);
  expect(s.modelDrift).toBe(true);
  expect(s.queuePaused).toBe("unavailable");
  expect(s.configOptions).toEqual(options);
  expect(
    h.invoke.mock.calls.some(([command]) => command === "session_prompt"),
  ).toBe(false);
});
