from pathlib import Path
import datetime, hashlib, json, subprocess, sys, time
ROOT = Path('/Users/tw/Desktop/farfold')
BASE = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
assert label and command and all(c.isalnum() or c in '-_' for c in label)
run = BASE / label
run.mkdir(exist_ok=False)
def inputs():
    files = set(ROOT.joinpath('src').rglob('*.ts')) | set(ROOT.joinpath('src').rglob('*.tsx'))
    files |= {ROOT / p for p in ['package.json','pnpm-lock.yaml','vitest.config.ts','tsconfig.json','tsconfig.app.json','tsconfig.node.json'] if (ROOT / p).is_file()}
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
def save(name,value):
    (run/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
before=inputs();save('source-before.json',before)
for name in ['session_configuration.ts','session_configuration_confirmation.ts','session_event_projection.ts','sessions.ts','sessions.config-save-retry.test.ts','sessions.config-save-retry-ordering.test.ts']:
    source=ROOT/'src/runtime'/name
    if source.is_file(): (run/name).write_bytes(source.read_bytes())
started_at=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
with (run/'command.log').open('xb') as stream:
    result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
after=inputs();save('source-after.json',after)
receipt={'command':command,'startedAt':started_at,'elapsedSeconds':round(time.monotonic()-start,6),'naturalExitCode':result.returncode,'listedFrontendAndConfigInputs':len(before),'inputsStableAtEndpoints':before==after,'rawLogSha256':hashlib.sha256((run/'command.log').read_bytes()).hexdigest()}
save('result.json',receipt);print(json.dumps(receipt,ensure_ascii=False));print((run/'command.log').read_text());sys.exit(result.returncode)
