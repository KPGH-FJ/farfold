# 删除边界夹具等待：有界修订与本机验证

唯一源码变化为 `src-tauri/src/worktrees/remove_boundary_tests.rs`。`source.patch`、before/after 原件和 `summary.json` 记录三处精确预算变化。共享 wait20、held释放10、结束等待20和全部原断言保持。

原 Windows full69 是本批原生 RED：2466 总项，2389 通过、2 失败、75 忽略；libtest3499.97秒，整体检查步骤4805秒，以退出1结束，并非90分钟job超时。第一项在实际recover的20秒等待时仍running，第二项在等待retire回调进入的10秒超时；不能把它误称回调内部held等待失败，也不能推断具体系统根因。

本机执行一次格式检查、一次 `cargo test --locked --lib --no-run` 增量编译；从Cargo原始JSON绑定唯一test binary后，复用同程序同时选择两完整FQN，以 `--test-threads=2`、不加 `--exact` 运行，保留父封装。外层2条全部通过且零忽略，两个子进程均有completed标记；程序SHA及793份列举输入前后相同。原始命令、退出码、日志和输入映射在 `fmt/`、`build/`、`mac-two/`。

这次Mac结果不代表Windows新预算已通过；原生验证由主代理唯一派发。未改生产期限，未运行完整工程检查、App、真实Agent或Git操作。
