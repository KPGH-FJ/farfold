from pathlib import Path
import datetime, hashlib, json, subprocess, sys, time
ROOT=Path('/Users/tw/Desktop/farfold')
BASE=Path(__file__).resolve().parent
label,*command=sys.argv[1:]
assert label and command and all(c.isalnum() or c in '-_' for c in label)
run=BASE/label;run.mkdir(exist_ok=False)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def inputs():
 files=set((ROOT/'src-tauri/src').rglob('*.rs'))
 files|={ROOT/p for p in ['src-tauri/Cargo.toml','src-tauri/Cargo.lock','src-tauri/build.rs','src-tauri/tauri.conf.json','.cargo/config.toml','src-tauri/.cargo/config.toml'] if (ROOT/p).is_file()}
 return {str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}
def save(name,value):(run/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
before=inputs();save('source-before.json',before)
if label=='mac-two':
 binding=json.loads((BASE/'build/result.json').read_text())['testBinary']
 assert command[0]==binding['path'] and sha(Path(command[0]))==binding['sha256']
 save('binary-before.json',binding)
started_at=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
with (run/'command.log').open('xb') as stream:result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
after=inputs();save('source-after.json',after)
receipt={'command':command,'startedAt':started_at,'elapsedSeconds':round(time.monotonic()-start,6),'naturalExitCode':result.returncode,'listedRustAndExplicitBuildInputs':len(before),'inputsStableAtEndpoints':before==after,'rawLogSha256':sha(run/'command.log')}
if label=='build' and result.returncode==0:
 artifacts=[]
 for line in (run/'command.log').read_text().splitlines():
  try:value=json.loads(line)
  except ValueError:continue
  if value.get('reason')=='compiler-artifact' and value.get('executable') and value.get('profile',{}).get('test') and value.get('target',{}).get('name')=='farfold_lib':artifacts.append(value)
 assert len(artifacts)==1,artifacts
 executable=Path(artifacts[0]['executable']);receipt['testBinary']={'path':str(executable),'sha256':sha(executable),'bytes':executable.stat().st_size}
if label=='mac-two':
 receipt['testBinaryBefore']=binding;receipt['testBinaryAfterSha256']=sha(Path(command[0]));receipt['binaryStable']=receipt['testBinaryAfterSha256']==binding['sha256']
save('result.json',receipt);print(json.dumps(receipt,ensure_ascii=False))
if label!='build':print((run/'command.log').read_text())
sys.exit(result.returncode)
