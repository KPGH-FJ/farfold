from pathlib import Path
import datetime, hashlib, json, re, subprocess, time
ROOT = Path('/Users/tw/Desktop/farfold')
BASE = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
paths = json.loads((BASE / 'declared-inputs.json').read_text())
pins = lambda: {p: sha((ROOT / p).read_bytes()) for p in paths}
catalog = json.loads((BASE / 'final-list-v2.json').read_text())
binary = ROOT / catalog['binary']['path']
expected_binary_sha = catalog['binary']['sha256']
rows = []
for index, group in enumerate(catalog['groups']):
    phase = f'associated-{index + 1}'
    argv = [str(binary), group['prefix'], '--show-output', '--test-threads=1']
    assert sha(binary.read_bytes()) == expected_binary_sha
    assert not (BASE / (phase + '.json')).exists()
    before = pins()
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    result = subprocess.run(argv, cwd=ROOT, capture_output=True)
    streams = {}
    for name, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        path = BASE / f'{phase}.{name}.log'
        path.write_bytes(data)
        path.chmod(0o600)
        streams[name] = {'path': str(path.relative_to(ROOT)), 'sha256': sha(data), 'bytes': len(data)}
    observed = re.findall(r'^test ([^ ]+) \.\.\. (ok|FAILED|ignored)(?:,.*)?$', result.stdout.decode(), re.M)
    after = pins()
    row = {'phase': phase, 'argv': argv, 'cwd': str(ROOT), 'startedAtUtc': start,
           'durationSeconds': time.monotonic() - tick, 'naturalExitCode': result.returncode,
           'sourceBefore': before, 'sourceAfter': after, 'sourceEndpointsEqual': before == after,
           'binarySha256': expected_binary_sha, 'binaryAfterSha256': sha(binary.read_bytes()),
           'expectedNames': group['names'], 'observed': [{'name': n, 'state': state} for n, state in observed],
           'exactCatalogMatched': sorted(n for n, _ in observed) == sorted(group['names']), **streams}
    (BASE / (phase + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    rows.append({'phase': phase, 'naturalExitCode': result.returncode, 'exactCatalogMatched': row['exactCatalogMatched'],
                 'passed': sum(state == 'ok' for _, state in observed), 'ignored': sum(state == 'ignored' for _, state in observed),
                 'failed': sum(state == 'FAILED' for _, state in observed), 'durationSeconds': row['durationSeconds']})
    assert result.returncode == 0 and before == after and row['binaryAfterSha256'] == expected_binary_sha
    assert row['exactCatalogMatched']
print(json.dumps({'groups': rows}))
(BASE / 'associated-summary.json').write_text(json.dumps({'groups': rows, 'binary': catalog['binary'],
    'scope': 'Three related groups from same final green test executable. Controlled peer and owned SQLite/helper evidence; no installed App/IPC, official Agent, Windows or full project checks.'}, indent=2) + '\n')
