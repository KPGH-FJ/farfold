"""Copy completed originals into the existing formal tool's canonical names."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import stat

ROOT = Path('/Users/tw/Desktop/farfold')
BASE = Path(__file__).resolve().parent
ENGINEERING = BASE / 'engineering'
COMMANDS = {
    'format-final': ['corepack', 'pnpm', 'format:check'],
    'typecheck-final': ['corepack', 'pnpm', 'typecheck'],
    'frontend-final': ['corepack', 'pnpm', 'test'],
    'build-final': ['corepack', 'pnpm', 'build'],
    'cargo-fmt': ['cargo', 'fmt', '--check', '--manifest-path', 'src-tauri/Cargo.toml'],
    'clippy': ['cargo', 'clippy', '--manifest-path', 'src-tauri/Cargo.toml', '--locked', '--', '-D', 'warnings'],
    'rust-full': ['cargo', 'test', '--manifest-path', 'src-tauri/Cargo.toml', '--locked'],
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path):
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(path)}


def read(path):
    return json.loads(path.read_text())


before, after = [ENGINEERING / f'source-{phase}.json' for phase in ('before', 'after')]
inputs = read(before)['files']
assert inputs == read(after)['files']
assert all(sha(ROOT / name) == value for name, value in inputs.items())
copies, rows, provenance = [], [], {}
for label, argv in COMMANDS.items():
    receipt = ENGINEERING / 'checks' / f'{label}.json'
    original = receipt.with_suffix('.log')
    result = read(receipt)
    assert result['exitCode'] == 0 and result['command'] == argv
    assert result['cwd'] == str(ROOT) and result['log'] == original.relative_to(ROOT).as_posix()
    assert result['startedAt'] < result['finishedAt'] and result['durationSeconds'] >= 0
    destination = BASE / original.name
    copies.append((original, destination))
    rows.append({'log': original.name, 'naturalExitCode': result['exitCode'],
                 'argv': argv, 'sha256': sha(original), 'receipt': ref(receipt)})
    provenance[original.name] = {'source': original.relative_to(ROOT).as_posix(), 'sha256': sha(original)}
front = (ENGINEERING / 'checks/frontend-final.log').read_text()
rust = (ENGINEERING / 'checks/rust-full.log').read_text()
files = re.search(r'Test Files\s+(\d+) passed \(\1\)', front)
tests = re.search(r'Tests\s+(\d+) passed \(\1\)', front)
native = re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', rust)
assert files and tests and native and int(native[0][0]) > 0
report = {'bindingState': 'ACTUAL_COMPLETED_SEVEN', 'sourceInputs': len(inputs),
          'frontendFiles': int(files[1]), 'frontendPassed': int(tests[1]),
          'rustPassed': int(native[0][0]), 'rustIgnored': int(native[0][1]),
          'sevenCommands': rows, 'logProvenance': provenance,
          'originalInputMaps': [ref(before), ref(after)],
          'sourceBoundary': 'Seven fresh original natural-zero commands; full declared input endpoints equal. Not Windows or installed-product acceptance.'}
copies += [(before, BASE / 'source-final-before.json'),
           (after, BASE / 'source-final-after.json')]
assert not (BASE / 'engineering-result.json').exists()
assert all(not target.exists() and not target.is_symlink() for _, target in copies)
for source, target in copies:
    with target.open('xb') as stream:
        stream.write(source.read_bytes())
    target.chmod(0o600)
    assert sha(source) == sha(target)
with (BASE / 'engineering-result.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
(BASE / 'engineering-result.json').chmod(0o600)
print(json.dumps({key: report[key] for key in ['sourceInputs', 'frontendFiles', 'frontendPassed', 'rustPassed', 'rustIgnored']}))
