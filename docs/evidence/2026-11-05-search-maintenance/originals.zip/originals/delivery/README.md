# Published ordinary-file receipt fidelity

P35/P18: an in-place change before the final observation could preserve file identity while old code returned the original size/hash as Completed. Both ordinary-copy and text-snapshot production entries now use a shared final receipt helper that checks actual bytes, size, before/after file state, reopened identity and parent location. Failed checks retain the published object and report DestinationChanged/Unknown. Existing cancellation, admission, source version and deadline semantics remain.

Corrected RED is real 3 pass / 4 fail, natural 101, after behavior-preserving production extraction. The same sealed seven-test bytes are GREEN 7/0/0. The real stream_copy witness uses its existing publication callback to alter one owned temporary file before publication; no new production hook or post-success change. The first attempt is preserved: five noncanonical-path fixture failures are not product RED.

Same GREEN binary: four associated groups, 46 passed / 0 failed / one pre-existing ignored 256MiB benchmark; exact actual names match catalog. Target formatting and lib/tests Clippy naturally exited 0. source-final.json is the final three-file pointer. Raw receipts, source snapshots, mechanical patch, fixture corrections and author summary are retained. manifest.json hashes all other sealed files in this directory.

Only owned temporary files were used. No user DB/data/config, real Agent/model, installed UI, complete IPC, Windows or full-seven proof. The added read is bounded/chunked; only 2MiB positive copy was measured, not maximum capacity/performance. A receipt is a final observation, not a continuous freeze or filesystem snapshot. Author packaging is not an independent review.
