# 管理取消观察与旧计时器 v2 独审

**PASS_WITH_EXPLICIT_SCOPE，0 必改。** 原v1静态CHANGES_REQUESTED回执保留。

- 原S1→C2null→新S3→旧S1timer反例已有实际sealed14：v1为8过6败，修后同测试字节14过。最终17文件221过/0跳过及3文件格式0原报告、日志/28成员清单、当前3源核合。
- Skill旧timer仍记录lost并按原请求调用原target.changed；实际confirm两例断言额外changed仍发生。Inventory observationLost仍保守记录。只把UI checking/error发布限定给当前existingepoch，不放开unknown/写入/确认，也不改期限或自动查询。
- Inventory的epoch来自begin0及check/cancel在publish前捕获的已有值；同步subscriber不能在observe构造时把旧观察重新标作新观察。普通null与旧null负控保留，真实按钮仅恢复明确同请求status，不冒称取消成功。
- 第一次14GREEN的controller字节不同于最终冻结；最终17/221与格式回执才绑定当前3源。不能称后续全部只是注释或第一次GREEN已是最终production。

这是受控ports/fakeTimers和实际controller/按钮closure层，不是DOM/完整IPC/官方CLI取消结果。未重跑任何检查或操作App/用户库/Agent；Root另负责合批完整工程和实机。
