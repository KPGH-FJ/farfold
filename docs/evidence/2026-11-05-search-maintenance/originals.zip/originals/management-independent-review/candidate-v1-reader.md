# 管理观察 v1：静态反例待实证

**CHANGES_REQUESTED_STATIC_COUNTEREXAMPLE，1必改候选；本读者未运行测试，不宣称旧8/215检查失败。**

实际链：初始inspect/read失败→status S1仍待定→cancel C2返回null并清checking→用户明确status S3→旧S1计时到期。Skill observe:245–254和Inventory observe:138–147的timer只核同flight/unresolved，无epoch条件，会将S3的checking改false/error timedOut；普通null分支的新epoch防线没覆盖timer。实际UI按钮仅依checking禁用，故这个再次查询入口可达。

现有两负控先让旧cancel timer到期再开新status，只覆盖旧null回执，不能排除此时序。作者应先用真实controller/buttons/fakeTimers封RED，再区分旧观察风险记录与当前UI发布；不能放开unknown/写入权限、改期限或自动重试。Root已交作者处理。

仅只读源码/夹具与写本独占回执；原件、源和最终reader均未改，待v2另审。
