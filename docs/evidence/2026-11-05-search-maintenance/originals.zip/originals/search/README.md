# 文件查找来源附件：等待实际显示后定位

P32显式当前文件内容查找走AttachmentSearchJump；它与既有LoadedSearchJump的已接收文字命中不同。旧路径固定第二帧便声明定位，未等第四附件hidden或前个受管理details关闭提交。最终合法typed7在精确旧生产源码3过4败→同字节7过；4败均是实际生产Jump过早focus，非镜像predicate。

生产仅Jump一处：复用既有SearchExpansion可见/提交判断，事件驱动单pending帧；定位/失效/清理退役监听与所属展开，无新期限/轮询/授权。原4case只机械补DOM/ready接口，不删断言。最终8文件103过(含新7/旧4)、类型0、3文件格式0。旧5轮和漏streaming:false的类型失败原样保留；最终typed7另封，勿混版本。

原始命令/日志在checks/，各report、8项窄输入端点及source-final.json/production.patch可审。初5GREEN未及时拍aftermap，不补造；最终typed7已真实拍前后并恢复fixed source。未做完整七项、浏览器/安装版、真实Agent/用户库或Windows。新安全安装实测条件与完整P12/P32余项见implementation-summary.json，不新增验收门槛。
