# 后端打开结果错误分类

生产修改仅 `src-tauri/src/acp_client/wait.rs`、`session.rs`。前者增加内部 typed reply，同时保留旧 `reply` 的完整字符串；后者只把非 fork 打开结果等待的两种外层失败转成 `AGENT_OPEN_TIMEOUT` / `AGENT_OPEN_CLOSED`。120 秒、fork 无新增期限、内层错误与 `.accept()` 不变。两码不能定位到 load/new/config/ready 的具体阶段，也不说明未知工作已经结束。

`baseline/` 是抽取前源文件；`red-open/` 是保持原行为的私有 helper 抽取和回归：编译成功，1 passed / 2 failed，自然退出 101。`baseline-to-red.patch` 保留这一步，`red-to-green.patch` 保留后续实际实现。所有原始命令、退出码、耗时和日志摘要位于各轮 `result.json`；`command.log` 是实际合并输出。各轮保存当时两份源文件及 792 项 Rust/build 输入端点摘要。

GREEN：打开回归 3、wait 兼容与 typed 回归 2、既有真实受控 peer 的 open_delivery 9、OpenDelivery 归属 1、fork owner 3，共 18 passed。`cargo fmt --check` 自然退出 0。精确命令和结果见 `summary.json`，没有重新执行完整七项。

其中一次实际命令为：

```sh
python3 output/2026-11-04-open-failure-diagnostics/backend/run-check.py green-open cargo test --manifest-path src-tauri/Cargo.toml --locked --lib acp_client::session::open_reply_tests:: -- --nocapture
```

已有轮次禁止覆盖；未来明确复跑须选一个新 label。测试仅使用 oneshot、既有受控 peer 和临时资料，不运行官方 Agent、正式应用、账号、凭据或真实模型请求；不代表安装界面或 Windows 实机通过。
