"""Preserve one exact scoped command and its real exit; never retries."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path('/Users/tw/Desktop/farfold')
BASE = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
assert label and command and all(c.isalnum() or c in '-_' for c in label)
run = BASE / label
run.mkdir(exist_ok=False)

def inputs():
    files = sorted(set((ROOT / 'src-tauri/src').rglob('*.rs')) | {
        ROOT / name for name in ('src-tauri/Cargo.toml', 'src-tauri/Cargo.lock', 'src-tauri/build.rs')})
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}

def save(name, value):
    with (run / name).open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

before = inputs()
save('source-before.json', before)
for name in ('wait.rs', 'session.rs'):
    (run / name).write_bytes((ROOT / 'src-tauri/src/acp_client' / name).read_bytes())
started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
started = time.monotonic()
with (run / 'command.log').open('xb') as stream:
    result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - started
after = inputs()
save('source-after.json', after)
receipt = {'command': command, 'startedAt': started_at, 'naturalExitCode': result.returncode,
    'elapsedSeconds': round(elapsed, 6), 'listedRustAndBuildInputs': len(before),
    'inputsStableAtEndpoints': before == after,
    'rawLogSha256': hashlib.sha256((run / 'command.log').read_bytes()).hexdigest()}
save('result.json', receipt)
print(json.dumps(receipt, ensure_ascii=False))
sys.exit(result.returncode)
