from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path('/Users/tw/Desktop/farfold')
BASE = Path(__file__).resolve().parent
phase = sys.argv[1]
assert len(sys.argv) == 2 and phase.replace('-', '').isalnum()
paths = list(json.loads((BASE / 'source-before.json').read_text())['files']) + [
    'src-tauri/src/acp_client/pump/config_activity_pending_tests.rs'
]
sha = lambda data: hashlib.sha256(data).hexdigest()
pins = lambda: {name: sha((ROOT / name).read_bytes()) for name in paths}
argv = ['cargo', 'test', '--manifest-path', 'src-tauri/Cargo.toml', '--locked',
        '--lib', '--message-format=json', 'acp_client::pump::config_activity_pending_tests::',
        '--', '--show-output', '--test-threads=1']
assert all(not (BASE / (phase + suffix)).exists() for suffix in ['.json', '.stdout.log', '.stderr.log'])
before = pins()
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
result = subprocess.run(argv, cwd=ROOT, capture_output=True)
after = pins()
streams = {}
for name, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
    path = BASE / f'{phase}.{name}.log'
    with path.open('xb') as stream:
        stream.write(data)
    path.chmod(0o600)
    streams[name] = {'path': str(path.relative_to(ROOT)), 'sha256': sha(data), 'bytes': len(data)}
artifacts = []
for line in result.stdout.splitlines():
    try:
        item = json.loads(line)
    except (ValueError, UnicodeDecodeError):
        continue
    if (isinstance(item, dict) and item.get('reason') == 'compiler-artifact'
            and item.get('profile', {}).get('test')
            and item.get('target', {}).get('name') == 'farfold_lib' and item.get('executable')):
        path = Path(item['executable'])
        artifacts.append({'path': str(path.relative_to(ROOT)), 'sha256': sha(path.read_bytes()),
                          'bytes': path.stat().st_size})
receipt = {'phase': phase, 'argv': argv, 'cwd': str(ROOT), 'startedAtUtc': start,
           'finishedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'durationSeconds': time.monotonic() - tick, 'naturalExitCode': result.returncode,
           'sourceBefore': before, 'sourceAfter': after, 'declaredSourceEndpointsEqual': before == after,
           'scope': 'Nine declared Rust source/test/config inputs; actual production first-poll and owned SDK peer frames, not complete transitive inputs, control-entry, installed UI or official Agent.',
           'actualTestExecutables': artifacts, **streams}
path = BASE / (phase + '.json')
with path.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
path.chmod(0o600)
print(json.dumps({'phase': phase, 'naturalExitCode': result.returncode,
                  'seconds': receipt['durationSeconds'], 'sourceEndpointsEqual': before == after,
                  'receipt': str(path.relative_to(ROOT)), 'testExecutables': artifacts}))
sys.exit(result.returncode)
