import pathlib,subprocess,sys
base=pathlib.Path(__file__).resolve().parent
checks={
"frontend":[("format-final",["corepack","pnpm","format:check"]),("typecheck-final",["corepack","pnpm","typecheck"]),("frontend-final",["corepack","pnpm","test"]),("build-final",["corepack","pnpm","build"])],
"rust":[("cargo-fmt",["cargo","fmt","--check","--manifest-path","src-tauri/Cargo.toml"]),("clippy",["cargo","clippy","--manifest-path","src-tauri/Cargo.toml","--locked","--","-D","warnings"]),("rust-full",["cargo","test","--manifest-path","src-tauri/Cargo.toml","--locked"])]}
for label,command in checks[sys.argv[1]]:
    result=subprocess.run([sys.executable,str(base/"run-check.py"),label,*command])
    if result.returncode:raise SystemExit(result.returncode)
