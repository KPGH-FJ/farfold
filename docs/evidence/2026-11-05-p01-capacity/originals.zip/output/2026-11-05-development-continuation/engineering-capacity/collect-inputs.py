from pathlib import Path
import ast, hashlib, json, os, re, stat, sys
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
stage=sys.argv[1]
assert stage in {"before","after"}
parameters=json.loads((ROOT/"output/2026-11-04-p01-draft-formal/formal/parameters.json").read_text())
ref=parameters["toolPins"]["shared"]
shared=ROOT/ref["path"]
assert hashlib.sha256(shared.read_bytes()).hexdigest()==ref["sha256"]
tree=ast.parse(shared.read_text())
scopes=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="SCOPES" for t in n.targets))
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="admitted")
pattern=next(ast.literal_eval(n.args[0]) for n in ast.walk(node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="fullmatch")
def admitted(name):
    return any(name.startswith(scope) for scope in scopes) or bool(re.fullmatch(pattern,name))
names=set()
for parent in (ROOT,ROOT/"src-tauri"):
    for p in parent.iterdir():
        n=p.relative_to(ROOT).as_posix()
        if admitted(n) and (p.is_file() or p.is_symlink()): names.add(n)
for scope in scopes:
    base=ROOT/scope
    if not base.exists():
        assert not base.is_symlink()
        continue
    assert base.is_dir() and not base.is_symlink()
    for directory,dirs,files in os.walk(base,followlinks=False):
        dirs[:]=[n for n in dirs if n!="__pycache__"]
        assert all(not (Path(directory)/n).is_symlink() for n in dirs)
        names.update((Path(directory)/n).relative_to(ROOT).as_posix() for n in files if n!=".DS_Store")
production=len(names)
names.update({"PRODUCT.md","docs/agent-access-requirements.md","docs/agent-first-release.md",".prettierignore"})
files={}
for name in sorted(names):
    p=ROOT/name
    info=p.lstat()
    assert stat.S_ISREG(info.st_mode) and not p.is_symlink()
    files[name]=hashlib.sha256(p.read_bytes()).hexdigest()
output=OUT/f"source-{stage}.json"
with output.open("x") as f: json.dump({"files":files},f,ensure_ascii=False,indent=2);f.write("\n")
if stage=="after": assert files==json.loads((OUT/"source-before.json").read_text())["files"]
print(json.dumps({"stage":stage,"productionInputs":production,"allInputs":len(files),"sourceEndpointMatch":stage=="after"}))
