import { execFile } from "node:child_process";
import { createHash, randomBytes } from "node:crypto";
import * as fs from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { isValidElement, type ReactNode } from "react";
import { expect, it, vi } from "vitest";

const h = vi.hoisted(() => ({
  invoke: vi.fn(),
  states: [] as unknown[],
  refs: [] as { current: unknown }[],
  effects: [] as (() => unknown)[],
  listeners: new Map<string, (event: { payload: number }) => void>(),
  stateCursor: 0,
  refCursor: 0,
}));
// Same small hook/event harness as DraftStartup.test.tsx. The draft store and
// DraftStartup's save/exit code stay real; native exit calls are only recorded.
vi.mock("react", async (original) => ({
  ...(await original<typeof import("react")>()),
  useSyncExternalStore: (_subscribe: unknown, get: () => unknown) => get(),
  useRef: (current: unknown) => (h.refs[h.refCursor++] ??= { current }),
  useState: (initial: unknown) => {
    const index = h.stateCursor++;
    if (index >= h.states.length) h.states.push(initial);
    return [
      h.states[index],
      (value: unknown) => {
        h.states[index] =
          typeof value === "function" ? value(h.states[index]) : value;
      },
    ];
  },
  useEffect: (effect: () => unknown) => h.effects.push(effect),
}));
vi.mock("@tauri-apps/api/core", () => ({ invoke: h.invoke }));
vi.mock("@tauri-apps/api/event", () => ({
  listen: async (
    name: string,
    callback: (event: { payload: number }) => void,
  ) => {
    h.listeners.set(name, callback);
    return () => h.listeners.delete(name);
  },
}));
vi.mock("../../../src/runtime/setup_storage", () => ({
  setupStorage: { load: async () => {}, flush: async () => {} },
  useSetupStorage: () => ({ ready: true, error: null }),
  SETUP_STORAGE_STRINGS: {},
}));
vi.mock("../../../src/runtime/conversation_read_state", () => ({
  conversationReadState: {
    flushPending: async () => {},
    snapshot: () => ({ error: null }),
  },
}));
vi.mock("../../../src/runtime/sessions", () => ({
  threads: {
    pauseQueuesForExit: vi.fn(),
    getSnapshot: () => ({ threads: new Map() }),
  },
}));
vi.mock("../../../src/runtime/authentication", () => ({
  hasActiveAuthentication: () => false,
}));
vi.mock("../../../src/runtime/update_impact", () => ({
  updateConversationBlocker: () => null,
}));
vi.mock("../../../src/runtime/file_copy_jobs", () => ({
  hasUnsettledFileCopies: () => false,
  useFileCopyJobs: () => [],
  fileCopyJobs: { getSnapshot: () => [] },
}));
vi.mock("../../../src/runtime/conversation_archive_jobs", () => ({
  useConversationArchiveJobs: () => [],
  conversationArchiveJobs: { hasUnknownFinished: () => false },
}));
vi.mock("../../../src/components/FileCopyJobsStatus", () => ({
  FileCopyJobsStatus: () => null,
}));
vi.mock("../../../src/components/ConversationArchiveJobsStatus", () => ({
  ConversationArchiveJobsStatus: () => null,
}));
vi.mock("../../../src/components/WorktreeManagementHost", () => ({
  WorktreeManagementHost: () => null,
}));
vi.mock("../../../src/components/StorageRecovery", () => ({
  StorageRecovery: () => null,
}));
vi.mock("../../../src/components/WorkspaceDialog", () => ({
  WorkspaceDialog: () => null,
}));

const run = promisify(execFile);
const output = fileURLToPath(new URL("./", import.meta.url));
const root = path.resolve(output, "../../..");
const driverName =
  "meta_store::recovery_tests::explicit_frontend_storage_bridge";
const digest = (bytes: Uint8Array) =>
  createHash("sha256").update(bytes).digest("hex");
type Ref = { path: string; sha256: string };
type Binding = {
  bindingState: "BOUND";
  driverName: string;
  executable: string;
  executableSha256: string;
  defaultIgnoredVerified: boolean;
  cargoReceipt: Ref;
  cargoLog: Ref;
  ignoredListReceipt: Ref;
  ignoredListStdout: Ref;
  ignoredListStderr: Ref;
  sourceInputMap: Ref;
  sourceInputCount: number;
  fixtureInputs: Record<string, string>;
};

function ownPath(relative: string): string {
  expect(path.isAbsolute(relative)).toBe(false);
  expect(relative.split("/")).not.toContain("..");
  const absolute = path.resolve(root, relative);
  expect(absolute.startsWith(root + path.sep)).toBe(true);
  return absolute;
}
async function evidence(ref: Ref): Promise<Buffer> {
  expect(/^[a-f0-9]{64}$/.test(ref.sha256)).toBe(true);
  expect(
    ref.path.startsWith("output/") || ref.path.startsWith("docs/evidence/"),
  ).toBe(true);
  const bytes = await fs.readFile(ownPath(ref.path));
  expect(digest(bytes)).toBe(ref.sha256);
  return bytes;
}
function nodes(node: ReactNode): ReactNode[] {
  if (Array.isArray(node)) return node.flatMap(nodes);
  if (!isValidElement<{ children?: ReactNode }>(node)) return [node];
  return [node, ...nodes(node.props.children)];
}

it("blocks DraftStartup exit after a real SQLite page-limit FULL error, then explicitly retries and cold loads", async () => {
  // This file deliberately has no fallback to any old binding or automatic
  // Cargo build. Root supplies actual final build/list/map evidence first.
  const bindingPath = path.join(output, "driver-binding.json");
  const bindingBytes = await fs.readFile(bindingPath);
  const binding: Binding = JSON.parse(bindingBytes.toString("utf8"));
  expect(binding.bindingState).toBe("BOUND");
  expect(binding.driverName).toBe(driverName);
  expect(binding.defaultIgnoredVerified).toBe(true);
  expect(/^[a-f0-9]{64}$/.test(binding.executableSha256)).toBe(true);
  const binaryInfo = await fs.lstat(binding.executable);
  expect(binaryInfo.isFile() && !binaryInfo.isSymbolicLink()).toBe(true);
  const binary = await fs.realpath(binding.executable);
  expect(path.dirname(binary)).toBe(
    await fs.realpath(path.join(root, "src-tauri/target/debug/deps")),
  );
  expect(/^farfold_lib-[a-f0-9]+$/.test(path.basename(binary))).toBe(true);

  const cargoReceipt = JSON.parse(
    (await evidence(binding.cargoReceipt)).toString("utf8"),
  );
  expect(cargoReceipt.naturalExitCode ?? cargoReceipt.exitCode).toBe(0);
  expect(cargoReceipt.command[0]).toBe("cargo");
  expect(cargoReceipt.command).toContain("test");
  const cargoLog = (await evidence(binding.cargoLog)).toString("utf8");
  expect(cargoLog).toContain(path.basename(binary));
  const ignoredReceipt = JSON.parse(
    (await evidence(binding.ignoredListReceipt)).toString("utf8"),
  );
  expect(ignoredReceipt.naturalExitCode ?? ignoredReceipt.exitCode).toBe(0);
  expect(ignoredReceipt.command).toEqual([
    binary,
    driverName,
    "--exact",
    "--ignored",
    "--list",
  ]);
  const ignoredStdout = (
    await evidence(binding.ignoredListStdout)
  ).toString("utf8");
  expect(ignoredStdout).toContain(driverName + ": test");
  expect(ignoredStdout).toContain("1 test, 0 benchmarks");
  expect((await evidence(binding.ignoredListStderr)).length).toBe(0);

  const sourceMap = JSON.parse(
    (await evidence(binding.sourceInputMap)).toString("utf8"),
  ).files as Record<string, string>;
  expect(Object.keys(sourceMap)).toHaveLength(binding.sourceInputCount);
  for (const required of [
    "src/runtime/drafts.ts",
    "src/runtime/draft_storage.ts",
    "src/components/DraftStartup.tsx",
    "src/runtime/storage_recovery.ts",
    "src/runtime/strings.ts",
    "src-tauri/src/meta_store.rs",
    "src-tauri/src/storage_recovery/error.rs",
    "src-tauri/src/meta_store/recovery_tests.rs",
    "src-tauri/Cargo.toml",
    "src-tauri/Cargo.lock",
    "package.json",
    "pnpm-lock.yaml",
  ]) {
    expect(Object.hasOwn(sourceMap, required)).toBe(true);
  }
  const fixturePaths = [
    path.relative(root, path.join(output, "frontend-capacity-exit.test.ts")),
    path.relative(root, path.join(output, "vitest.config.mts")),
  ];
  expect(Object.keys(binding.fixtureInputs).sort()).toEqual(
    fixturePaths.sort(),
  );
  const verifyInputs = async () => {
    expect(digest(await fs.readFile(bindingPath))).toBe(digest(bindingBytes));
    for (const [relative, expected] of Object.entries({
      ...sourceMap,
      ...binding.fixtureInputs,
    })) {
      expect(digest(await fs.readFile(ownPath(relative)))).toBe(expected);
    }
    expect(digest(await fs.readFile(binary))).toBe(binding.executableSha256);
  };
  await verifyInputs();

  const temporaryParent = await fs.realpath(tmpdir());
  const directory = await fs.mkdtemp(
    path.join(temporaryParent, "farfold-p01-storage-bridge-"),
  );
  await fs.chmod(directory, 0o700);
  const directoryIdentity = await fs.lstat(directory);
  const uid = process.getuid!();
  const reportDirectory = await fs.mkdtemp(path.join(output, "run-"));
  await fs.chmod(reportDirectory, 0o700);
  const token = randomBytes(24).toString("hex");
  await fs.writeFile(
    path.join(directory, "fixture.marker.json"),
    JSON.stringify({ kind: "farfold-p01-storage-bridge-v1", token }),
    { flag: "wx", mode: 0o600 },
  );
  const calls: Array<Record<string, unknown>> = [];
  let phase = "initial";
  let fixtureRemoved = false;
  let cleanupError: string | null = null;
  let fault = false;
  let fullReceipt: string | null = null;
  const saved = "saved fixture draft🙂\nsecond paragraph";
  const edited = "x".repeat(48 * 1024) + "\nnewer local input retained";
  let success = false;
  let stopStartup: (() => void) | undefined;
  let exitBlocked = false;
  let exitLeaseReleased = false;
  let renderedFullError = false;

  const ownedFile = async (file: string, privateFile = false) => {
    const info = await fs.lstat(file);
    expect(info.isFile() && !info.isSymbolicLink()).toBe(true);
    expect(info.uid).toBe(uid);
    expect(info.nlink).toBe(1);
    if (privateFile) expect(info.mode & 0o777).toBe(0o600);
  };
  const ownDirectory = async () => {
    expect(path.dirname(directory)).toBe(temporaryParent);
    const now = await fs.lstat(directory);
    expect(now.isDirectory() && !now.isSymbolicLink()).toBe(true);
    expect([now.dev, now.ino, now.uid, now.mode & 0o777]).toEqual([
      directoryIdentity.dev,
      directoryIdentity.ino,
      uid,
      0o700,
    ]);
    await ownedFile(path.join(directory, "fixture.marker.json"), true);
    expect(await fs.readFile(path.join(directory, "fixture.marker.json"), "utf8")).toBe(JSON.stringify({ kind: "farfold-p01-storage-bridge-v1", token }));
  };
  const exchange = async (
    command: "settings_get" | "settings_set",
    value?: unknown,
    origin: "frontend" | "fixture-control" = "fixture-control",
  ) => {
    expect(calls.length).toBeLessThan(10);
    await ownDirectory();
    expect(digest(await fs.readFile(binary))).toBe(binding.executableSha256);
    const id = randomBytes(24).toString("hex");
    for (const name of ["request.json", "response.json"]) {
      const file = path.join(directory, name);
      const stat = await fs.lstat(file).catch(() => null);
      if (stat) {
        await ownedFile(file, true);
        await fs.unlink(file);
      }
    }
    const request = {
      id,
      token,
      command,
      key: "unsentWork.v1",
      read_only: false,
      limit_pages_to_current: command === "settings_set" && fault,
      ...(command === "settings_set" ? { value } : {}),
    };
    const requestBytes = Buffer.from(JSON.stringify(request), "utf8");
    expect(requestBytes.length).toBeLessThanOrEqual(65_536);
    await fs.writeFile(
      path.join(directory, "request.json"),
      requestBytes,
      { flag: "wx", mode: 0o600 },
    );
    const invocation = [
      driverName,
      "--exact",
      "--ignored",
      "--nocapture",
      "--test-threads=1",
    ];
    let stdout = "",
      stderr = "";
    try {
      ({ stdout, stderr } = await run(binary, invocation, {
        cwd: directory,
        timeout: 10_000,
        maxBuffer: 1024 * 1024,
      }));
    } catch (error) {
      const failure = error as { stdout?: string; stderr?: string };
      await fs.writeFile(
        path.join(reportDirectory, `failed-${calls.length + 1}.stdout.log`),
        failure.stdout ?? "",
        { mode: 0o600 },
      );
      await fs.writeFile(
        path.join(reportDirectory, `failed-${calls.length + 1}.stderr.log`),
        failure.stderr ?? "",
        { mode: 0o600 },
      );
      throw error;
    }
    const prefix = String(calls.length + 1).padStart(2, "0");
    await fs.writeFile(
      path.join(reportDirectory, `${prefix}.stdout.log`),
      stdout,
      {
        mode: 0o600,
      },
    );
    await fs.writeFile(
      path.join(reportDirectory, `${prefix}.stderr.log`),
      stderr,
      {
        mode: 0o600,
      },
    );
    expect(stdout).toContain("test result: ok. 1 passed; 0 failed;");
    await ownedFile(path.join(directory, "response.json"), true);
    const response = JSON.parse(
      await fs.readFile(path.join(directory, "response.json"), "utf8"),
    );
    expect(response.id).toBe(id);
    calls.push({ origin, phase, request, response, naturalExitCode: 0,
      stdoutSha256: digest(Buffer.from(stdout)), stderrSha256: digest(Buffer.from(stderr)) });
    await fs.writeFile(
      path.join(reportDirectory, `${prefix}.json`),
      JSON.stringify(calls.at(-1), null, 2) + "\n",
      { mode: 0o600 },
    );
    if (request.limit_pages_to_current) {
      expect(response.ok).toBe(false);
      expect(response.error).toMatch(/^FARFOLD_STORAGE:full:/);
      expect(response.testSqliteLimit.freePages).toBe(0);
      expect(response.testSqliteLimit.maxPageCount).toBe(response.testSqliteLimit.pageCount);
      expect(response.testSqliteLimit.pageSize).toBeGreaterThanOrEqual(512);
      expect(response.testSqliteLimit.pageSize).toBeLessThanOrEqual(4096);
    }
    if (!response.ok) {
      expect(typeof response.error).toBe("string");
      fullReceipt = response.error;
      throw response.error;
    }
    return response.value;
  };

  try {
    h.invoke.mockImplementation(async (command, input) => {
      if (command === "app_drafts_ready" || command === "app_exit_after_save")
        return;
      expect(input.key).toBe("unsentWork.v1");
      expect(["settings_get", "settings_set"]).toContain(command);
      return exchange(command, input.value, "frontend");
    });
    const d = await import("../../../src/runtime/drafts");
    const persistence = d.draftPersistence;
    await persistence.load();
    d.composerDrafts.update("new", () => ({ text: saved, attachments: [] }));
    await persistence.flush();
    const original = await exchange("settings_get");
    expect(original.composers.new.text).toBe(saved);

    phase = "sqlite-full";
    fault = true;
    d.composerDrafts.update("new", () => ({ text: edited, attachments: [] }));
    await expect(persistence.flush()).rejects.toThrow(/存储空间不足/);
    expect(fullReceipt).toMatch(/^FARFOLD_STORAGE:full:/);
    expect(await exchange("settings_get")).toEqual(original);
    expect(d.composerDrafts.read("new").text).toBe(edited);
    expect(persistence.snapshot().error).toContain("存储空间不足");
    expect(persistence.isSaved(persistence.revision())).toBe(false);

    const { DraftStartup } = await import("../../../src/components/DraftStartup");
    const { DRAFT_STRINGS } = await import("../../../src/runtime/draft_storage");
    const render = () => {
      h.stateCursor = 0;
      h.refCursor = 0;
      return DraftStartup({ children: "controlled editable content" });
    };
    render();
    stopStartup = h.effects[0]() as () => void;
    await vi.waitFor(() =>
      expect(h.invoke).toHaveBeenCalledWith("app_drafts_ready"),
    );
    const exits = () =>
      h.invoke.mock.calls.filter(
        ([command]) => command === "app_exit_after_save",
      );
    h.listeners.get("app:save-before-exit")!({ payload: 74 });
    expect(persistence.snapshot().interactionLocked).toBe(true);
    await vi.waitFor(() =>
      expect(persistence.snapshot().interactionLocked).toBe(false),
    );
    expect(exits()).toHaveLength(0);
    exitBlocked = true;
    exitLeaseReleased = true;
    const alert = nodes(render()).find(
      (node) =>
        isValidElement<{ role?: string }>(node) && node.props.role === "alert",
    );
    expect(
      nodes(alert)
        .filter((node) => typeof node === "string")
        .join(""),
    ).toContain("存储空间不足");
    renderedFullError = true;
    expect(d.composerDrafts.read("new").text).toBe(edited);
    expect(await exchange("settings_get")).toEqual(original);

    const beforeRetry = calls.length;
    fault = false;
    phase = "explicit-retry";
    await Promise.resolve();
    expect(calls).toHaveLength(beforeRetry);
    const retry = nodes(render()).find(
      (node) =>
        isValidElement<{ children?: ReactNode }>(node) &&
        node.type === "button" &&
        node.props.children === DRAFT_STRINGS.retry,
    );
    expect(isValidElement<{ onClick?: () => void }>(retry)).toBe(true);
    if (!isValidElement<{ onClick?: () => void }>(retry))
      throw new Error("actual retry button is missing");
    retry.props.onClick!();
    await vi.waitFor(() => expect(exits()).toHaveLength(1));
    expect(exits()[0]).toEqual(["app_exit_after_save", { token: 74 }]);
    expect(persistence.snapshot().error).toBeNull();
    expect(persistence.isSaved(persistence.revision())).toBe(true);
    const current = await exchange("settings_get");
    expect(current.composers.new.text).toBe(edited);
    stopStartup();
    stopStartup = undefined;
    expect(persistence.snapshot().interactionLocked).toBe(false);
    phase = "cold-module-read";
    vi.resetModules();
    const cold = await import("../../../src/runtime/drafts");
    await cold.draftPersistence.load();
    expect(cold.composerDrafts.read("new").text).toBe(edited);
    expect(
      h.invoke.mock.calls.every(([command]) =>
        [
          "settings_get",
          "settings_set",
          "app_drafts_ready",
          "app_exit_after_save",
        ].includes(command),
      ),
    ).toBe(true);
    expect(calls).toHaveLength(10);
    expect(calls.filter((call) => (call.request as { limit_pages_to_current: boolean }).limit_pages_to_current)).toHaveLength(2);
    await verifyInputs();
    success = true;
  } finally {
    stopStartup?.();
    try {
      await ownDirectory();
      const names = new Set([
        "fixture.marker.json", "request.json", "response.json", "fixture.sqlite3",
        "fixture.sqlite3-wal", "fixture.sqlite3-shm", "fixture.sqlite3-journal",
      ]);
      for (const name of await fs.readdir(directory)) {
        expect(names.has(name)).toBe(true);
        await ownedFile(path.join(directory, name));
      }
      await fs.rm(directory, { recursive: true });
      fixtureRemoved = true;
    } catch (error) {
      cleanupError = String(error);
      throw error;
    } finally {
    await fs.writeFile(
      path.join(reportDirectory, "result.json"),
      JSON.stringify(
        {
          passed: success && fixtureRemoved,
          bindingSha256: digest(bindingBytes),
          sourceInputMap: binding.sourceInputMap,
          sourceInputs: Object.keys(sourceMap).length,
          fixtureInputs: binding.fixtureInputs,
          driverName,
          executableSha256: binding.executableSha256,
          callCount: calls.length,
          fullReceipt,
          fixtureRemoved,
          cleanupError,
          exitCoordinator: {
            exitBlocked,
            exitLeaseReleased,
            renderedFullError,
            requests: h.invoke.mock.calls.filter(
              ([command]) => command === "app_exit_after_save",
            ),
            nativeExitExecuted: false,
          },
          scope:
            "GREEN-only coverage: real production MetaStore SQLITE_FULL from connection page-count limit, real frontend persistence and DraftStartup through controlled hooks/events and transport. Retry opens a new connection without the test limit; cold means module reset plus new SQLite connection. No product RED, physical disk-full, system quota, complete Tauri IPC, DOM/installed UI, native exit, Agent/model or whole-P01 proof. Ownership checks are not atomic against hostile same-UID replacement.",
        },
        null,
        2,
      ) + "\n",
      { mode: 0o600 },
    );
    console.info(`P01_CAPACITY_BRIDGE_RESULT ${reportDirectory}/result.json`);
    }
  }
});
