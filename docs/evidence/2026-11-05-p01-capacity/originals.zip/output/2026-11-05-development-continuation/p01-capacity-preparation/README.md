# P01容量故障：仅测试候选，尚未运行

本目录沿唯一计划P01“容量不足可恢复且不覆盖旧内容、不自动发送”补覆盖，不建立新验收队列。本轮已只读核实现，并按root后续授权准备test-only候选。没有Cargo、SQLite、Vitest、Agent、App或用户数据操作；driver-binding.json不存在，不可借用旧binary或旧binding直接执行。

## 可行性与最小改动

- 生产MetaStore以私有Mutex保存SQLite连接；同模块测试能调用lock。现有recovery_tests.rs:113–187已有max_page_count FULL/旧值保持和结构化full收据测试，本候选不复制这些后端单测。
- 仅扩展macOS cfg(test)且默认ignored的既有explicit_frontend_storage_bridge。Request增加默认false的固定limit_pages_to_current布尔量；只允许settings_set且read_only=false，不接受SQL、路径、任意页数或新设置key。serde deny_unknown_fields、65,536B、独占0700目录、600输入/输出、marker/token/UID/inode/单链接/白名单均保持。
- 仅在同一生产MetaStore连接上查询page_count/page_size/freelist_count，限定1..256页、512..4096字节页、零空闲页与至少48KiB序列化值，设置max_page_count为当前页数并读回。释放Mutex guard后直接走原生产set_setting；只有实际full收据才生成响应，附testSqliteLimit读数，不伪造错误。条件不符或未真实FULL就测试失败，不自动放宽或填盘。
- 前端fixture沿旧10交换退出桥的hooks/event/实际重试按钮结构，复用本批队列桥已有的真实binary/忽略清单/原始Cargo/源map绑定检查与归属清理。48KiB ASCII新稿及少量说明在每次请求真实JSON编码后核≤65,536B，远低于生产32MiB前端上限；仅测试临时SQLite页数限制。

## 候选断言

1. 正常保存小原稿并独立读回。写入48KiB新本地输入时，让production set_setting实际返回FARFOLD_STORAGE:full；全值读回仍等于旧稿，当前窗口新稿保持、isSaved=false、错误为存储空间不足。
2. 实际DraftStartup收到受控app:save-before-exit后再次遇到FULL：不派发app_exit_after_save，退出交互锁释放，实际alert保留容量原因，新稿不丢，旧盘值仍相同。只记录退出命令，不执行退出。
3. 明确关闭fixture故障开关后不自动写入；点实际重试按钮才在新连接无本次限额下保存，记录唯一退出请求。随后冷模块重置及新SQLite连接读回新稿。预计10次交换、其中两次真实FULL；次数须由后续实际结果确认。

## 绑定及后续执行

root须先全文审driver与fixture，再统一一次fresh Rust test编译。保留实际Cargo自然退出日志、精确新testbinary SHA、精确默认ignored清单及当前源输入map，再生成本目录driver-binding.json。绑定结构与上次queue-schema桥相同，fixtureInputs仅本目录frontend-capacity-exit.test.ts与vitest.config.mts；无自动构建、旧绑定fallback、环境变量或新依赖。精确拟执行命令（本轮未执行）：

```sh
corepack pnpm exec vitest run --config output/2026-11-05-development-continuation/p01-capacity-preparation/vitest.config.mts
```

仅执行了目标格式化和TypeScript AST语法/相对源码路径静态检查。首次rustfmt误用edition2021，实际Cargo是2024；最终已按edition2024重做，原回执保留。静态检查不等于Rust编译、语义typecheck或桥接GREEN。

## 结论边界

值得做：这是现有P01容量条件的一条小型联通补验，能填“真实SQLite FULL → 实际前端保存/退出失败 → 明确重试/冷读”的空白，复用已有传输而不加生产入口。它是GREEN补覆盖，不造产品RED。max_page_count只限制此临时SQLite连接的数据库页增长，不是物理磁盘满、系统配额、真实设备I/O或WAL/journal占用满盘。钩子/事件/传输受控；冷指模块重置+每请求新Rust进程/SQLite连接，不是App重启；不覆盖完整Tauri IPC、DOM/安装版错误界面、真实退出/恢复UI、附件重核、完整P01或29家八项。归属检查非原子，不能宣称抵抗同UID恶意替换。纯测试变化不要求重新安装Mac。
