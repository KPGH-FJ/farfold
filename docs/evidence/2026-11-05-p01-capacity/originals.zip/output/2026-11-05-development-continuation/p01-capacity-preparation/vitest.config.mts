import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  test: {
    include: [
      "output/2026-11-05-development-continuation/p01-capacity-preparation/frontend-capacity-exit.test.ts",
    ],
    testTimeout: 60_000,
  },
});
