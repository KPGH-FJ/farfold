import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  test: {
    include: [
      "output/2026-11-05-development-continuation/p01-queue-schema/sqlite-bridge/frontend-queue-schema.test.ts",
    ],
    testTimeout: 90_000,
  },
});
