import { execFile } from "node:child_process";
import { createHash, randomBytes } from "node:crypto";
import * as fs from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { expect, it, vi } from "vitest";

const h = vi.hoisted(() => ({ invoke: vi.fn() }));
vi.mock("@tauri-apps/api/core", () => ({
  invoke: h.invoke,
  Channel: class {
    onmessage = (_value: unknown) => {};
  },
}));

const run = promisify(execFile);
const output = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(output, "../../../..");
const driverName =
  "meta_store::recovery_tests::explicit_frontend_storage_bridge";
const key = "fixture-agent:/fixture:native";
const digest = (bytes: Uint8Array) =>
  createHash("sha256").update(bytes).digest("hex");
type Ref = { path: string; sha256: string };
type Binding = {
  bindingState: "BOUND";
  driverName: string;
  executable: string;
  executableSha256: string;
  defaultIgnoredVerified: boolean;
  cargoReceipt: Ref;
  cargoLog: Ref;
  ignoredListReceipt: Ref;
  ignoredListStdout: Ref;
  ignoredListStderr: Ref;
  sourceInputMap: Ref;
  sourceInputCount: number;
  fixtureInputs: Record<string, string>;
};

function ownPath(relative: string): string {
  expect(path.isAbsolute(relative)).toBe(false);
  expect(relative.split("/")).not.toContain("..");
  const absolute = path.resolve(root, relative);
  expect(absolute.startsWith(root + path.sep)).toBe(true);
  return absolute;
}
async function evidence(ref: Ref): Promise<Buffer> {
  expect(/^[a-f0-9]{64}$/.test(ref.sha256)).toBe(true);
  expect(
    ref.path.startsWith("output/") || ref.path.startsWith("docs/evidence/"),
  ).toBe(true);
  const bytes = await fs.readFile(ownPath(ref.path));
  expect(digest(bytes)).toBe(ref.sha256);
  return bytes;
}
function snapshot() {
  return {
    version: 1,
    composers: {
      "session:previous": {
        text: "previous synthetic unsent draft",
        attachments: [],
      },
    },
    choice: { agentId: null, cwd: null, service: null, config: {} },
    feedback: {},
    queues: {
      [key]: {
        blocks: [
          [
            {
              type: "text",
              text: "known synthetic queued input",
              _meta: { "official.future": { retained: true } },
            },
          ],
        ],
        uncertainIndex: 0,
        outcomeUnknown: true,
      },
    },
  };
}

it("rejects unknown queue schema read from real MetaStore, preserves its value, then explicitly loads a supported fixture and cold reads local input", async () => {
  // This file deliberately has no fallback to any old binding or automatic
  // Cargo build. Root supplies actual final build/list/map evidence first.
  const bindingPath = path.join(output, "driver-binding.json");
  const bindingBytes = await fs.readFile(bindingPath);
  const binding: Binding = JSON.parse(bindingBytes.toString("utf8"));
  expect(binding.bindingState).toBe("BOUND");
  expect(binding.driverName).toBe(driverName);
  expect(binding.defaultIgnoredVerified).toBe(true);
  expect(/^[a-f0-9]{64}$/.test(binding.executableSha256)).toBe(true);
  const binaryInfo = await fs.lstat(binding.executable);
  expect(binaryInfo.isFile() && !binaryInfo.isSymbolicLink()).toBe(true);
  const binary = await fs.realpath(binding.executable);
  expect(path.dirname(binary)).toBe(
    await fs.realpath(path.join(root, "src-tauri/target/debug/deps")),
  );
  expect(/^farfold_lib-[a-f0-9]+$/.test(path.basename(binary))).toBe(true);

  const cargoReceipt = JSON.parse(
    (await evidence(binding.cargoReceipt)).toString("utf8"),
  );
  expect(cargoReceipt.naturalExitCode ?? cargoReceipt.exitCode).toBe(0);
  expect(cargoReceipt.command[0]).toBe("cargo");
  expect(cargoReceipt.command).toContain("test");
  const cargoLog = (await evidence(binding.cargoLog)).toString("utf8");
  expect(cargoLog).toContain(path.basename(binary));
  const ignoredReceipt = JSON.parse(
    (await evidence(binding.ignoredListReceipt)).toString("utf8"),
  );
  expect(ignoredReceipt.naturalExitCode ?? ignoredReceipt.exitCode).toBe(0);
  expect(ignoredReceipt.command).toEqual([
    binary,
    driverName,
    "--exact",
    "--ignored",
    "--list",
  ]);
  const ignoredStdout = (
    await evidence(binding.ignoredListStdout)
  ).toString("utf8");
  expect(ignoredStdout).toContain(driverName + ": test");
  expect(ignoredStdout).toContain("1 test, 0 benchmarks");
  expect((await evidence(binding.ignoredListStderr)).length).toBe(0);

  const sourceMap = JSON.parse(
    (await evidence(binding.sourceInputMap)).toString("utf8"),
  ).files as Record<string, string>;
  expect(Object.keys(sourceMap)).toHaveLength(binding.sourceInputCount);
  for (const required of [
    "src/runtime/drafts.ts",
    "src/runtime/draft_storage.ts",
    "src/runtime/sessions.ts",
    "src-tauri/src/meta_store/recovery_tests.rs",
    "src-tauri/Cargo.toml",
    "src-tauri/Cargo.lock",
    "package.json",
    "pnpm-lock.yaml",
  ]) {
    expect(Object.hasOwn(sourceMap, required)).toBe(true);
  }
  const fixturePaths = [
    path.relative(root, path.join(output, "frontend-queue-schema.test.ts")),
    path.relative(root, path.join(output, "vitest.config.mts")),
  ];
  expect(Object.keys(binding.fixtureInputs).sort()).toEqual(
    fixturePaths.sort(),
  );
  const verifyInputs = async () => {
    expect(digest(await fs.readFile(bindingPath))).toBe(digest(bindingBytes));
    for (const [relative, expected] of Object.entries({
      ...sourceMap,
      ...binding.fixtureInputs,
    })) {
      expect(digest(await fs.readFile(ownPath(relative)))).toBe(expected);
    }
    expect(digest(await fs.readFile(binary))).toBe(binding.executableSha256);
  };
  await verifyInputs();

  const temporaryParent = await fs.realpath(tmpdir());
  const directory = await fs.mkdtemp(
    path.join(temporaryParent, "farfold-p01-storage-bridge-"),
  );
  await fs.chmod(directory, 0o700);
  const directoryIdentity = await fs.lstat(directory);
  const uid = process.getuid!();
  const token = randomBytes(24).toString("hex");
  const markerBytes = JSON.stringify({
    kind: "farfold-p01-storage-bridge-v1",
    token,
  });
  const markerPath = path.join(directory, "fixture.marker.json");
  await fs.writeFile(markerPath, markerBytes, { flag: "wx", mode: 0o600 });
  const reportDirectory = await fs.mkdtemp(path.join(output, "run-"));
  await fs.chmod(reportDirectory, 0o700);
  const calls: Array<Record<string, unknown>> = [];
  const frontendCalls: Array<{ phase: string; command: string }> = [];
  let phase = "unsupported";
  let passed = false;
  let oldLoadSucceeded = false;
  let fixtureRemoved = false;
  let cleanupError: string | null = null;

  const ownedFile = async (file: string, privateFile = false) => {
    const info = await fs.lstat(file);
    expect(info.isFile() && !info.isSymbolicLink()).toBe(true);
    expect(info.uid).toBe(uid);
    expect(info.nlink).toBe(1);
    if (privateFile) expect(info.mode & 0o777).toBe(0o600);
  };
  const ownDirectory = async () => {
    expect(path.dirname(directory)).toBe(temporaryParent);
    const now = await fs.lstat(directory);
    expect(now.isDirectory() && !now.isSymbolicLink()).toBe(true);
    expect([now.dev, now.ino, now.uid, now.mode & 0o777]).toEqual([
      directoryIdentity.dev,
      directoryIdentity.ino,
      uid,
      0o700,
    ]);
    await ownedFile(markerPath, true);
    expect(await fs.readFile(markerPath, "utf8")).toBe(markerBytes);
  };
  const exchange = async (
    origin: "frontend" | "fixture-control",
    command: "settings_get" | "settings_set",
    value?: unknown,
  ): Promise<unknown> => {
    expect(calls.length).toBeLessThan(8);
    await ownDirectory();
    expect(digest(await fs.readFile(binary))).toBe(binding.executableSha256);
    for (const name of ["request.json", "response.json"]) {
      const file = path.join(directory, name);
      if (await fs.lstat(file).catch(() => null)) {
        await ownedFile(file, true);
        await fs.unlink(file);
      }
    }
    const request = {
      token,
      id: randomBytes(24).toString("hex"),
      command,
      key: "unsentWork.v1",
      read_only: false,
      ...(command === "settings_set" ? { value } : {}),
    };
    await fs.writeFile(
      path.join(directory, "request.json"),
      JSON.stringify(request),
      { flag: "wx", mode: 0o600 },
    );
    const prefix = String(calls.length + 1).padStart(2, "0");
    let stdout = "";
    let stderr = "";
    try {
      ({ stdout, stderr } = await run(
        binary,
        [driverName, "--exact", "--ignored", "--nocapture", "--test-threads=1"],
        { cwd: directory, timeout: 10_000, maxBuffer: 1024 * 1024 },
      ));
    } catch (error) {
      const failed = error as { stdout?: string; stderr?: string };
      await fs.writeFile(
        path.join(reportDirectory, prefix + ".failed.stdout.log"),
        failed.stdout ?? "",
        { mode: 0o600 },
      );
      await fs.writeFile(
        path.join(reportDirectory, prefix + ".failed.stderr.log"),
        failed.stderr ?? "",
        { mode: 0o600 },
      );
      throw error;
    }
    await fs.writeFile(
      path.join(reportDirectory, prefix + ".stdout.log"),
      stdout,
      { mode: 0o600 },
    );
    await fs.writeFile(
      path.join(reportDirectory, prefix + ".stderr.log"),
      stderr,
      { mode: 0o600 },
    );
    expect(stdout).toContain("test result: ok. 1 passed; 0 failed;");
    const responsePath = path.join(directory, "response.json");
    await ownedFile(responsePath, true);
    const response = JSON.parse(await fs.readFile(responsePath, "utf8"));
    expect(response.id).toBe(request.id);
    calls.push({
      origin,
      phase,
      request,
      response,
      naturalExitCode: 0,
      stdoutSha256: digest(Buffer.from(stdout)),
      stderrSha256: digest(Buffer.from(stderr)),
    });
    await fs.writeFile(
      path.join(reportDirectory, prefix + ".json"),
      JSON.stringify(calls.at(-1), null, 2) + "\n",
      { mode: 0o600 },
    );
    if (!response.ok) throw new Error(String(response.error));
    return response.value;
  };

  try {
    // Two deliberately distinct owned fixture values. Replacing the former
    // with the latter is a test action, not an implemented recovery UI.
    const supportedBackup = snapshot();
    const unsupported = snapshot();
    Object.assign(unsupported.queues[key], {
      futureInput: { text: "unknown synthetic input must remain saved" },
    });
    await exchange("fixture-control", "settings_set", unsupported);
    h.invoke.mockImplementation(async (command, input) => {
      frontendCalls.push({ phase, command });
      expect(["settings_get", "settings_set"]).toContain(command);
      expect(input.key).toBe("unsentWork.v1");
      return exchange("frontend", command, input.value);
    });

    const d = await import("../../../../src/runtime/drafts");
    const loading = await Promise.allSettled([d.draftPersistence.load()]);
    oldLoadSucceeded = loading[0].status === "fulfilled";
    if (oldLoadSucceeded) {
      const { threads } = await import("../../../../src/runtime/sessions");
      threads.markOpenFailed(
        key,
        "fixture-agent",
        "/fixture",
        "native",
        "synthetic failed open",
      );
    }
    d.composerDrafts.update("new", () => ({
      text: "later local input retained through explicit fixture retry",
      attachments: [],
    }));
    const flushing = await Promise.allSettled([d.draftPersistence.flush()]);
    expect(await exchange("fixture-control", "settings_get")).toEqual(
      unsupported,
    );
    expect(loading[0].status).toBe("rejected");
    expect(flushing[0].status).toBe("rejected");
    expect(d.draftPersistence.snapshot().ready).toBe(false);
    expect(d.draftPersistence.snapshot().error).toBeTruthy();
    expect(d.composerDrafts.read("session:previous").text).toBe("");
    expect(d.composerDrafts.read("new").text).toBe(
      "later local input retained through explicit fixture retry",
    );
    expect(d.draftQueues.read(key)).toBeNull();
    expect(frontendCalls).toEqual([
      { phase: "unsupported", command: "settings_get" },
      { phase: "unsupported", command: "settings_get" },
    ]);

    phase = "supported-fixture-retry";
    await exchange("fixture-control", "settings_set", supportedBackup);
    await d.draftPersistence.load();
    const { threads } = await import("../../../../src/runtime/sessions");
    const thread = threads.markOpenFailed(
      key,
      "fixture-agent",
      "/fixture",
      "native",
      "synthetic failed open",
    );
    expect(thread.queued).toEqual(supportedBackup.queues[key].blocks);
    expect(thread.uncertainPrompt).toBe(thread.queued[0]);
    expect(thread.queuePaused).toBe("uncertain");
    expect(thread.historicalOutcomeUnknown).toBe(true);
    await d.draftPersistence.flush();
    expect(d.draftPersistence.snapshot().ready).toBe(true);
    expect(d.draftPersistence.snapshot().error).toBeNull();

    phase = "cold-module-read";
    vi.resetModules();
    const cold = await import("../../../../src/runtime/drafts");
    await cold.draftPersistence.load();
    expect(cold.composerDrafts.read("new").text).toBe(
      "later local input retained through explicit fixture retry",
    );
    expect(cold.composerDrafts.read("session:previous").text).toBe(
      supportedBackup.composers["session:previous"].text,
    );
    expect(cold.draftQueues.read(key)).toEqual(supportedBackup.queues[key]);
    expect(frontendCalls).toEqual([
      { phase: "unsupported", command: "settings_get" },
      { phase: "unsupported", command: "settings_get" },
      { phase: "supported-fixture-retry", command: "settings_get" },
      { phase: "supported-fixture-retry", command: "settings_set" },
      { phase: "cold-module-read", command: "settings_get" },
    ]);
    expect(calls).toHaveLength(8);
    await verifyInputs();
    passed = true;
  } finally {
    try {
      await ownDirectory();
      const names = new Set([
        "fixture.marker.json",
        "request.json",
        "response.json",
        "fixture.sqlite3",
        "fixture.sqlite3-wal",
        "fixture.sqlite3-shm",
        "fixture.sqlite3-journal",
      ]);
      for (const name of await fs.readdir(directory)) {
        expect(names.has(name)).toBe(true);
        await ownedFile(path.join(directory, name));
      }
      await fs.rm(directory, { recursive: true });
      fixtureRemoved = true;
    } catch (error) {
      cleanupError = String(error);
      throw error;
    } finally {
      await fs.writeFile(
        path.join(reportDirectory, "result.json"),
        JSON.stringify(
          {
            passed: passed && fixtureRemoved,
            driverName,
            executableSha256: binding.executableSha256,
            bindingSha256: digest(bindingBytes),
            sourceInputMap: binding.sourceInputMap,
            sourceInputs: Object.keys(sourceMap).length,
            fixtureInputs: binding.fixtureInputs,
            exchangeCount: calls.length,
            frontendCalls,
            oldLoadSucceeded,
            fixtureRemoved,
            cleanupError,
            scope:
              "GREEN-only production MetaStore/SQLite value transport plus real frontend draft/session functions. The frontend rejects unknown owned queue schema; SQLite itself is not forced into a fault. Supported backup replacement is fixture control, and cold means module reset plus a new Rust process/SQLite connection. No complete Tauri IPC, installed UI, real recovery UI, App restart, Agent/model/exit or whole-P01 proof; ownership checks do not claim atomic resistance to hostile same-UID replacement.",
          },
          null,
          2,
        ) + "\n",
        { mode: 0o600 },
      );
      console.info(
        "P01_QUEUE_SCHEMA_SQLITE_RESULT " +
          path.join(reportDirectory, "result.json"),
      );
    }
  }
});
