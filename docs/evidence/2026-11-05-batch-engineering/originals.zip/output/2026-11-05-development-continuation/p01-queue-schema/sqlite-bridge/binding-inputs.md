# P01未知队列字段：真实SQLite联通准备

状态：仅准备，未解析/编译/导入/运行本测试，未构建Rust、查询ignored list或绑定二进制。driver-binding.json故意缺失，不能借用旧binding。root仍负责稳定工程、真实二进制绑定和执行许可。

复用现有src-tauri/src/meta_store/recovery_tests.rs中的macOS默认ignored入口meta_store::recovery_tests::explicit_frontend_storage_bridge；不改driver、生产源码、依赖、环境变量、普通pnpm test或Windows CI。原2026-11-04的driver/bridge/退出桥原件保持。本批只补GREEN联通，不制造SQLite RED；原同字节RED仍是合成settings磁盘加实际前端调用链。

## 真实路径与固定边界

测试只创建系统临时目录下独占farfold-p01-storage-bridge-目录，0700；marker/token、请求及响应均0600。driver固定只访问该目录内fixture.sqlite3及固定请求文件，且只准unsentWork.v1的settings_get/set；每次请求启动一个精确ignored测试进程并新开SQLite连接，不启动Agent或模型。driver原有普通文件/UID/硬链接/符号链接检查保持。测试额外核目录设备/inode/UID和marker身份，清理只限这个自有目录；不宣称原子抵抗同UID恶意替换。

固定版预期恰8次交换：

1. fixture-control settings_set：将自有、含queue.futureInput的未知快照写入临时SQLite。
2. frontend settings_get：真实draftPersistence.load读取后，未知队列schema应在发布任何草稿/队列前拒绝。
3. frontend settings_get：保留later local input后，真实flush因load仍失败而拒绝；零frontend settings_set。
4. fixture-control settings_get：精确JSON值仍等于未知原值。
5. fixture-control settings_set：测试显式选择另一个预先构造的受支持backupfixture；这是测试控制，不是恢复UI，也不是应用自动删除未知字段。
6. frontend settings_get：明确load重试，保留本地新输入并恢复已知队列。实际threads.markOpenFailed再触发restoreQueue/emit；官方PromptBlock._meta必须保持。
7. frontend settings_set：真实flush保存完整新值。
8. frontend settings_get：重置前端模块后由全新Rust进程/SQLite连接冷读；本地新输入、旧已知草稿及完整队列/_meta保持。

若错误版本首次load意外成功，测试才走实际threads.markOpenFailed以暴露旧重写路径；这不是本批将要执行的RED。固定版首次load失败时不会进入该UI状态方法。成功分支仍执行该方法验证支持队列的普通重写兼容。Tauri invoke只替换为受控测试传输，不替换draft/session函数；任何非settings命令均立即失败，禁止Agent/模型/退出动作。

本用例没有制造SQLite readonly/FULL故障。它验证真实MetaStore取回未知JSON后，前端schema拒绝可阻止后续写入。冷读表示模块重置+新SQLite连接，不是正式应用重启；不代表完整IPC、安装UI、真实恢复UI、其他附件或完整P01。

## 等待root提供的真实binding

driver-binding.json只能在最终稳定工程完成后由root写入。不得填旧hash、虚构Cargo/list回执或默认猜计数。结构如下，所有路径是本仓库相对证据路径；executable是实际本机绝对路径：

    {
      "bindingState": "BOUND",
      "driverName": "meta_store::recovery_tests::explicit_frontend_storage_bridge",
      "executable": "/Users/tw/Desktop/farfold/src-tauri/target/debug/deps/farfold_lib-实际hash后缀",
      "executableSha256": "实际二进制SHA256小写",
      "defaultIgnoredVerified": true,
      "cargoReceipt": {"path": "实际最终Cargo命令JSON", "sha256": "实际SHA256"},
      "cargoLog": {"path": "实际最终Cargo日志含该libbinary名", "sha256": "实际SHA256"},
      "ignoredListReceipt": {"path": "实际ignored-list命令JSON", "sha256": "实际SHA256"},
      "ignoredListStdout": {"path": "实际ignored-list stdout", "sha256": "实际SHA256"},
      "ignoredListStderr": {"path": "实际ignored-list stderr", "sha256": "实际SHA256"},
      "sourceInputMap": {"path": "最终完整files map原件", "sha256": "实际SHA256"},
      "sourceInputCount": "实际整数，不预设2369或2370",
      "fixtureInputs": {
        "output/2026-11-05-development-continuation/p01-queue-schema/sqlite-bridge/frontend-queue-schema.test.ts": "最终测试字节SHA256",
        "output/2026-11-05-development-continuation/p01-queue-schema/sqlite-bridge/vitest.config.mts": "最终配置字节SHA256"
      }
    }

Cargo回执取现有实际最终命令，接受exitCode或naturalExitCode=0；不会为了本fixture新增Cargo构建。sourceInputMap应是root已核的完整最终声明输入，测试前后逐项核所有列出文件，并另外核本fixture两文件；不把该map扩称完整传递环境冻结。每次交换还核实际二进制SHA。ignored-list须是实际新binary运行以下精确参数的自然0原件，stdout恰含本driver的test声明及1 test, 0 benchmarks，stderr为空：

    实际libbinary meta_store::recovery_tests::explicit_frontend_storage_bridge --exact --ignored --list

绑定与协议审阅通过后唯一独立测试命令为：

    corepack pnpm exec vitest run --config output/2026-11-05-development-continuation/p01-queue-schema/sqlite-bridge/vitest.config.mts

此命令目前没有执行。配置仅收这一文件、单用例90秒界；每次driver子进程10秒，最多8次交换。普通pnpm test仍只收src/scripts。本fixture没有builder、自动安装、私有HOME或环境开关。

运行原件预期存本目录独占run-子目录（0700），每次request/response及自然退出的stdout/stderr/SHA回执0600；result明确scope和cleanup状态。失败原件保留，不覆盖旧轮记录。
