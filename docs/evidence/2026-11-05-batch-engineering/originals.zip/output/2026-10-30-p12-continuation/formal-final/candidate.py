# Private helper prepared without build, capture, installation, helper import or execution.
# Future dependency references use final helper names; no helper was executed or imported.
"""One exclusive internal candidate build; never install, launch, quit or access user data.
Usage: python3 -B candidate.py parameters.json <parameters-sha256>
Bundle/signature/ZIP checks reuse the prior candidate's explicit pure algorithms.
"""

# Root-authorized input binding only; preparation did not execute this candidate.
from datetime import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import stat
import subprocess
import sys
import time
import zipfile

ROOT = Path('/Users/tw/Desktop/farfold')
BASE = ROOT / 'output/2026-10-30-p12-continuation'
ENGINEERING = BASE / 'engineering-final'
PREP = BASE / 'formal-final'
OUT = PREP / 'candidate-output'
APP = ROOT / 'src-tauri/target/release/bundle/macos/Farfold.app'
FORMAL = Path('/Applications/Farfold.app')
BUILD = ['corepack', 'pnpm', 'tauri:build:internal', '--bundles', 'app']
SCOPES = ('src/', 'assets/', 'public/', 'scripts/', 'patches/', '.cargo/',
          'src-tauri/src/', 'src-tauri/native/', 'src-tauri/capabilities/',
          'src-tauri/icons/', 'src-tauri/resources/', 'src-tauri/.cargo/',
          '.github/', 'src-tauri/examples/')
FILES = {'Contents/Info.plist', 'Contents/MacOS/farfold', 'Contents/Resources/icon.icns',
         'Contents/Resources/release-manifest.json', 'Contents/_CodeSignature/CodeResources'}

AUTHORITY_NAMES = frozenset({'PRODUCT.md', 'docs/agent-access-requirements.md',
                             'docs/agent-first-release.md'})


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def regular(path, directory=False):
    need(all(not p.is_symlink() for p in (path, *path.parents)), 'Symlink refused')
    need(stat.S_ISDIR(path.stat().st_mode) if directory else stat.S_ISREG(path.stat().st_mode), 'Wrong file type')


def sha(path):
    regular(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def relative(name):
    need(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts, 'Relative path required')
    return ROOT / name


def pinned(name, expected, refs):
    path = relative(name)
    need(type(expected) is str and re.fullmatch('[0-9a-f]{64}', expected), 'SHA pin unbound')
    need(sha(path) == expected, 'Pinned evidence changed')
    refs[path] = expected
    return json.loads(path.read_bytes())


def run(argv):
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True)
    need(result.returncode == 0, f'{argv[0]} failed with exit {result.returncode}')
    return (result.stdout + result.stderr).strip()


def admitted(name):
    return any(name.startswith(scope) for scope in SCOPES) or bool(re.fullmatch(
        r'(package\.json|pnpm-lock\.yaml|pnpm-workspace\.yaml|index\.html|tsconfig[^/]*\.json|'
        r'[^/]+\.config\.[^/]+|\.npmrc|\.pnpmfile\.cjs|src-tauri/[^/]+\.(rs|json|toml|lock|plist))', name))


def production_source(commit, inputs):
    need(run(['git', 'rev-parse', 'HEAD']) == commit, 'HEAD differs from explicit commit')
    need(not any((ROOT / name).exists() or (ROOT / name).is_symlink() for name in
                 ('.env', '.env.local', '.env.production', '.env.production.local')), 'Unfrozen build environment file present')
    tree = {}
    raw = subprocess.run(['git', 'ls-tree', '-r', '-z', commit], cwd=ROOT, check=True, capture_output=True).stdout
    for entry in filter(None, raw.split(b'\0')):
        meta, name = entry.split(b'\t', 1); mode, kind, oid = meta.split(); name = name.decode()
        if admitted(name):
            need(kind == b'blob' and mode in (b'100644', b'100755'), 'Nonregular committed source')
            tree[name] = (mode, oid.decode())
    disk = set()
    for base in (ROOT, ROOT / 'src-tauri'):
        for path in base.iterdir():
            if admitted(str(path.relative_to(ROOT))) and (path.is_file() or path.is_symlink()):
                disk.add(str(path.relative_to(ROOT)))
    for scope in SCOPES:
        base = ROOT / scope
        if not base.exists():
            need(not base.is_symlink(), 'Broken source scope symlink'); continue
        regular(base, True)
        for path in base.rglob('*'):
            if path.name == '.DS_Store' or '__pycache__' in path.parts:
                continue
            regular(path, path.is_dir())
            if path.is_file():
                disk.add(str(path.relative_to(ROOT)))
    need(disk == set(tree) == set(inputs) and disk, 'Disk/commit/frozen production path set differs')
    hashes = {}
    for name in sorted(disk):
        path = ROOT / name; regular(path); data = path.read_bytes()
        mode, oid = tree[name]
        need(hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == oid, 'Uncommitted production source')
        need(bool(path.stat().st_mode & 0o111) == (mode == b'100755'), 'Source executable mode changed')
        hashes[name] = hashlib.sha256(data).hexdigest()
        need(inputs.get(name) == hashes[name], 'Production source differs from engineering input')
    need({'package.json', 'pnpm-lock.yaml', 'src-tauri/Cargo.toml', 'src-tauri/Cargo.lock'} <= disk, 'Required config missing')
    return hashes


def source(commit, inputs):
    """Verify the full engineering graph; only the exact authority set is split."""
    need(type(inputs) is dict and len(inputs) == 2333,
         'Full engineering source count differs')
    need({name for name in inputs if not admitted(name)} == AUTHORITY_NAMES,
         'Full engineering authority set differs')
    production = {name: pin for name, pin in inputs.items() if name not in AUTHORITY_NAMES}
    need(len(production) == 2330
         and len(inputs) == len(production) + len(AUTHORITY_NAMES), 'Production source count differs')
    hashes = production_source(commit, production)
    tree = {}
    raw = subprocess.run(['git', 'ls-tree', '-r', '-z', commit, '--', *sorted(AUTHORITY_NAMES)],
                         cwd=ROOT, check=True, capture_output=True).stdout
    for entry in filter(None, raw.split(b'\0')):
        meta, name = entry.split(b'\t', 1); mode, kind, oid = meta.split(); name = name.decode()
        need(name in AUTHORITY_NAMES and kind == b'blob' and mode in (b'100644', b'100755'),
             'Nonregular committed authority')
        tree[name] = (mode, oid.decode())
    need(set(tree) == AUTHORITY_NAMES, 'Committed authority set differs')
    for name in sorted(AUTHORITY_NAMES):
        path = relative(name); regular(path); data = path.read_bytes(); mode, oid = tree[name]
        need(hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == oid,
             'Uncommitted authority source')
        need(bool(path.stat().st_mode & 0o111) == (mode == b'100755'), 'Authority mode changed')
        need(hashlib.sha256(data).hexdigest() == inputs[name], 'Authority differs from final committed freeze')
    need(run(['git', 'rev-parse', 'HEAD']) == commit, 'HEAD changed during full source verification')
    return hashes


def verify_p12_progress(pre, post, frozen, engineering, commit, prep, read_evidence, check):
    """Recompute one bounded progress-cell delta; never execute checks or modify inputs."""
    from datetime import datetime as ProgressDateTime
    document = 'docs/agent-access-requirements.md'
    checked, final = pre['inputs'], frozen['inputs']
    check(checked == post['inputs'] and set(checked) == set(final), 'checked-final-input-members')
    check({name for name in final if final[name] != checked[name]} == {document}, 'only-p12-authority-may-differ')
    check({name: pin for name, pin in checked.items() if name not in AUTHORITY_NAMES}
          == {name: pin for name, pin in final.items() if name not in AUTHORITY_NAMES}, 'production-exact-to-seven')
    check(all(final[name] == checked[name] for name in AUTHORITY_NAMES - {document}), 'other-authority-exact-to-seven')
    check(frozen['kind'] == 'FinalCommittedBuildInputFreezeWithPostCheckP12Progress'
          and frozen['baseHead'] == commit
          and frozen['fullInputFreezeBeforeEngineeringChecks'] is False
          and frozen['checksRanBeforeCommitOnExactInputMap'] is False
          and frozen['checksRanAtFinalCommit'] is False
          and frozen['checkedInputMapExactlyEqualsFinalInputMap'] is False
          and frozen['productionInputsExactlyMatchSeven'] is True, 'honest-final-freeze-boundary')
    pins = {}
    def read(row):
        check(type(row) is dict and set(row) == {'path', 'sha256'}
              and type(row['path']) is str and type(row['sha256']) is str
              and re.fullmatch('[0-9a-f]{64}', row['sha256']), 'progress-evidence-reference')
        name = row['path']; path = Path(name)
        check(not path.is_absolute() and path.as_posix() == name and '..' not in path.parts, 'progress-evidence-scope')
        body = read_evidence(row)
        check(type(body) is bytes and len(body) <= 4 * 1024 * 1024
              and hashlib.sha256(body).hexdigest() == row['sha256'], 'progress-evidence-bytes')
        check(name not in pins or pins[name] == row['sha256'], 'progress-pin-conflict')
        pins[name] = row['sha256']; return body
    def expected_ref(row, name):
        check(row['path'] == name, 'progress-fixed-evidence-path')
        return read(row)
    prep_name = prep.relative_to(ROOT).as_posix()
    ref = frozen['postCheckAuthorityProgress']
    raw = expected_ref(ref, prep_name + '/post-check-authority-progress.json')
    delta = json.loads(raw)
    check(type(delta) is dict and set(delta) == {'kind', 'finalSourceCommit', 'checkedMap', 'scope',
          'before', 'after', 'progressCell', 'tools', 'checks', 'supplementalAuthority'}, 'progress-receipt-shape')
    check(delta['kind'] == 'PostCheckP12ProgressOnly' and delta['finalSourceCommit'] == commit
          and delta['checkedMap'] == engineering['sourceAfter']
          and delta['scope'] == {'path': document, 'taskId': 'P12', 'column': 3}, 'progress-receipt-scope')
    progress_name = BASE.relative_to(ROOT).as_posix() + '/post-engineering-progress'
    before = expected_ref(delta['before'], progress_name + '/agent-access-requirements.md.before')
    after = expected_ref(delta['after'], progress_name + '/agent-access-requirements.md.after')
    check(hashlib.sha256(before).hexdigest() == checked[document]
          and hashlib.sha256(after).hexdigest() == final[document], 'progress-before-after-map-links')
    cell = delta['progressCell']
    check(type(cell) is dict and set(cell) == {'old', 'new'}
          and all(type(cell[key]) is str and '\n' not in cell[key] and '\r' not in cell[key]
                  and '|' not in cell[key] for key in cell)
          and cell['old'] != cell['new'], 'progress-cell-shape')
    rows = before.splitlines(keepends=True)
    matches = [index for index, line in enumerate(rows) if re.match(rb'^\|\s*P12\s*\|', line)]
    check(len(matches) == 1, 'one-original-p12-row')
    index = matches[0]; pieces = rows[index].split(b'|')
    check(len(pieces) == 6 and pieces[3] == cell['old'].encode('utf-8'), 'exact-original-progress-cell')
    pieces[3] = cell['new'].encode('utf-8'); rows[index] = b'|'.join(pieces)
    check(b''.join(rows) == after, 'only-exact-p12-third-cell-bytes-changed')
    tools = delta['tools']
    tool_names = {'scripts/check-project-docs.mjs', 'scripts/agent-task-reference.mjs',
                  'docs/archive/2026-10-17-documentation-alignment/plan-conditions.json'}
    check(type(tools) is dict and set(tools) == tool_names, 'progress-check-tool-set')
    baseline = None
    for name, row in tools.items():
        body = expected_ref(row, name)
        if name in checked:
            check(row['sha256'] == checked[name] == final[name], 'progress-checker-not-changed')
        else:
            check(row['sha256'] == 'a5c231d101131af806b95ba174be1a7f6a360ae650912623b963a40159472b7e', 'original-condition-baseline-pin')
            baseline = json.loads(body)
    check(baseline['originalCount'] == len(baseline['rows']) == 151, 'all-original-conditions-retained')
    def conditions(body):
        found = {}
        for line in body.decode('utf-8').splitlines():
            if not re.match(r'^\|\s*(?:ARCH-\d+|NEW-\d+|P\d+|H\d+)\s*\|', line): continue
            cells = [part.strip() for part in line.split('|')[1:-1]]
            check(len(cells) in (3, 4) and cells[0] not in found, 'progress-condition-row-shape')
            found[cells[0]] = {'title': cells[1], 'completion': cells[-1]}
        return found
    check(conditions(before) == conditions(after) == baseline['rows'], 'exact-151-titles-and-completions')
    supplemental = delta['supplementalAuthority']
    check(type(supplemental) is dict and set(supplemental) == {'docs/status.md', 'plans/agent-access.md'}, 'supplemental-progress-set')
    final_doc_hashes = {document: final[document]}
    for name, row in supplemental.items():
        check(type(row) is dict and set(row) == {'sha256', 'gitBlob', 'mode'}
              and type(row['mode']) is int and row['mode'] in (0o644, 0o755), 'supplemental-pin-shape')
        body = read({'path': name, 'sha256': row['sha256']})
        blob = hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()
        tree = subprocess.run(['git', 'ls-tree', '-z', commit, '--', name], cwd=ROOT,
                              check=True, capture_output=True).stdout
        check(tree == ((('100755' if row['mode'] == 0o755 else '100644') + ' blob ' + blob + '\t' + name).encode() + b'\0')
              and row['gitBlob'] == blob and stat.S_IMODE((ROOT / name).stat().st_mode) == row['mode'], 'supplemental-final-git-bytes-mode')
        final_doc_hashes[name] = row['sha256']
    checks = delta['checks']
    check(type(checks) is dict and set(checks) == {'docsCheck', 'targetedFormat'}, 'post-check-command-set')
    format_targets = ['docs/status.md', 'plans/agent-access.md', document]
    commands = {'docsCheck': ['corepack', 'pnpm', 'docs:check'],
                'targetedFormat': ['corepack', 'pnpm', 'exec', 'prettier', '--check', *format_targets]}
    def instant(value):
        check(type(value) is str, 'progress-time-type')
        value = ProgressDateTime.fromisoformat(value.replace('Z', '+00:00'))
        check(value.tzinfo is not None, 'progress-time-zone'); return value
    for key, row in checks.items():
        check(type(row) is dict and set(row) == {'argv', 'exitCode', 'startedAt', 'finishedAt',
              'stdout', 'stderr', 'inputHashesBefore', 'inputHashesAfter'}, 'post-check-command-shape')
        check(row['argv'] == commands[key] and type(row['exitCode']) is int and row['exitCode'] == 0,
              'actual-post-check-argv-natural-integer-zero')
        check(row['inputHashesBefore'] == row['inputHashesAfter'] == final_doc_hashes, 'post-check-final-doc-endpoints')
        check(instant(engineering['recordedAt']) <= instant(row['startedAt']) <= instant(row['finishedAt'])
              <= instant(frozen['recordedAt']), 'post-check-time-order')
        leaf = 'docs-check-confirmed' if key == 'docsCheck' else 'targeted-format'
        output = expected_ref(row['stdout'], progress_name + '/' + leaf + '.stdout.raw')
        expected_ref(row['stderr'], progress_name + '/' + leaf + '.stderr.raw')
        if key == 'docsCheck':
            output = re.sub(rb'\x1b\[[0-9;]*m', b'', output)
            position = output.rfind(b'\n{')
            position = position + 1 if position >= 0 else output.find(b'{')
            check(position >= 0, 'docs-check-json-output')
            result = json.loads(output[position:])
            check(result['originalConditions'] == result['currentRows'] == 151
                  and result['activePlans'] == 1 and result['productAcceptanceClaimed'] is False,
                  'actual-docs-check-151-output')
    mode_refs = frozen['modeEvidence']
    check(type(mode_refs) is dict and set(mode_refs) == {'bindingPreflight', 'rootBefore', 'auditorAfter'}, 'mode-endpoint-reference-set')
    binding = json.loads(expected_ref(mode_refs['bindingPreflight'], ENGINEERING.relative_to(ROOT).as_posix() + '/binding-preflight.json'))
    root_before = json.loads(expected_ref(mode_refs['rootBefore'], ENGINEERING.relative_to(ROOT).as_posix() + '/root-invocation-preflight.json'))
    audited = json.loads(expected_ref(mode_refs['auditorAfter'], BASE.relative_to(ROOT).as_posix() + '/engineering-final-summary.json'))
    check(binding['head'] == root_before['head'] == engineering['baseHead']
          and binding['inputCount'] == root_before['allExpectedInputHashesAndModesMatch'] == len(checked)
          and set(binding['inputModes']) == set(checked), 'checked-mode-endpoint-links')
    check(all(value in ('0o644', '0o755') and stat.S_IMODE((ROOT / name).stat().st_mode) == int(value, 8)
              for name, value in binding['inputModes'].items()), 'current-modes-match-root-endpoint')
    check(audited['engineering'] == frozen['engineeringSummary'] and audited['sourceEvidence']['before'] == engineering['sourceBefore']
          and audited['sourceEvidence']['after'] == engineering['sourceAfter']
          and audited['modeEvidence']['bindingPreflightModeCount'] == audited['modeEvidence']['rootInvocationReportedModesMatching']
          == audited['modeEvidence']['currentAuditorModeComparisons'] == len(checked)
          and audited['modeEvidence']['currentModeDiscrepancies'] == []
          and audited['modeEvidence']['perCommandModeMapsOrChecksPresent'] is False
          and audited['modeEvidence']['noContinuousModeOrWriterClaim'] is True, 'root-mode-endpoints-not-per-command-continuity')
    return pins


def engineering_facts(config, commit):
    """Bind real seven checks and exact pre/post inputs to the later committed freeze."""
    need(set(config) == {'schema', 'receiptPath', 'sha256', 'committedFreeze'} and config['schema'] == 'p12-continuation-seven-v1', 'batch-engineering-config')
    pins = {}
    def seal(row):
        need(type(row) is dict and type(row.get('path')) is str and type(row.get('sha256')) is str and re.fullmatch('[0-9a-f]{64}', row['sha256']), 'engineering-evidence-reference')
        path = relative(row['path']); need(sha(path) == row['sha256'], 'engineering-evidence-drift')
        pins[row['path']] = row['sha256']; return path
    def read(row):
        return json.loads(seal(row).read_bytes())
    def instant(value):
        need(type(value) is str, 'engineering-time-type')
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        need(result.tzinfo is not None, 'engineering-time-zone')
        return result
    report = read({'path': config['receiptPath'], 'sha256': config['sha256']})
    freeze = read(config['committedFreeze'])
    need(report['kind'] == 'ActualSevenEngineeringChecksWithPreAndPostSourceFreeze' and report['sourceUnchanged'] is True and report['checksComplete'] is True and report['allSevenSucceeded'] is True, 'actual-seven-checks-scope')
    need(freeze['kind'] == 'FinalCommittedBuildInputFreezeWithPostCheckP12Progress' and freeze['baseHead'] == commit, 'final-source-freeze-scope')
    inputs = freeze['inputs']
    need(type(inputs) is dict and len(inputs) == freeze['inputCount'] == report['inputCount'] == 2333 and all(type(n) is str and (admitted(n) or n in AUTHORITY_NAMES) and type(h) is str and re.fullmatch('[0-9a-f]{64}', h) for n, h in inputs.items()), 'final-frozen-inputs')
    need({n for n in inputs if not admitted(n)} == AUTHORITY_NAMES and len(inputs) - len(AUTHORITY_NAMES) == 2330, 'final-authority-production-split')
    need(freeze['engineeringSummary'] == {'path': config['receiptPath'], 'sha256': config['sha256']}, 'engineering-freeze-reference-links')
    pre = read(report['sourceBefore']); post = read(report['sourceAfter'])
    need(pre['kind'] == 'PreEngineeringBuildInputFreeze' and post['kind'] == 'PostEngineeringBuildInputFreeze' and pre['baseHead'] == post['baseHead'] == report['baseHead'], 'engineering-pre-post-scope')
    need(pre['fullInputFreezeBeforeEngineeringChecks'] is True and post['fullInputFreezeBeforeEngineeringChecks'] is True and pre['inputs'] == post['inputs'] and pre['inputCount'] == post['inputCount'] == len(inputs), 'engineering-pre-post-inputs')
    progress_pins = verify_p12_progress(pre, post, freeze, report, commit, PREP, lambda row: seal(row).read_bytes(), need)
    pins.update(progress_pins)
    need(report['limits']['checksRanBeforeCommit'] is True and report['limits']['formalInstalled'] is False and report['limits']['realAffectedPathVerified'] is False and report['limits']['all29Accepted'] is False, 'engineering-proof-limits')
    commands = {
        'format': ['corepack', 'pnpm', 'format:check'],
        'typecheck': ['corepack', 'pnpm', 'typecheck'],
        'frontend-test-direct': ['corepack', 'pnpm', 'test'],
        'build': ['corepack', 'pnpm', 'build'],
        'cargo-fmt': ['cargo', 'fmt', '--check', '--manifest-path', 'src-tauri/Cargo.toml'],
        'cargo-clippy': ['cargo', 'clippy', '--manifest-path', 'src-tauri/Cargo.toml', '--locked', '--', '-D', 'warnings'],
        'cargo-test': ['cargo', 'test', '--manifest-path', 'src-tauri/Cargo.toml', '--locked']}
    need(type(report['checks']) is list and len(report['checks']) == 7, 'seven-check-count')
    rows = {row['check']: row for row in report['checks']}
    need(set(rows) == set(commands), 'seven-check-members')
    start, end = instant(pre['recordedAt']), instant(post['recordedAt'])
    need(start <= end <= instant(report['recordedAt']) <= instant(freeze['recordedAt']), 'engineering-freeze-time-order')
    logs = {}
    for name, argv in commands.items():
        row = rows[name]
        need(row['argv'] == argv and type(row['exitCode']) is int and row['exitCode'] == 0 and row['sourceInputsMatchBefore'] is True and start <= instant(row['startedAt']) <= instant(row['finishedAt']) <= end, 'actual-seven-command-result-time')
        chunks = []
        for stream in ('stdout', 'stderr'):
            path = seal({'path': row[stream], 'sha256': row[stream + 'Sha256']})
            chunks.append(path.read_bytes())
        logs[name] = re.sub(rb'\x1b\[[0-9;]*m', b'', b'\n'.join(chunks))
    front_files = re.search(rb'Test Files\s+(\d+) passed', logs['frontend-test-direct'])
    front_tests = re.search(rb'Tests\s+(\d+) passed', logs['frontend-test-direct'])
    rust = [dict(zip(('passed', 'failed', 'ignored'), map(int, row))) for row in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', logs['cargo-test'])]
    need(front_files and front_tests and int(front_files[1]) == 691 and int(front_tests[1]) == 9230, 'actual-frontend-test-summary')
    need(report['counts']['frontend'] == {'files': 691, 'passed': 9230, 'failed': 0} and rust == report['counts']['native'] and rust == [{'passed': 2326, 'failed': 0, 'ignored': 6}, {'passed': 0, 'failed': 0, 'ignored': 0}, {'passed': 0, 'failed': 0, 'ignored': 0}], 'actual-native-test-summary')
    need(all(sha(relative(name)) == pin for name, pin in pins.items()), 'engineering-evidence-final-drift')
    return {'finalInputs': inputs, 'evidencePins': pins}


def engineering(config, refs, commit):
    facts = engineering_facts(config, commit)
    refs.update({relative(name): pin for name, pin in facts['evidencePins'].items()})
    return facts['finalInputs']


def formal_baseline(config, refs):
    need(set(config) == {'receiptPath', 'sha256', 'sourceCommit', 'binarySha256'}, 'formal-baseline-config')
    baseline = pinned(config['receiptPath'], config['sha256'], refs)
    need(baseline['kind'] == 'ObservedStaticFormalBundleBaselineNotDataSnapshot' and baseline['sourceCommit'] == config['sourceCommit'] == '52aa8419ad402bf8b4e35dcf8cf2cd127706a4ea', 'formal-baseline-source')
    need((baseline['bundleId'], baseline['version'], baseline['platform'], baseline['appPath']) == ('ai.farfold.desktop', '0.1.7', 'darwin-arm64', str(FORMAL)), 'formal-baseline-identity')
    rows = baseline['files']
    need(type(rows) is dict and set(rows) == FILES, 'formal-baseline-exact-five')
    files, modes = {}, {}
    for name, row in rows.items():
        need(type(row) is dict and set(row) == {'sha256', 'bytes', 'mode', 'device', 'inode'} and type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}', row['sha256']) and all(type(row[k]) is int and row[k] >= 0 for k in ('bytes', 'mode', 'device', 'inode')), 'formal-baseline-file-record')
        value = (FORMAL / name).lstat()
        need(stat.S_ISREG(value.st_mode) and (value.st_size, stat.S_IMODE(value.st_mode), value.st_dev, value.st_ino) == (row['bytes'], row['mode'], row['device'], row['inode']), 'formal-baseline-file-identity-drift')
        files[name] = row['sha256']; modes[name] = row['mode']
    need(config['binarySha256'] == files['Contents/MacOS/farfold'] == 'e7afbdcee3b62a006454eb2f9ff9ac9f2165a0e6da322b9ab9446a128442bbbf' and bundle(FORMAL) == (files, modes), 'formal-baseline-content-drift')
    return {'candidateFiles': files, 'candidateModes': modes}


def bundle(path):
    regular(path, True); files, modes = {}, {}
    for item in sorted(path.rglob('*')):
        regular(item, item.is_dir())
        if item.is_file():
            name = str(item.relative_to(path)); files[name] = sha(item); modes[name] = stat.S_IMODE(item.stat().st_mode)
    need(set(files) == FILES, 'Bundle is not the exact five files')
    return files, modes


def identity():
    info = plistlib.loads((APP / 'Contents/Info.plist').read_bytes())
    need((info.get('CFBundleIdentifier'), info.get('CFBundleShortVersionString'), info.get('CFBundleExecutable')) == ('ai.farfold.desktop', '0.1.7', 'farfold'), 'Wrong app identity')
    need(info.get('CFBundleDevelopmentRegion') == 'zh_CN' and 'zh-Hans' in info.get('CFBundleLocalizations', []), 'Wrong localization')
    manifest = APP / 'Contents/Resources/release-manifest.json'
    need(sha(manifest) == sha(ROOT / 'src-tauri/resources/release-manifest.json') and json.loads(manifest.read_bytes())['version'] == '0.1.7', 'Embedded manifest differs')
    need(run(['lipo', '-archs', str(APP / 'Contents/MacOS/farfold')]) == 'arm64', 'Wrong architecture')
    verify = run(['codesign', '--verify', '--deep', '--strict', '--verbose=2', str(APP)])
    details = run(['codesign', '-d', '--verbose=4', str(APP)])
    need({'Signature=adhoc', 'Identifier=ai.farfold.desktop'} <= set(details.splitlines()), 'Wrong signature')
    return {'architecture': 'arm64', 'codesignVerify': verify, 'codesignDetails': details}


def exclusive(path):
    regular(path.parent, True)
    return os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600), 'wb')


def archive(path, files, modes):
    path.parent.mkdir(mode=0o700, exist_ok=False); regular(path.parent, True)
    with exclusive(path) as stream, zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED) as zipped:
        for name in sorted(files):
            zipped.write(APP / name, 'Farfold.app/' + name)
    with zipfile.ZipFile(path) as zipped:
        entries = zipped.infolist()
        need(zipped.testzip() is None and len(entries) == len(files) and {e.filename for e in entries} == {'Farfold.app/' + n for n in files}, 'ZIP CRC/membership differs')
        for entry in entries:
            name = entry.filename[len('Farfold.app/'):]; mode = entry.external_attr >> 16
            need(stat.S_ISREG(mode) and stat.S_IMODE(mode) == modes[name] and entry.file_size == (APP / name).stat().st_size and hashlib.sha256(zipped.read(entry)).hexdigest() == files[name], 'ZIP mode/payload differs')
    return {'archiveSha256': sha(path), 'archiveBytes': path.stat().st_size}


def main():
    need(Path(__file__).name == 'candidate.py', 'preparation-template-not-executable')
    need(len(sys.argv) == 3 and Path(__file__).absolute().parent == PREP, 'Expected parameter file and SHA')
    refs = {}; config_path = Path(sys.argv[1]).absolute(); regular(config_path)
    need(config_path.parent == PREP and '..' not in config_path.parts, 'Wrong parameter location')
    need(re.fullmatch('[0-9a-f]{64}', sys.argv[2]) and sha(config_path) == sys.argv[2], 'Parameter pin differs')
    refs[config_path] = sys.argv[2]; config = json.loads(config_path.read_bytes()); commit = config['sourceCommit']
    need(set(config) == {'schema', 'sourceCommit', 'engineering', 'formalBaseline'}, 'Unknown parameter schema')
    need(config['schema'] == 1 and commit == '4b40c09932daad2e718b5f98e0a75eccc5f84dd7', 'Real source commit unbound')
    inputs = engineering(config['engineering'], refs, commit)
    formal = formal_baseline(config['formalBaseline'], refs)
    formal = (formal['candidateFiles'], formal['candidateModes'])
    before = source(commit, inputs); need(not APP.exists() and not APP.is_symlink(), 'Duplicate App already exists; preserve it')
    need(all(not p.is_symlink() for p in APP.parents), 'Candidate destination symlink refused')
    OUT.mkdir(mode=0o700, exist_ok=False); regular(OUT, True)
    record = {'phase': 'failed', 'sourceCommit': commit, 'startedAtUnix': time.time(), 'buildCommand': BUILD, 'installed': False, 'formalAppReplaced': False, 'engineeringLimitations': {'checkedFullInputFreezeBeforeChecks': True, 'checksRanAtFinalCommit': False, 'finalFullMapMatchesSeven': False, 'productionContinuity': 'exact-2330-checked-pre-post-and-final-input-equality', 'authorityProgressOnly': 'requirements-P12-third-cell-with-natural-docs-and-format-receipts', 'modeEvidence': 'Root-endpoints-and-current-Git-mode-only; no-per-command-mode-continuity'}}
    with exclusive(OUT / 'candidate.json') as receipt:
        try:
            lock_path = ROOT / 'src-tauri/target/.farfold-candidate-build.lock'
            regular(lock_path.parent, True)
            with os.fdopen(os.open(lock_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600), 'r+b') as lock:
                need(os.fstat(lock.fileno()).st_uid == os.getuid() and stat.S_ISREG(os.fstat(lock.fileno()).st_mode), 'Invalid candidate lock')
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                need(source(commit, inputs) == before and bundle(FORMAL) == formal and not APP.exists(), 'Prebuild drift')
                with exclusive(OUT / 'build.log') as log:
                    result = subprocess.run(BUILD, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
                record.update(buildExitCode=result.returncode, buildLogSha256=sha(OUT / 'build.log'))
                need(result.returncode == 0, 'Candidate build failed; preserve log and partial App')
                need(source(commit, inputs) == before, 'Production source changed during build')
                record.update(identity()); files, modes = bundle(APP)
                archive_path = ROOT / f'src-tauri/target/internal-candidate/p12-continuation-{commit[:8]}/Farfold-0.1.7-{commit[:8]}.zip'
                record.update(archive=str(archive_path.relative_to(ROOT)), **archive(archive_path, files, modes))
                need(bundle(APP) == (files, modes) and source(commit, inputs) == before and bundle(FORMAL) == formal, 'Final source/bundle/formal drift')
                need(all(sha(p) == pin for p, pin in refs.items()), 'Pinned evidence changed during build')
                record.update(phase='internalCandidatePreparedNotInstalled', productionInputs=before, candidateFiles=files, candidateModes=modes, evidencePins={str(p.relative_to(ROOT)): pin for p, pin in refs.items()})
        except Exception as error:
            record['error'] = str(error)
        finally:
            record['completedAtUnix'] = time.time(); receipt.write((json.dumps(record, ensure_ascii=False, indent=2) + '\n').encode()); receipt.flush(); os.fsync(receipt.fileno())
    print(json.dumps({'phase': record['phase'], 'receipt': str((OUT / 'candidate.json').relative_to(ROOT))}))
    return 0 if record['phase'] == 'internalCandidatePreparedNotInstalled' else 1


if __name__ == '__main__':
    raise SystemExit(main())
