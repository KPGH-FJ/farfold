"""Explicit one-time test-binary build; never part of ordinary frontend CI."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess
import time

ROOT = Path("/Users/tw/Desktop/farfold")
OUT = ROOT / "output/2026-11-04-p01-storage-bridge"
DRIVER = "meta_store::recovery_tests::explicit_frontend_storage_bridge"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    files = set((ROOT / "src-tauri/src").rglob("*.rs"))
    files.update((ROOT / "src-tauri/native").rglob("*.m"))
    files.update(ROOT / name for name in [
        "package.json", "pnpm-lock.yaml", "src-tauri/Cargo.toml", "src-tauri/Cargo.lock",
        "src-tauri/build.rs", "src/runtime/drafts.ts", "src/runtime/draft_storage.ts",
        "src/runtime/storage_recovery.ts", "vitest.config.ts",
    ])
    files.update(OUT / name for name in ["frontend-storage-bridge.test.ts", "vitest.config.mts", "build-driver.py"])
    return {path.relative_to(ROOT).as_posix(): sha(path) for path in sorted(files)}


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    (OUT / name).chmod(0o600)


before = snapshot()
save("source-before.json", {"files": before})
command = ["cargo", "test", "--manifest-path", "src-tauri/Cargo.toml", "--locked", "--lib", "--no-run", "--message-format=json"]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
with (OUT / "cargo-no-run.stdout.jsonl").open("xb") as stdout, (OUT / "cargo-no-run.stderr.log").open("xb") as stderr:
    result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
after = snapshot()
save("source-after.json", {"files": after})
changes = [name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]
save("cargo-no-run.result.json", {"command": command, "startedAt": started, "finishedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(), "durationSeconds": round(time.monotonic() - clock, 3), "naturalExitCode": result.returncode, "sourceChangesAtEndpoints": changes})
if result.returncode:
    raise SystemExit(result.returncode)
assert not changes, "Inputs changed; keep original evidence and review the actual scope"
artifacts = []
for line in (OUT / "cargo-no-run.stdout.jsonl").read_text().splitlines():
    row = json.loads(line)
    if row.get("reason") == "compiler-artifact" and row.get("profile", {}).get("test") and row.get("target", {}).get("name") == "farfold_lib" and row.get("executable"):
        artifacts.append(row)
assert len(artifacts) == 1
artifact = artifacts[0]
binary = Path(artifact["executable"])
assert binary.parent == ROOT / "src-tauri/target/debug/deps" and binary.is_file() and not binary.is_symlink()
listing = subprocess.run([str(binary), DRIVER, "--exact", "--ignored", "--list"], cwd=ROOT, capture_output=True, text=True, timeout=10)
(OUT / "ignored-driver-list.stdout.log").write_text(listing.stdout)
(OUT / "ignored-driver-list.stderr.log").write_text(listing.stderr)
assert listing.returncode == 0 and f"{DRIVER}: test" in listing.stdout and "1 test, 0 benchmarks" in listing.stdout
save("driver-binding.json", {"driverName": DRIVER, "executable": str(binary), "executableSha256": sha(binary), "defaultIgnoredVerified": True, "ignoredListNaturalExitCode": listing.returncode, "artifactTarget": artifact["target"], "artifactProfile": artifact["profile"], "sourceInputs": len(after), "sourceEndpointHashesMatch": True, "scope": "Explicit current-host test build only; no app, Agent, installed validation or all-platform freeze claim."})
print(json.dumps({"naturalExitCode": 0, "executable": str(binary), "defaultIgnoredVerified": True, "sourceInputs": len(after)}))
