import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: [
      "output/2026-11-04-p01-storage-bridge/frontend-storage-bridge.test.ts",
    ],
    testTimeout: 60_000,
  },
});
