#![cfg_attr(test, allow(dead_code))]
#[cfg(test)]
mod windows_process {
    pub(crate) const DEBUG_MEMBER_LIMIT: usize = 256;
}
#[cfg(test)]
mod process_platform {
    use std::{io, os::windows::io::BorrowedHandle};
    pub(crate) struct OwnedGroup;
    impl OwnedGroup {
        pub(crate) fn debugged_members_inactive<'a>(
            &self,
            _child: BorrowedHandle<'_>,
            _members: impl Iterator<Item = BorrowedHandle<'a>> + Clone,
        ) -> io::Result<bool> {
            Ok(false)
        }
    }
}
#[cfg(test)]
mod worktrees {
    #[path = "/Users/tw/Desktop/farfold/src-tauri/src/worktrees/git_command_observation_tests.rs"]
    pub(super) mod command_observation;
    #[path = "/Users/tw/Desktop/farfold/src-tauri/src/worktrees/git_debug_windows.rs"]
    mod debug_windows;
    fn actual_caller_timer_method_signature(owner: &mut debug_windows::DebugProcesses) {
        owner.observe_poll_sleep(std::time::Duration::ZERO);
    }
}

#[cfg(all(test, windows))]
mod lifecycle_observer_field {
    use std::sync::Arc;
#[cfg(all(test, windows))]
pub(super) type RetirementObserver = Arc<dyn Fn(serde_json::Value) + Send + Sync>;
    pub(crate) struct ConnectionLife {
    #[cfg(all(test, windows))]
    pub(super) retirement_observer: Arc<std::sync::OnceLock<RetirementObserver>>,
    }
}
