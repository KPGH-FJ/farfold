# 新鲜拒绝与失效审阅的呈现

仅 `SkillChangeReview.tsx` 的状态提示改变，另补既有两份测试；controller、协议生命周期、错误码白名单、权限和三份实际 DTO 均保持。基线与三个冻结源码 hash 在 `source-final.json`，不虚构已提交的功能 commit。

三类来源拒绝都是明确 inspect failed/settled、无原 review、无写入并有具体原因，原 UI 却统一加“此次审阅已失效。要修改，请重新查询清单并审阅。”。实际 controller 首次接收时 reviewRetired=false；收起的 retire 又会将它置 true，即使从未有过 review，因此不能只看这个标志区分。

先在旧生产文件上跑 3 DTO × 首次显示/实际 retire 后重显示，6 项仅因多余失效提示失败；另 6 项通过。两份测试在 RED 前已格式化，原 DTO 与测试字节到 GREEN 完全相同。最小 UI 谓词限定明确终态 failed、op.review=null、无写入、具体 code 与 view.error 一致，只省略通用失效段，原错误段及其他状态优先级保留。GREEN 为 2 文件 12/12，包含真正 ready review 到期或撤销仍提示失效的两个实际 controller 控制；另有 6 文件 41/41 关联测试、typecheck、三文件格式与 diff --check 均自然 0。原命令和日志在 `checks/`。

这里的收起后重显示测试实际调用 controller.retire 并 SSR 渲染保留的请求状态，不冒称 DOM 点击或浏览器负测。未增加 DOM 依赖或模拟焦点框架。root 随后在同一字节的既有真实浏览器夹具完成本次 3 类原因 × 打开/收起/再打开的 9 个实际 DOM 观察；新原件 `../mcp-browser-ui/browser-refusal-final.json` 逐条核实：打开与再打开只显示一条对应原因，没有失效提示，焦点为 H5；收起焦点为 BUTTON，展开宽度未溢出。read3/inspect3，confirm/native0，既有夹具记录并拒绝的 cleanup cancel 尝试共5，不能称全部端口零调用。截图 hash 与原 DOM hash 记在 summary。真实 ready review 过期/撤销仍只有前述 SSR 控制，没有浏览器负测。此前焦点修复的旧9观察保持原字节范围，不冒称它们是这次结果。

只声明本次实际覆盖；本线没有运行完整前端、完整七项、Cargo、构建、浏览器、正式应用或真实 Agent/账号/模型，未写用户配置。旧工程检查的 Rust 声明输入逐 hash 保持，后续受影响批检查由 root 统筹。本 UI 修正不代表实际官方配置采用、MCP 连接或工具调用。
