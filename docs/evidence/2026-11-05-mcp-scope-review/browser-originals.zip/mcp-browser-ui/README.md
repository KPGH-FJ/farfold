# MCP浏览器组件夹具

仅准备，未编译、启动服务器或浏览器、操作正式App，也未连接Agent/模型。正式Mac界面仍待解锁，本页不能替代安装版验证。

fixture.test.html加载fixture.test.tsx，复用实际inventory/controller、MCP端口、SkillChangeReview和原styles.css/product-shell.css及组件自带CSS。三份输入直接导入src/runtime/fixtures/mcp-scope-refusals-wire.json；只在本测试文件替换read/inspect端口并按原DTO两枚UUID回放，不改任何DTO字段、不引入Vitest浏览器运行库。重复按钮是同一固定DTO的测试回放，不代表新的后端操作。

页面有三个明确按钮：项目／继承／多处设置原因。由root通过Cua在DOM中操作，核实际原因文字、无确认按钮、无横向裁切或空白，以及原inline组件的“关闭／查看MCP修改状态”与实际焦点。SkillChangeReview没有宿主Escape处理；本fixture不添加WorkspaceDialog或手写Escape行为，不把Escape关闭设为成功门槛。不能据此证明完整AgentDetails的关闭或焦点行为。

可见fixture-receipt记录当前case、累计read/inspect/confirm/native/otherPorts计数、拒绝调用名、fixture错误与当前焦点文字。每个正常新case应累计新增read1/inspect1，confirm/native/otherPorts保持0；“关闭／再查看”不增加传输调用。确认和其他MCP/inventory动作全部记录并拒绝；本页Tauri兜底只记录command名称并拒绝，不记录参数、读取凭据或触发真实native操作。页面未挂载App、DraftStartup或账号/Agent初始化流程。

root全文审阅、完整七项与SQLite补验完成后，才可启动已授权的本机loopback Vite，并在IAB打开：
http://127.0.0.1:<root选择端口>/output/2026-11-05-development-continuation/mcp-browser-ui/fixture.test.html

本次没有执行上述步骤。原pnpm test仅收src/scripts，普通构建仍以根index.html为入口；没有改测试、构建、依赖或环境配置。结果只能记为真实浏览器DOM组件层＋受控端口，不是完整Tauri IPC、实际官方CLI、配置采用/连接/工具调用或正式安装App。

## 实际执行补记

2026-11-05已执行，以上“仅准备”描述为原准备状态。初次默认扫描碰到历史output夹具语法错误，停止自有服务器后改用本目录私有Vite配置，仅扫描本页；生产配置未改。真实浏览器发现并修复再展开丢焦点，同字节夹具3case×3状态核合。收起有既有MCP撤销、切case有清单撤销；原“关闭后零端口”预期过严，实际逐条记录并拒绝，不据此改生产或称后台取消成功。确认/native均0。当前owned服务器和临时页已关闭。详见browser-summary.json及browser-original/final.json、截图。
