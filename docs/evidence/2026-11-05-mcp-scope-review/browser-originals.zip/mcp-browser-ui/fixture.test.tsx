import { useEffect, useState, useSyncExternalStore } from "react";
import { createRoot } from "react-dom/client";
import actualWire from "../../../src/runtime/fixtures/mcp-scope-refusals-wire.json";
import type { InventoryOperation } from "../../../src/runtime/extension_inventory_types";
import type { InventoryOwner } from "../../../src/runtime/extension_inventory_controller";
import type { McpChangeOperation } from "../../../src/runtime/mcp_management_types";
import { extensionInventory } from "../../../src/runtime/extension_inventory_controller";
import { inventoryPort } from "../../../src/runtime/extension_inventory";
import { skillManagement } from "../../../src/runtime/skill_management_controller";
import { mcpManagementPort } from "../../../src/runtime/mcp_management";
import { SkillChangeReview } from "../../../src/components/SkillChangeReview";
import "../../../src/styles.css";
import "../../../src/product-shell.css";

type Case = "project" | "inherited" | "conflict";
type Wire = { case: Case; inventory: InventoryOperation; operation: McpChangeOperation };
const wires = actualWire as unknown as Wire[];
const labels: Record<Case, string> = {
  project: "打开项目设置原因",
  inherited: "打开继承设置原因",
  conflict: "打开多处设置原因",
};
const receipt = {
  fixture: "浏览器组件夹具，非正式应用",
  case: "none",
  read: 0,
  inspect: 0,
  confirm: 0,
  native: 0,
  otherPorts: 0,
  denied: [] as string[],
  error: "",
};
let revision = 0;
const listeners = new Set<() => void>();
const subscribe = (fn: () => void) => {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
};
const changed = () => { revision++; listeners.forEach((fn) => fn()); };
const need = (ok: unknown, message: string) => {
  if (!ok) throw new Error(message);
};
const denied = (kind: "confirm" | "native" | "otherPorts", command: string): never => {
  receipt[kind]++;
  receipt.denied.push(kind + ":" + command); // Never record native arguments.
  changed();
  throw { code: "invalidRequest" };
};
// Backstop for every un-replaced native call in this isolated test page.
Object.defineProperty(window, "__TAURI_INTERNALS__", {
  configurable: true,
  value: {
    invoke: async (command: string) => denied("native", command),
    transformCallback: () => denied("native", "transformCallback"),
  },
});
let active: Wire | null = null;
let currentOwner: InventoryOwner | null = null;
inventoryPort.read = async (input) => {
  receipt.read++; changed();
  need(active && input.kind === "mcp" &&
    input.agentId === active.inventory.agentId &&
    input.cwd === active.inventory.cwd &&
    input.requestId === active.inventory.requestId, "fixture inventory identity");
  return structuredClone(active!.inventory);
};
inventoryPort.status = async () => denied("otherPorts", "inventory.status");
inventoryPort.cancel = async () => denied("otherPorts", "inventory.cancel");
mcpManagementPort.inspect = async (input) => {
  receipt.inspect++; changed();
  const op = active?.operation;
  const request = input as unknown as Record<string, unknown>;
  need(op && request.agentId === op.agentId && request.requestId === op.requestId &&
    request.inventoryRequestId === op.target.inventoryRequestId &&
    request.itemId === op.target.itemId && request.enabled === op.requestedEnabled,
    "fixture inspect identity");
  return structuredClone(op!);
};
mcpManagementPort.confirm = async () => denied("confirm", "mcp.confirm");
mcpManagementPort.status = async () => denied("otherPorts", "mcp.status");
mcpManagementPort.cancel = async () => denied("otherPorts", "mcp.cancel");
mcpManagementPort.recheck = async () => denied("otherPorts", "mcp.recheck");

function waitForState(subscribeTo: typeof subscribe, ready: () => boolean) {
  return new Promise<void>((resolve, reject) => {
    const check = () => {
      if (ready()) { stop(); clearTimeout(timer); resolve(); }
    };
    const stop = subscribeTo(check);
    const timer = setTimeout(() => {
      stop(); reject(new Error("fixture controller did not settle"));
    }, 3000);
    check();
  });
}
function Fixture() {
  useSyncExternalStore(subscribe, () => revision);
  const [selected, setSelected] = useState<{
    wire: Wire; owner: InventoryOwner; round: number;
  } | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    document.addEventListener("focusin", changed);
    return () => document.removeEventListener("focusin", changed);
  }, []);
  async function open(wire: Wire) {
    setBusy(true);
    receipt.error = ""; receipt.case = wire.case;
    if (currentOwner) {
      skillManagement.retire(currentOwner);
      extensionInventory.retire(currentOwner);
    }
    active = wire;
    const owner: InventoryOwner = {
      agentId: wire.operation.agentId, token: {},
      current: () => currentOwner === owner,
    };
    currentOwner = owner;
    setSelected({ wire, owner, round: revision });
    const originalUuid = crypto.randomUUID;
    const ids = [wire.inventory.requestId, wire.operation.requestId];
    // Replay the original DTO IDs only here; no public field is normalized.
    crypto.randomUUID = () => {
      const id = ids.shift();
      need(id, "unexpected extra UUID request");
      return id as ReturnType<Crypto["randomUUID"]>;
    };
    try {
      need(extensionInventory.begin(owner, wire.operation.cwd,
        wire.inventory.requestId, "mcp"), "fixture inventory admission");
      await waitForState(extensionInventory.subscribe,
        () => !extensionInventory.get(owner.agentId).unresolved);
      const result = extensionInventory.get(owner.agentId).results.mcp;
      need(result?.snapshot.items[0], "fixture inventory result");
      need(skillManagement.inspect({
        owner, result: result!, item: result!.snapshot.items[0],
        requestedEnabled: false,
        current: () => extensionInventory.isCurrentResult(owner, result!),
        changed: () => extensionInventory.markStale(result!),
      }), "fixture inspect admission");
      await waitForState(skillManagement.subscribe,
        () => !skillManagement.get(owner.agentId).unresolved);
      const view = skillManagement.get(owner.agentId);
      need(view.operation?.code === wire.operation.code && view.review === null,
        "fixture refused operation mismatch");
      need(ids.length === 0, "fixture UUID sequence");
    } catch (error) {
      receipt.error = error instanceof Error ? error.message : "fixture transport rejected";
    } finally {
      crypto.randomUUID = originalUuid;
      setBusy(false); changed();
    }
  }
  const focus = document.activeElement instanceof HTMLElement
    ? document.activeElement.textContent?.trim().slice(0, 100) : "";
  return (
    <main style={{ maxWidth: 780, margin: "0 auto", padding: 24,
      height: "100%", overflow: "auto", boxSizing: "border-box" }}>
      <h1>MCP 原因 · 浏览器组件夹具</h1>
      <p>非正式应用。回放已有真实 Rust DTO，端口替换；不连接程序、不修改配置。</p>
      <p>仅测下方原 inline 组件的关闭／再查看；不验证宿主 Escape。</p>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        {(["project", "inherited", "conflict"] as const).map((name) => (
          <button className="btn" type="button" data-case={name} key={name}
            disabled={busy} onClick={() => void open(wires.find((w) => w.case === name)!)}>
            {labels[name]}
          </button>
        ))}
      </div>
      <div id="actual-component">
        {selected && <SkillChangeReview key={selected.round}
          agentId={selected.owner.agentId} owner={selected.owner} active />}
      </div>
      <h2>仅本页回执（累计调用次数）</h2>
      <pre id="fixture-receipt" style={{ whiteSpace: "pre-wrap",
        overflowWrap: "anywhere", userSelect: "text" }}>
        {JSON.stringify({ ...receipt, focus }, null, 2)}
      </pre>
    </main>
  );
}
createRoot(document.getElementById("root")!).render(<Fixture />);
