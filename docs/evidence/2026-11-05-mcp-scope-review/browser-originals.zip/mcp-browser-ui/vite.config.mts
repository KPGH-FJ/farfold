import { defineConfig, mergeConfig } from "vite";
import base from "../../../vite.config";
export default defineConfig(mergeConfig(base, {
  optimizeDeps: { entries: ["output/2026-11-05-development-continuation/mcp-browser-ui/fixture.test.html"] },
}));
