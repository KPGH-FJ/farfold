# MCP 审阅重新打开焦点：候选证据

仅 `src/components/SkillChangeReview.tsx` 改变。基线 `603056dd11baea68a438f686ee83f96d89377ba4`，生产文件从 `91b58c649fcab09da891b40102d669018ee41078d04a7d4ce18e865b440a9889` 变为 `47f70694de1e9ec05b805574224366359e4ebaf4ed7e05e21888715ebd280bed`。未提交；本目录不代表正式应用已更新。

原问题由 root 在真实浏览器组件夹具发现：收起后重新查看，内容与标题恢复，但 `document.activeElement` 是 `BODY`。原件是 `../mcp-browser-ui/browser-original.json` 的 `project-reopened`；当时夹具缓存的 focus 文本没有跟随 BODY，结论依据直接 DOM `focus.tag`，不是缓存文字。

原因是标题焦点 effect 只响应新 request；重新查看保留同一 request，仅清空 closed。修复只记录上次 closed，让非空到 null 的实际重新打开也走原标题焦点 effect。active 与 owner.current 守卫、原 request 改变的标题焦点及收起后按钮焦点保留；未执行的转移仍被消费，避免后续激活补抢焦点。最终小差异复读未发现必改项。

root 已在同一夹具与 DTO 重放中记录 3 类原因的打开、收起、重新打开，共 9 个实际 DOM 观察；本线只读核原件，不重复操作浏览器：

| 原因 | 打开 | 收起 | 重新打开 |
| --- | --- | --- | --- |
| 项目设置 | H5 标题 | 查看按钮 | H5 标题 |
| 继承设置 | H5 标题 | 查看按钮 | H5 标题 |
| 多处设置 | H5 标题 | 查看按钮 | H5 标题 |

完整原件为 `../mcp-browser-ui/browser-final.json`。三类原因文字存在，6 次展开观察的组件 scrollWidth 不大于 clientWidth；有页面宽度回执的 3 次打开也不横向溢出。confirm/native 始终 0。otherPorts 最终为 5，是夹具记录并拒绝的 mcp.cancel/inventory.cancel 尝试，不能写成全部端口零调用；重新打开本身未增加 read/inspect 或这些 cancel 尝试。当前夹具 SHA 与两份 DOM 原件 SHA 在 `summary.json`，root 报告夹具字节未变；本线未另存一份 RED 前夹具 hash。

本线实际跑了现有 6 文件 20 项组件/归属/安全码回归、typecheck 与单文件 Prettier，均自然 0，diff --check 也 0；原命令与日志在 `checks/`。这些既有用例使用 SSR，不是 DOM 焦点负测。没有新增 DOM 依赖、模拟 focus 镜像测试或新框架。active=false / owner 过期不抢焦点只有源码审查，未做浏览器负测；未宣称已测。

2372 项旧工程输入与当前文件逐 hash 比较，仅本 TSX 不同，Rust 输入保持。旧七项保持原实测边界；本焦点修复不冒称再跑七项，后续受影响前端四项由 root 统一收束。本次也不证明完整详情页/宿主 Escape、完整 Tauri IPC、官方配置采用、MCP 连接/调用或安装版 UI。未运行 Cargo、真实 Agent、账号或模型；未改 controller、文档、依赖或默认测试入口。
