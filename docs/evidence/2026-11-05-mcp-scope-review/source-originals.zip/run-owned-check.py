import datetime, hashlib, json, pathlib, subprocess, sys, time
root = pathlib.Path(__file__).resolve().parents[3]
out = pathlib.Path(__file__).resolve().parent
label, *command = sys.argv[1:]
log, receipt = out/(label+".log"), out/(label+".json")
assert label and command and not log.exists() and not receipt.exists()
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
with log.open("xb") as target:
    result = subprocess.run(command, cwd=root, stdout=target, stderr=subprocess.STDOUT)
record = {"command":command,"cwd":str(root),"startedAtUtc":start,"finishedAtUtc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"durationSeconds":time.monotonic()-clock,"naturalExitCode":result.returncode,"log":str(log.relative_to(root)),"logSha256":hashlib.sha256(log.read_bytes()).hexdigest()}
receipt.write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(record,ensure_ascii=False))
raise SystemExit(result.returncode)
