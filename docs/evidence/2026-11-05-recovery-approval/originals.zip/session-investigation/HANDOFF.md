# 恢复期间用户操作保留：本线交接

本线仅修改 `src/runtime/session_open_baseline.ts` 与新增 `src/runtime/sessions.recovery-user-work.test.ts`，现已冻结，未提交。

实际复现两项接纳竞态：读取期间保留/放弃未知待发副本后，成功恢复会重新带回不在队列中的未知标记，并写出 `uncertainIndex:-1`；读取期间保存的工作暂停也会在普通恢复和配置重核后回退。修复仅合回同一对象的当前工作允许状态、明确移走的原未知副本处置及后来的非空暂停写者，保留独立的执行未知、停止与配置/权限保护。没有增加自动派发。

新源码夹具 v1 实际 RED 3过6败 → 同字节最终 GREEN 9过；最初候选 8过1败的历史结束负控原件保留。11 个相关文件 177 项全部通过。类型标注修正为 `satisfies OpenResult` 后的 v2 又实际 9过，两源格式检查通过。全量类型检查重试仍被并行作者的 Composer 新测试 121/203 行阻塞；本线不改其文件，不称类型检查通过。

当前草稿和附件、队列编辑及身份、打开失败保留、外部未知仍受保护、历史真终态和用户暂停后恢复不自动继续均有定向控制；均为真实前端 runtime 加受控 IPC peer，没有 App、真实模型、完整 IPC、Windows 或新 SQLite 验证。

详见 `handoff-summary.json`、`source-red-*`、`source-final-green-*`、`source-v2-green-*` 与 `affected-*`。`first-*` 是临时 observer 误导入私有方法造成的夹具错误，不计产品 RED。源输入地图实录了其他授权并行修改，不冒称整树前后同。父代理负责独审与统一稳定批检查，151 条原完成条件不变。
