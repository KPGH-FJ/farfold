import { defineConfig, mergeConfig } from "vitest/config";
import original from "../../../vite.config.ts";
export default mergeConfig(original, defineConfig({
  cacheDir: "output/2026-11-05-next-capability-stage/session-investigation/vite-cache",
  test: {
    include: ["output/2026-11-05-next-capability-stage/session-investigation/recovery-interleaving.test.ts"],
  },
}));
