# RecoveryApproval 最终静态准备

已按主代理审定方案应用且仅修改三份 CI 文件，没有派发。准备版模板与225行提案差异保留；最终版本只将三处未定字面量替换成实测28。

实际合批 JSON：四文件28/28，自然退出0，6+9+9+4，零跳过/失败，检查期间相关输入不变。命令与逐用例见 frontend-final-command.json、frontend-final.vitest.json；未执行 Cargo、App、GH/CI 或网络。

最终 YAML 再经已装 Prettier YAML AST 解析：原23步均保留，新增2步后25步；两个准备if只增加新cohort，其他旧步骤AST、job及全部旧step时限、resume_scope不变。旧native groups/phase inventory（包括Frozen26/45）与McpScope list/All原块逐字一致，旧Mcp18/15和OpenFailure18/51不改。最终对照获批模板仅28字面量替换。

新增RecoveryApproval固定1组/2完整native FQN、threads1，经模块--list精确核两个名字，再以同组actual cases与natural exit核实执行；固定前端4文件28case。List/Frontend/All绑定head、selection/inputdigest、binary/fixture；All绑定List回执hash。无新环境标志，现有FARFOLD_SELECTED_COHORT传参机制保持。

本机没有pwsh或actionlint，故没有本机PowerShell解析结论。保留现有Windows build的四脚本Parser.ParseFile前置；尚未在Windows执行，不能称新cohort通过。由主代理统一本机完整检查、提交推送、固定源码后决定派发。
