# RecoveryApproval：Windows 受影响验证最小提案

尚未应用到活动 CI，未派发。仅静态准备三文件模板与 `RecoveryApproval.proposed.patch`；Composer 仍在其独占代理处修复/冻结，未读取或运行其用例。最终前端总数暂用 `__RECOVERY_APPROVAL_FRONTEND_TEST_COUNT__`，模板不能执行/提交或派发；该字面量将只在取得真实最终回执后替换并应用。

- Workflow 添加一个 cohort、两个仅新 cohort 执行的步骤（Frontend 与 List/Frontend/All 汇总）。Node/依赖准备的 if 仅加新 cohort，native 复用原 generic 调用。原 45 分钟 job、30 分钟 build、8 分钟普通 native 等时限不变，无新环境变量，现有 FARFOLD_SELECTED_COHORT 机制保持。
- selected-build 只把新 cohort 加入现有前端全输入映射条件。
- runner 新分支严格绑定 1 group / 2 个完整 native FQN，threads=1；前置模块 filter 的 --list 必须恰好这两个原名（含唯一新重复 ID 负例），实际执行也按名字/条数/原始 natural exit 判定。不是使用 --exact 的单条调用；实际执行范围由精确 list 与逐 case 闭合。
- 前端固定四个文件：permission_options.test.tsx、opening_permissions.test.ts、sessions.recovery-user-work.test.ts、Composer.send-ownership.test.tsx。已获主代理确认前三个最终数为 6/9/9，Composer 待真实最终回执；不猜总数。沿原 JSON reporter 的 exact files、actual cases、零跳过、typecheck/test 自然退出及输入不变证明。
- List/Frontend/All 结果均绑定 selection/input digest/test binary/fixture；All 另绑定 List 收据 hash。旧 McpScope18/15、OpenFailure18/51、Frozen26groups/45executions及原 phases/default 保留。

静态核查：用本机已装 prettier/plugins/yaml 真 AST 解析 YAML；比较原 23 步，旧步骤除两个 setup if 的新 cohort 条件外 AST 不变，新增两步后 25 步，旧 job/step 限时与 resume_scope 不变。旧 groups/phase inventory、McpScope 的 list/All 逻辑块逐字相同。没有本机 pwsh/actionlint/PyYAML 或直接可 import 的 yaml/js-yaml；未下载工具。PowerShell 纯解析将由原 Windows build 的四个 Parser.ParseFile 前置完成，目前不能声称已本机解析或 Windows 通过。

`proposal.json` 保留三活动文件修改前 SHA 与提案 SHA；`static-validation.json` 记 YAML/结构检查及工具边界。取得 Composer 冻结信息后需核三活动文件仍对应 before SHA、仅替换上述 3 处字面量，再写三文件并进行最小静态复核；不运行 Cargo、产品测试、GH/CI/安装/Agent。
