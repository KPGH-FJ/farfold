import original from "../../../vitest.config";
export default {
  ...original,
  cacheDir: "output/2026-11-05-next-capability-stage/approval-independent-review/vite-cache",
  test: {
    ...original.test,
    include: [
      "output/2026-11-05-next-capability-stage/approval-independent-review/approval-review.test.tsx",
      "src/runtime/permission_options.test.tsx",
      "src/runtime/permission_shortcuts.test.ts",
      "src/runtime/opening_permissions.test.ts",
      "src/runtime/interaction_actions.stop.test.ts",
    ],
  },
};
