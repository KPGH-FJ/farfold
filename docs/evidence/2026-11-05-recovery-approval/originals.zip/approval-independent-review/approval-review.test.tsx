import { afterEach, expect, it, vi } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
const h = vi.hoisted(() => ({ invoke: vi.fn() }));
vi.mock("@tauri-apps/api/core", () => ({ invoke: h.invoke }));
import { ApprovalCard } from "../../../src/components/thread-items";
import { InteractionActions } from "../../../src/runtime/interaction_actions";
import { OpeningInquiryOwner } from "../../../src/runtime/opening_inquiries";
import { selectablePermissionOption } from "../../../src/runtime/permission_options";
import { applyPermissionRequest, freshThreadState } from "../../../src/runtime/session_projection";
const owners: OpeningInquiryOwner[] = [];
function setup(options: unknown) {
  vi.useFakeTimers();
  h.invoke.mockResolvedValue({ status: "submitted" });
  const state = freshThreadState("review", "agent", "/work", "native");
  const request = { sessionId: "native", options, _meta: { opaque: [null, false, { keep: "literal" }] } };
  applyPermissionRequest(state, { requestId: "first", options, toolCall: {}, request });
  return { state, request, pending: state.pendingPermissions[0], actions: new InteractionActions(() => state, vi.fn()) };
}
afterEach(() => {
  owners.splice(0).forEach((owner) => owner.retire());
  h.invoke.mockReset();
  vi.useRealTimers();
});
it("keeps a real empty string ID selectable when malformed IDs precede it", async () => {
  const { state, request, pending, actions } = setup([
    { name: "missing", kind: "allow_once" },
    ...[null, 17, false, {}, []].map((id, index) => ({ optionId: id, name: `invalid-${index}`, kind: "allow_once" })),
    { optionId: "", name: "actual-empty", kind: "reject_once" },
  ]);
  const valid = pending.options.at(-1)!;
  expect(selectablePermissionOption(pending.options, valid)).toBe(true);
  expect(pending.options.slice(0,-1).every((option) => !selectablePermissionOption(pending.options, option))).toBe(true);
  const html = renderToStaticMarkup(<ApprovalCard {...pending} onPick={() => {}} />);
  const buttons = html.match(/<button\b[^>]*>[\s\S]*?<\/button>/g) ?? [];
  expect(buttons.filter((button) => button.includes('disabled=""'))).toHaveLength(6);
  expect(buttons.find((button) => button.includes("actual-empty"))).not.toContain('disabled=""');
  actions.decide(state.key, "first", "", "actual-empty", false);
  await vi.runAllTimersAsync();
  expect(h.invoke).toHaveBeenCalledExactlyOnceWith("session_permission_respond", { sessionId: "native", requestId: "first", optionId: "" });
  expect(pending.requestSnapshot).toEqual(request);
});
it.each(["allow_once", "allow_always", "reject_once", "reject_always"])("preserves unique normal %s submission", async (kind) => {
  const { state, actions } = setup([{ optionId: "original", name: kind, kind }]);
  actions.decide(state.key, "first", "original", kind, kind.startsWith("allow"), kind === "allow_always");
  if (kind === "allow_always") {
    await vi.advanceTimersByTimeAsync(4999);
    expect(h.invoke).not.toHaveBeenCalled();
  }
  await vi.runAllTimersAsync();
  expect(h.invoke).toHaveBeenCalledExactlyOnceWith("session_permission_respond", { sessionId: "native", requestId: "first", optionId: "original" });
});
it("treats a shared option ID in separate requests independently", async () => {
  const options = [{ optionId: "shared", name: "Allow once", kind: "allow_once" }];
  const { state, actions, pending } = setup(options);
  applyPermissionRequest(state, { requestId: "second", options, toolCall: {}, request: { opaque: "second" } });
  const second = state.pendingPermissions[1];
  actions.decide(state.key, "first", "shared", "Allow once", true);
  await vi.runAllTimersAsync();
  expect(state.pendingPermissions).toEqual([second]);
  expect(second.status).toBe("pending");
  actions.decide(state.key, "second", "shared", "Allow once", true);
  await vi.runAllTimersAsync();
  expect(h.invoke.mock.calls.map(([, args]) => args.requestId)).toEqual([pending.requestId, second.requestId]);
});
it.each(["retryable", "uncertain", "expired"])("retains the original %s result semantics", async (status) => {
  const { state, request, pending, actions } = setup([{ optionId: "safe", name: "Reject", kind: "reject_once" }]);
  h.invoke.mockResolvedValue({ status });
  actions.decide(state.key, "first", "safe", "Reject", false);
  await vi.runAllTimersAsync();
  expect(h.invoke).toHaveBeenCalledTimes(1);
  expect(pending.requestSnapshot).toEqual(request);
  if (status === "expired") expect(state.pendingPermissions).toEqual([]);
  else {
    expect(pending.status).toBe(status === "retryable" ? "pending" : "uncertain");
    expect(pending.decision).toBeNull();
    if (status === "uncertain") {
      actions.decide(state.key, "first", "safe", "Reject", false);
      await vi.runAllTimersAsync();
      expect(h.invoke).toHaveBeenCalledTimes(1);
    }
  }
});
it("undoes a unique remember choice without dispatching", async () => {
  const { state, pending, actions } = setup([{ optionId: "remember", name: "Remember", kind: "allow_always" }]);
  actions.decide(state.key, "first", "remember", "Remember", true, true);
  actions.undo(state.key, "first");
  await vi.runAllTimersAsync();
  expect(h.invoke).not.toHaveBeenCalled();
  expect(pending.decision).toBeNull();
});
it("keeps duplicate IDs blocked after a real opening handoff while allowing the separate option", async () => {
  vi.useFakeTimers(); h.invoke.mockResolvedValue({ status: "submitted" });
  const owner = new OpeningInquiryOwner("a", "/work", () => {}); owners.push(owner); owner.addInterest();
  const options = [{optionId:"same",name:"Allow",kind:"allow_once"},{optionId:"same",name:"Reject",kind:"reject_once"},{optionId:"safe",name:"Separate reject",kind:"reject_once"}];
  const request = { opaque: ["opening", null] };
  owner.receive({kind:"permissionRequest",requestId:"opening",owner:{requestId:"opening",connectionId:"connection",sessionId:"native"},toolCall:{},options,request});
  const original = owner.snapshot().permissions[0];
  const state = freshThreadState("opening", "a", "/work", "native"); state.connectionId="connection";
  owner.handoffPermissions(state, () => true, () => {});
  const actions = new InteractionActions(() => state, vi.fn());
  actions.decide(state.key,"opening","same","Allow",true);
  await vi.runAllTimersAsync(); expect(h.invoke).not.toHaveBeenCalled();
  expect(state.pendingPermissions[0]).toBe(original);
  actions.decide(state.key,"opening","safe","Separate reject",false);
  await vi.runAllTimersAsync();
  expect(h.invoke).toHaveBeenCalledExactlyOnceWith("session_permission_respond",{sessionId:"native",requestId:"opening",optionId:"safe"});
  expect(original.requestSnapshot).toEqual(request);
});
