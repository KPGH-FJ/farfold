# 审批选项标识保护：独立复核

结论：**本批未发现必改问题（PASS_WITH_EXPLICIT_SCOPE）**。只读产品源码和现有证据；仅在本目录增加补充用例、配置、日志与报告，无源码修改，未运行 Cargo、全量检查、App、CI 或网络。

独立定向前端运行自然退出 0，5 文件 **49/49**（现有 38 项＋本目录补充 11 项）；原命令、退出、stdout/stderr 和运行前后源码指纹均保留。18 个相关输入指纹在检查期间未变。当前复核 HEAD 为 `4814cb75c49c4fbe47a0156bdea4b7f447898dc8`；包含尚未提交的所审改动，不能仅用 HEAD 字符串代替这些指纹。

- 重复 ID 按本请求判断：按钮、快捷键、普通直接动作及 opening 动作都阻断歧义项；后端在取走 responder 之前要求恰好匹配 1 次。另一个唯一有效选项仍可继续。
- 非字符串 ID 不再 String 强转。普通投影产生 invalidId，helper 的唯一性统计排除这些无效项。补充了“无效项在前、合法空字符串 ID 在后”的真实投影→卡片→动作路径，包含 missing/null/number/boolean/object/array；合法空 ID 精确提交、无效按钮禁用，通过。
- 同一个 optionId 在两个 request 中独立工作；第一次回复不消耗第二请求。原始 opaque request/tool/options 保留在独立快照，不被归一化视图覆盖。
- 四种正常选项、remember 的 5 秒窗口与 undo、retryable/uncertain/expired，以及 opening 取消/迟到/owner/handoff 关联测试通过。新增实际 OpeningInquiryOwner.receive→handoff→普通动作的重复 ID 反例及 safe 正控。

原始 RED：普通前端 4 失败/1 通过、opening 1 失败/8 通过、Rust 1 失败（错误返回 submitted）；现有 GREEN：前端 8 文件 59 通过，后来单文件 6 通过，Rust 两个合成协议用例通过。这些集合重叠，不能相加为唯一用例数。Rust 本轮仅核日志和源码，未重复执行；日志不是安装版、真实 Agent 或独立数字退出回执。

**已排除的候选**：先前怀疑 opening 的 find 会被 invalidId 空字符串哨兵遮蔽，但产品 readOpeningPermission 先过滤非字符串及空字符串，normal 投影不会流回 opening.add；该形状在本调用链不可达，不算缺陷。Opening 不支持空字符串 ID 是既有行为，本批未改变或新增支持承诺；普通对话空 ID 正控不扩称 opening 支持。

具体语义、范围和六份现有 RED/GREEN 原件哈希见 `review.json`；本轮执行见 `frontend-command.json`。所有通过结论限受控前端/合成协议路径，不代表真实 Agent、安装版或 Windows 审批验收。
