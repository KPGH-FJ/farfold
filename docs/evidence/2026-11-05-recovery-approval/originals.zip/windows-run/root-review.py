from pathlib import Path,PurePosixPath
import hashlib,json,re,stat,zipfile
BASE=Path(__file__).resolve().parent; RAW=BASE/'raw/artifact'
HEAD='cfd14b749d5e008359edc4901d3c6da00350f323'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(value,label):
 assert value,label
 checks.append(label)
run=load(BASE/'run-completed.stdout');jobs=load(BASE/'jobs-completed.stdout')['jobs']
check(run['id']==41965725276 and run['run_attempt']==1 and run['head_sha']==HEAD and run['status']=='completed' and run['conclusion']=='success','exact run/source/attempt completed success')
check(len(jobs)==1 and jobs[0]['id']==127042164355 and jobs[0]['head_sha']==HEAD and jobs[0]['conclusion']=='success','exact one job/source success')
for needle in ['Build and bind','Check selected types and exact recovery','Run the selected native','Require exact selected recovery']:
 matches=[s for s in jobs[0]['steps'] if needle in s['name']]
 check(len(matches)==1 and matches[0]['conclusion']=='success','actual step: '+needle)
check(load(BASE/'watch.result.json')['naturalExitCode']==0,'unique watch natural exit0')
selection=load(RAW/'build-selection.json'); inputs=load(RAW/'inputs-after.json')
check(selection['sourceHead']==HEAD and selection['selectedCohort']=='RecoveryApproval','selection exact source/cohort')
check((RAW/'inputs-before.json').read_bytes()==(RAW/'inputs-after.json').read_bytes(),'same before/after input bytes')
check(len(inputs)==2312,'2312 declared Windows source inputs')
for key,name in [('inputsBeforeSha256','inputs-before.json'),('inputsAfterSha256','inputs-after.json')]:check(selection[key].lower()==sha(RAW/name),'selection hash: '+name)
build=load(RAW/'selected-build.result.json');check(build['buildSucceeded'] and build['runnerExitCode']==0 and build['testBuildExit']==0 and build['fixtureBuildExit']==0 and build['sourceHead']==HEAD,'build natural exits0 and exact source')
check(len(build['syntaxChecks'])==4,'four actual PowerShell parse results')
for syntax in build['syntaxChecks']:check(syntax['parseErrors']==[] and syntax['sha256'].lower()==inputs[syntax['path']].lower(),'ParseFile bound: '+syntax['path'])
phases={n:load(RAW/f'recovery-approval-{n}.result.json') for n in ['List','Frontend','All']}
for name,rec in phases.items():
 check(rec['sourceHead']==HEAD and rec['cohort']=='RecoveryApproval' and rec['phase']==name,'phase identity: '+name)
 check(rec['allReturned'] and rec['exactAllPassed'] and rec['sourceInputsStable'] and not rec['productOrAllWindowsComplete'],'phase bounded success flags: '+name)
 check(rec['selectionSha256'].lower()==sha(RAW/'build-selection.json'),'selection byte hash: '+name)
 for key in ['inputsAfterSha256','testBinarySha256','fixtureSha256']:check(rec[key].lower()==selection[key].lower(),'cross receipt '+name+':'+key)
for rec in [build,*phases.values()]:
 for name,want in rec.get('rawFileSha256',{}).items():
  check(Path(name).name==name and (RAW/name).is_file() and sha(RAW/name)==want.lower(),'raw file hash: '+name)
check(phases['All']['listResultSha256'].lower()==sha(RAW/'recovery-approval-List.result.json'),'All binds exact List bytes')
names={'acp_client::permission_request_tests::permission_request_preserves_full_params_and_compatibility_fields','acp_client::permission_request_tests::ambiguous_permission_option_cannot_consume_the_original_responder'}
l=phases['List'];check(l['naturalExitCode']==0 and l['runnerExitCode']==0 and set(l['actualNames'])==names and len(l['actualNames'])==2,'List natural0 and exact two FQNs')
text=(RAW/'recovery-approval-list.stdout.log').read_text(encoding='utf-8-sig');actual=re.findall(r'^(\S+): test\r?$',text,re.M);check(len(actual)==2 and set(actual)==names,'actual binary list text two FQNs')
text=(RAW/'recovery-approval-worker.stdout.log').read_text(encoding='utf-8-sig');actual=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\r?$',text,re.M)
check(len(actual)==2 and {n for n,s in actual}==names and all(s=='ok' for n,s in actual),'actual native execution text exact two passed')
check(len(re.findall(r'^test result: ok\. 2 passed; 0 failed; 0 ignored;',text,re.M))==1,'one exact native summary')
a=phases['All'];check(a['expectedGroups']==a['completedGroups']==len(a['groups'])==1 and a['expectedExecutions']==2 and a['groups'][0]['expectedTests']==2 and a['groups'][0]['naturalExitCode']==0 and a['groups'][0]['passed'],'native group natural0 and exact counts')
f=phases['Frontend'];check(f['typecheckNaturalExitCode']==f['testNaturalExitCode']==f['runnerExitCode']==0 and f['actualTests']==f['expectedTests']==28,'frontend natural exits0 and28')
report=load(RAW/'recovery-approval-frontend.vitest.json');check(report['success'] and report['numPassedTests']==report['numTotalTests']==28 and report['numFailedTests']==report['numPendingTests']==report['numTodoTests']==0,'Vitest28 pass with no failure/skip/todo')
expected={'src/components/Composer.send-ownership.test.tsx':4,'src/runtime/opening_permissions.test.ts':9,'src/runtime/permission_options.test.tsx':6,'src/runtime/sessions.recovery-user-work.test.ts':9}
check(len(report['testResults'])==4,'four actual frontend files')
for file in report['testResults']:
 match=[n for n in expected if file['name'].replace('\\','/').endswith('/'+n)]
 check(len(match)==1 and file['status']=='passed' and len(file['assertionResults'])==expected[match[0]] and all(a['status']=='passed' for a in file['assertionResults']),'actual frontend file: '+file['name'])
artifacts=load(BASE/'artifacts-completed.stdout')['artifacts'];check(len(artifacts)==1,'one run artifact');artifact=artifacts[0]
check(artifact['id']==13388121703 and artifact['workflow_run']['id']==run['id'] and artifact['workflow_run']['head_sha']==HEAD,'artifact exact id/run/source')
check(artifact['size_in_bytes']==(BASE/'artifact-original.stdout').stat().st_size==257448 and artifact['digest']=='sha256:'+sha(BASE/'artifact-original.stdout'),'actual artifact bytes and server digest')
for archive,dest,expected_count in [('artifact-original.stdout','artifact',22),('logs-completed.stdout','job-logs',17)]:
 with zipfile.ZipFile(BASE/archive) as z:
  check(z.testzip() is None,'ZIP CRC: '+archive); members=[i for i in z.infolist() if not i.is_dir()];check(len(members)==expected_count,'ZIP actual text member count: '+archive)
  for info in members:
   name=info.filename.replace('\\','/');parts=PurePosixPath(name);check(not parts.is_absolute() and '..' not in parts.parts and not stat.S_ISLNK(info.external_attr>>16),'safe member: '+name)
   data=z.read(info);data.decode('utf-8-sig');check(b'\0' not in data and Path(name).suffix.lower() in {'.json','.jsonl','.log','.txt'},'text-only member: '+name)
   check((BASE/'raw'/dest/name).read_bytes()==data,'exact extracted bytes: '+name)
binding=load(BASE/'source-binding.json');check(binding['inputCount']==2312 and binding['sourceCommit']==HEAD and binding['exactCount']==35 and binding['lfToCrlfExactCount']==2277 and not binding['mismatches'] and binding['all20ChangedSourceFilesIncluded'],'Git/source binding verified by separate root script')
record={'reviewer':'root, independent of CI script author and acquisition owner','result':'PASS_WITH_EXPLICIT_SCOPE','run':run['id'],'sourceHead':HEAD,'rawChecksPassed':len(checks),'checks':checks,'windowsNative':{'passed':2,'failed':0,'ignored':0},'windowsFrontend':{'files':4,'passed':28,'failed':0,'pending':0,'todo':0},'sourceBinding':{'inputs':2312,'exact':35,'LF_to_CRLF_exact':2277,'all20ChangedFilesIncluded':True},'limits':['Check count is derived evidence assertions, not product test count.','Remote test/fixture executable digests were bound across receipts; no executable was downloaded or locally hashed.','Windows frontend uses controlled callback/hook/SSR tests; native cases use actual manager and controlled Python protocol peer, no real Agent/model.','No App/installer/desktop UI/user-account/full Windows or29-agent acceptance.']}
(BASE/'root-independent-review.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='checks'}))
