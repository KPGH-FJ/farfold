from pathlib import Path
import collections,datetime,hashlib,json,re,sys
b=Path(__file__).resolve().parent
head="cfd14b749d5e008359edc4901d3c6da00350f323";run_id=41965725276
names=["acp_client::permission_request_tests::permission_request_preserves_full_params_and_compatibility_fields","acp_client::permission_request_tests::ambiguous_permission_option_cannot_consume_the_original_responder"]
front={"src/runtime/permission_options.test.tsx":6,"src/runtime/opening_permissions.test.ts":9,"src/runtime/sessions.recovery-user-work.test.ts":9,"src/components/Composer.send-ownership.test.tsx":4}
checks=[]
def check(label,passed,actual=None,expected=None):checks.append({"check":label,"passed":bool(passed),"actual":actual,"expected":expected})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def heq(a,c):return isinstance(a,str) and isinstance(c,str) and a.lower()==c.lower()
def load(p):return json.loads(p.read_text(encoding="utf-8-sig"))
run=load(b/"run-completed.stdout");jobs=load(b/"jobs-completed.stdout")["jobs"];artifacts=load(b/"artifacts-completed.stdout")["artifacts"]
check("fixed_run_and_head",run.get("id")==run_id and run.get("head_sha")==head,{"id":run.get("id"),"head":run.get("head_sha")},{"id":run_id,"head":head})
check("run_completed_success",run.get("status")=="completed" and run.get("conclusion")=="success",[run.get("status"),run.get("conclusion")],["completed","success"])
check("single_selected_job",len(jobs)==1 and jobs[0].get("name")=="selected",[{"name":j.get("name"),"id":j.get("id")} for j in jobs],"one selected job")
for j in jobs:
 check("job_source_head:"+str(j["id"]),j.get("head_sha")==head,j.get("head_sha"),head)
 check("job_completed_success:"+str(j["id"]),j.get("status")=="completed" and j.get("conclusion")=="success",[j.get("status"),j.get("conclusion")],["completed","success"])
check("one_current_run_artifact",len(artifacts)==1 and artifacts[0].get("name")==f"farfold-windows-launch-prerequisites-{run_id}-1" and artifacts[0].get("expired")==False,[{"id":a.get("id"),"name":a.get("name"),"expired":a.get("expired")} for a in artifacts],"one unexpired current run/attempt artifact")
root=b/"raw"/"artifact"
def path(name):
 found=list(root.rglob(name));check("required_raw_file:"+name,len(found)==1,[str(p.relative_to(b)) for p in found],"one")
 if len(found)!=1:raise RuntimeError("Missing or duplicate required file "+name)
 return found[0]
selp=path("build-selection.json");sel=load(selp);beforep=path("inputs-before.json");afterp=path("inputs-after.json");before=load(beforep);after=load(afterp);build=load(path("selected-build.result.json"));identity=load(path("identity.json"))
check("complete_original_input_maps_equal",bool(before) and before==after,{"beforeCount":len(before),"afterCount":len(after)},"all original key/hash pairs equal")
check("all_original_input_hashes_sha256",all(isinstance(v,str) and re.fullmatch(r"[0-9a-f]{64}",v) for v in after.values()),len(after),"each lower-case SHA256")
check("selection_head_cohort",sel.get("sourceHead")==head and sel.get("cohort")=="LaunchPrerequisites" and sel.get("selectedCohort")=="RecoveryApproval",{k:sel.get(k) for k in ["sourceHead","cohort","selectedCohort"]},"fixed head / LaunchPrerequisites / RecoveryApproval")
check("identity_head_cohort",identity.get("sourceHead")==head and identity.get("selectedCohort")=="RecoveryApproval",identity,"fixed head / RecoveryApproval")
check("selection_before_map_hash",heq(sel.get("inputsBeforeSha256"),sha(beforep)),sel.get("inputsBeforeSha256"),sha(beforep))
check("selection_after_map_hash",heq(sel.get("inputsAfterSha256"),sha(afterp)),sel.get("inputsAfterSha256"),sha(afterp))
for key in ["testBuildExit","fixtureBuildExit"]:check("selected_actual_build_exit:"+key,sel.get(key)==0,sel.get(key),0)
check("selected_build_natural_result",build.get("testBuildExit")==0 and build.get("fixtureBuildExit")==0 and build.get("runnerExitCode")==0 and build.get("buildSucceeded")==True and build.get("sourceInputsStable")==True and build.get("sourceHead")==head,build,"0 build exits / succeeded / stable / fixed source")
syntax=build.get("syntaxChecks",[]);expected_scripts={".github/scripts/windows-selected-build.ps1",".github/scripts/windows-stdio-eof.ps1",".github/scripts/windows-stdout-controls.ps1",".github/scripts/windows-launch-prerequisites.ps1"}
check("four_actual_powershell_parsefiles",len(syntax)==4 and {x.get("path") for x in syntax}==expected_scripts,syntax,sorted(expected_scripts))
for x in syntax:check("parse_errors_and_bound_script:"+x.get("path","?"),x.get("parseErrors")==[] and heq(x.get("sha256"),after.get(x.get("path"))),x,{"parseErrors":[],"sha256":after.get(x.get("path"))})
for obj,label in [(build,"selected-build")]:
 for name,h in obj.get("rawFileSha256",{}).items():
  p=path(name);check("raw_hash:"+label+":"+name,heq(h,sha(p)),h,sha(p))
check("workflow_source_hash_bound",heq(sel.get("workflowSha256"),after.get(".github/workflows/windows-launch-prerequisites.yml")),sel.get("workflowSha256"),after.get(".github/workflows/windows-launch-prerequisites.yml"))
phase={}
for ph in ["List","Frontend","All"]:
 pp=path("recovery-approval-"+ph+".result.json");obj=load(pp);phase[ph]=obj
 check("phase_source_identity:"+ph,obj.get("sourceHead")==head and obj.get("cohort")=="RecoveryApproval" and obj.get("phase")==ph,{k:obj.get(k) for k in ["sourceHead","cohort","phase"]},"fixed source / RecoveryApproval / "+ph)
 for k in ["allReturned","exactAllPassed","sourceInputsStable"]:check("phase_assertion:"+ph+":"+k,obj.get(k)==True,obj.get(k),True)
 for k,h in [("selectionSha256",sha(selp)),("inputsAfterSha256",sel["inputsAfterSha256"]),("testBinarySha256",sel["testBinarySha256"]),("fixtureSha256",sel["fixtureSha256"])]:check("phase_binding:"+ph+":"+k,heq(obj.get(k),h),obj.get(k),h)
 for name,h in obj.get("rawFileSha256",{}).items():p=path(name);check("raw_hash:"+ph+":"+name,heq(h,sha(p)),h,sha(p))
li=phase["List"];check("list_natural_exit",li.get("naturalExitCode")==0 and li.get("runnerExitCode")==0,[li.get("naturalExitCode"),li.get("runnerExitCode")],[0,0]);check("list_exact_two_original_fqns",li.get("exactNames")==True and sorted(li.get("expectedNames",[]))==sorted(names) and sorted(li.get("actualNames",[]))==sorted(names),{"expected":li.get("expectedNames"),"actual":li.get("actualNames")},names)
fr=phase["Frontend"];check("frontend_natural_exits",fr.get("typecheckNaturalExitCode")==0 and fr.get("testNaturalExitCode")==0 and fr.get("runnerExitCode")==0,{k:fr.get(k) for k in ["typecheckNaturalExitCode","testNaturalExitCode","runnerExitCode"]},0)
check("frontend_exact_file_receipt",fr.get("exactFiles")==True and set(fr.get("expectedFiles",[]))==set(front) and len(fr.get("actualFiles",[]))==4,fr.get("expectedFiles"),list(front))
check("frontend_28_actual_receipt",fr.get("expectedTests")==28 and fr.get("actualTests")==28,[fr.get("expectedTests"),fr.get("actualTests")],[28,28])
report=load(path("recovery-approval-frontend.vitest.json"));actual_counts={};all_cases=[]
for f in report["testResults"]:
 matches=[n for n in front if f["name"].replace("\\","/").lower().endswith("/"+n.lower())];check("frontend_report_file:"+f["name"],len(matches)==1,matches,"one exact expected suffix")
 if len(matches)==1:actual_counts[matches[0]]=len(f["assertionResults"])
 all_cases.extend(f["assertionResults"])
check("frontend_report_4files_28cases",len(report["testResults"])==4 and actual_counts==front and len(all_cases)==28,actual_counts,front)
check("frontend_report_no_skips_or_failures",report.get("success")==True and report.get("numTotalTests")==28 and report.get("numPassedTests")==28 and report.get("numPendingTests")==0 and report.get("numTodoTests")==0 and report.get("numFailedTests")==0 and all(x.get("status")=="passed" for x in all_cases),{k:report.get(k) for k in ["success","numTotalTests","numPassedTests","numPendingTests","numTodoTests","numFailedTests"]},"28 passed, zero skip/todo/fail")
worker=load(path("recovery-approval-worker.json"));check("native_actual_exit_and_case_names",worker.get("naturalExitCode")==0 and worker.get("passed")==True and worker.get("exactNames")==True and sorted(worker.get("expectedNames",[]))==sorted(names) and sorted(x.get("name") for x in worker.get("actualCases",[]))==sorted(names) and all(x.get("result")=="ok" for x in worker.get("actualCases",[])),worker,"exact two ok / actual natural 0")
check("native_threads_and_filter",worker.get("argv")==["acp_client::permission_request_tests::","--show-output","--test-threads=1","--color=never"],worker.get("argv"),"one prefix group threads1, no accidental extra selection")
for k,h in [("selectionSha256",sha(selp)),("testBinarySha256",sel["testBinarySha256"]),("fixtureSha256",sel["fixtureSha256"])]:check("native_worker_binding:"+k,heq(worker.get(k),h),worker.get(k),h)
for stream in ["stdout","stderr"]:pp=path("recovery-approval-worker."+stream+".log");check("native_worker_stream_hash:"+stream,heq(worker.get(stream+"Sha256"),sha(pp)),worker.get(stream+"Sha256"),sha(pp))
al=phase["All"];groups=al.get("groups",[]);check("all_one_group_two_natural_passes",al.get("expectedGroups")==1 and al.get("completedGroups")==1 and al.get("expectedExecutions")==2 and len(groups)==1 and groups[0].get("naturalExitCode")==0 and groups[0].get("expectedTests")==2 and groups[0].get("passed")==True,groups,"one group / two tests / natural0")
check("all_binds_actual_list_receipt",heq(al.get("listResultSha256"),sha(path("recovery-approval-List.result.json"))),al.get("listResultSha256"),sha(path("recovery-approval-List.result.json")))
for p in b.glob("*.result.json"):
 obj=load(p)
 if "command" in obj:
  for stream in ["stdout","stderr"]:
   v=obj.get(stream,{});pp=Path(v.get("path",""));check("cli_receipt_stream_pin:"+p.name+":"+stream,pp.is_file() and pp.stat().st_size==v.get("bytes") and heq(sha(pp),v.get("sha256")) if pp.is_file() else False,v,"saved bytes/sha")
failed=[x for x in checks if not x["passed"]]
result={"runId":run_id,"sourceHead":head,"status":"PASS_WITH_EXPLICIT_SCOPE" if not failed else "FINDINGS","checks":checks,"checkCount":len(checks),"failedChecks":failed,"gitBlobAndCrLfEquivalence":"DEFERRED_TO_ROOT_INDEPENDENT_REVIEW","testExeDownloadedOrRehashed":False,"productOrFullWindowsComplete":False}
with (b/"checks.json").open("x") as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write("\n")
summary={"runId":run_id,"sourceHead":head,"runConclusion":run.get("conclusion"),"status":result["status"],"checksPassed":len(checks)-len(failed),"failedChecks":[x["check"] for x in failed],"jobs":[{"id":j["id"],"name":j["name"],"status":j["status"],"conclusion":j["conclusion"],"headSha":j.get("head_sha"),"startedAt":j.get("started_at"),"completedAt":j.get("completed_at"),"steps":j.get("steps")} for j in jobs],"inputMapCount":len(after),"native":{"files":1,"tests":2,"names":names,"naturalExitCode":worker.get("naturalExitCode"),"proof":"runner's actual executable invocation receipt; EXE not uploaded or independently rehashed locally"},"frontend":{"files":4,"tests":28,"perFile":actual_counts,"typecheckNaturalExitCode":fr.get("typecheckNaturalExitCode"),"testNaturalExitCode":fr.get("testNaturalExitCode"),"skips":report.get("numPendingTests")},"powershellParseFiles":syntax,"artifactMetadata":artifacts,"boundary":"Only fixed-source RecoveryApproval selected tests/metadata; no full Windows/desktop/App/Agent/installer acceptance","gitBlobAndCrLfEquivalence":"root follow-up pending","noDispatchRerunOrExecution":True}
with (b/"summary.json").open("x") as f:json.dump(summary,f,ensure_ascii=False,indent=2);f.write("\n")
print(json.dumps({"status":result["status"],"checkCount":len(checks),"failedChecks":[x["check"] for x in failed],"inputMapCount":len(after),"native":2,"frontend":actual_counts},ensure_ascii=False))
