from pathlib import Path
import hashlib,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
COMMIT='cfd14b749d5e008359edc4901d3c6da00350f323'
rawpath=Path(sys.argv[1]).resolve()
assert rawpath.is_relative_to(BASE.resolve())
inputs=json.loads(rawpath.read_text(encoding='utf-8-sig'))
assert isinstance(inputs,dict) and 2000 < len(inputs) < 4000
changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',COMMIT],cwd=ROOT,text=True).splitlines()
assert len(changed)==20 and all(name in inputs for name in changed)
p=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
result={}; mismatches={}
for name,digest in sorted(inputs.items()):
 assert isinstance(name,str) and '\n' not in name and not name.startswith('/') and '..' not in Path(name).parts
 assert isinstance(digest,str) and re.fullmatch('[0-9a-fA-F]{64}',digest)
 p.stdin.write((COMMIT+':'+name+'\n').encode());p.stdin.flush()
 header=p.stdout.readline().decode().strip().split();assert len(header)==3 and header[1]=='blob',(name,header)
 blob=p.stdout.read(int(header[2]));assert p.stdout.read(1)==b'\n'
 canonical=hashlib.sha256(blob).hexdigest();wanted=digest.lower()
 if canonical==wanted: mode='exact'
 elif b'\0' not in blob and b'\r\n' not in blob and b'\n' in blob and hashlib.sha256(blob.replace(b'\n',b'\r\n')).hexdigest()==wanted: mode='LF_to_CRLF_exact'
 else:
  mode='MISMATCH';mismatches[name]={'gitSha256':canonical,'windowsSha256':wanted}
 result[name]={'mode':mode,'gitSha256':canonical,'windowsSha256':wanted}
p.stdin.close();assert p.wait()==0
record={'sourceCommit':COMMIT,'inputMap':str(rawpath.relative_to(ROOT)),'inputMapSha256':hashlib.sha256(rawpath.read_bytes()).hexdigest(),'inputCount':len(inputs),'all20ChangedSourceFilesIncluded':True,'exactCount':sum(x['mode']=='exact' for x in result.values()),'lfToCrlfExactCount':sum(x['mode']=='LF_to_CRLF_exact' for x in result.values()),'mismatches':mismatches,'files':result,'scope':'Canonical Git blob comparison to archived Windows input hashes. CRLF paths are an exact named checkout transform, not raw byte equality. Does not hash the remote executable locally.'}
(BASE/'source-binding.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['files','mismatches']} | {'mismatches':len(mismatches)}))
assert not mismatches
