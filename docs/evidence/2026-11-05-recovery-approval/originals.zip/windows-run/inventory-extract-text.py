from pathlib import Path,PurePosixPath
import hashlib,json,stat,sys,zipfile
base=Path(__file__).resolve().parent
archive=Path(sys.argv[1]).resolve();label=sys.argv[2]
if label not in ("artifact","job-logs"):raise SystemExit("Invalid fixed archive label")
if archive.parent!=base:raise SystemExit("Archive must remain in the authorized directory")
root=base/"raw"/label
if root.exists():raise SystemExit("Refuse to overwrite an extracted archive")
inventory=base/(label+"-zip-inventory.json")
if inventory.exists():raise SystemExit("Refuse to overwrite archive inventory")
allowed={".json",".jsonl",".log",".txt",".ps1",".py",".sh",".stdout",".stderr"}
entries=[];total=0;names=set();problems=[]
with zipfile.ZipFile(archive) as z:
 for info in z.infolist():
  name=info.filename;p=PurePosixPath(name);mode=info.external_attr>>16
  issues=[]
  if p.is_absolute() or ".." in p.parts or "\\" in name or "\x00" in name or (p.parts and len(p.parts[0])>=2 and p.parts[0][1]==":"):issues.append("unsafe_path")
  if name.casefold() in names:issues.append("duplicate_or_case_colliding_member")
  names.add(name.casefold())
  if stat.S_ISLNK(mode):issues.append("symlink")
  if stat.S_IFMT(mode) not in (0,stat.S_IFREG,stat.S_IFDIR):issues.append("non_regular_member")
  if info.flag_bits&1:issues.append("encrypted_member")
  total+=info.file_size
  item={"name":name,"bytes":info.file_size,"compressedBytes":info.compress_size,"crc32":format(info.CRC,"08x"),"unixMode":oct(mode),"isDirectory":info.is_dir(),"safeExtension":p.suffix.lower() in allowed,"issues":issues}
  entries.append(item);problems.extend({"name":name,"issue":v} for v in issues)
 record={"archive":str(archive),"archiveBytes":archive.stat().st_size,"archiveSha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"memberCount":len(entries),"uncompressedTotalBytes":total,"members":entries,"problems":problems,"stage":"inventory_before_any_extraction"}
 with inventory.open("x") as f:json.dump(record,f,indent=2);f.write("\n")
 if problems or total>200*1024*1024 or len(entries)>1000:raise SystemExit("Archive inventory rejected; nothing extracted")
 extracted=[];excluded=[]
 for info,item in zip(z.infolist(),entries):
  if info.is_dir():continue
  if not item["safeExtension"]:
   excluded.append({"name":info.filename,"reason":"non_allowlisted_extension"});continue
  content=z.read(info)
  if len(content)!=info.file_size:raise SystemExit("Member size changed")
  try:content.decode("utf-8-sig")
  except UnicodeDecodeError:
   excluded.append({"name":info.filename,"reason":"not_strict_utf8_text"});continue
  if b"\x00" in content or content[:2]==b"MZ":
   excluded.append({"name":info.filename,"reason":"binary_signature_or_nul"});continue
  target=root.joinpath(*PurePosixPath(info.filename).parts)
  if not target.resolve().is_relative_to(root.resolve()):raise SystemExit("Extraction path escapes text root")
  target.parent.mkdir(parents=True,exist_ok=True)
  with target.open("xb") as f:f.write(content)
  extracted.append({"member":info.filename,"path":str(target.relative_to(base)),"bytes":len(content),"sha256":hashlib.sha256(content).hexdigest(),"crcRead":"PASS"})
 with (base/(label+"-text-extraction.json")).open("x") as f:json.dump({"inventory":str(inventory.name),"extracted":extracted,"excluded":excluded,"binaryOrAppExecuted":False},f,indent=2);f.write("\n")
print(json.dumps({"label":label,"members":len(entries),"uncompressedTotalBytes":total,"extractedTextFiles":len(extracted),"excluded":excluded}))
