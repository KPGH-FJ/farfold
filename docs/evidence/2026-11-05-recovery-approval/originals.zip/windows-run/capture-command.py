from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
base=Path(__file__).resolve().parent
label=sys.argv[1]; command=sys.argv[2:]
if not label or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in label): raise SystemExit("Invalid receipt label")
if command[:2] != ["gh","api"] and command[:4] != ["gh","run","watch","41965725276"]: raise SystemExit("Only this CI read/watch commands are allowed")
if command[:2] == ["gh","api"] and (len(command)!=3 or not command[2].startswith("repos/KPGH-FJ/farfold/actions/")): raise SystemExit("Only actions read endpoint allowed")
paths={kind:base/(label+suffix) for kind,suffix in [("stdout",".stdout"),("stderr",".stderr"),("receipt",".result.json")]}
if any(p.exists() for p in paths.values()): raise SystemExit("Refuse to overwrite an existing command record")
started=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
with paths["stdout"].open("xb") as out,paths["stderr"].open("xb") as err:
 process=subprocess.Popen(command,stdout=out,stderr=err)
 if command[:3]==["gh","run","watch"]:
  lock=base/"watch-started.json"
  with lock.open("x") as f: json.dump({"runId":41965725276,"sourceHead":"cfd14b749d5e008359edc4901d3c6da00350f323","helperPid":__import__("os").getpid(),"ghPid":process.pid,"command":command,"startedAtUtc":started},f,indent=2)
 code=process.wait()
finished=datetime.datetime.now(datetime.timezone.utc).isoformat()
r={"command":command,"startedAtUtc":started,"finishedAtUtc":finished,"naturalExitCode":code,"elapsedSeconds":time.monotonic()-clock,"stdout":{"path":str(paths["stdout"]),"bytes":paths["stdout"].stat().st_size,"sha256":hashlib.sha256(paths["stdout"].read_bytes()).hexdigest()},"stderr":{"path":str(paths["stderr"]),"bytes":paths["stderr"].stat().st_size,"sha256":hashlib.sha256(paths["stderr"].read_bytes()).hexdigest()},"scope":"CLI/API client exit only; not a Cargo/App test process exit"}
with paths["receipt"].open("x") as f:json.dump(r,f,indent=2);f.write("\n")
print(json.dumps({"label":label,"naturalExitCode":code,"stdoutBytes":r["stdout"]["bytes"],"stderrBytes":r["stderr"]["bytes"]}),flush=True)
raise SystemExit(code)
