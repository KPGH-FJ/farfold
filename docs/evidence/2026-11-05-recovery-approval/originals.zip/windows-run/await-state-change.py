from pathlib import Path
import datetime,hashlib,json,re,time
b=Path(__file__).resolve().parent
cursor=b/"watch-state-cursor.json"; state=json.loads(cursor.read_text()) if cursor.exists() else {"offset":0,"buffer":"","signature":None,"completed":False}
start=time.monotonic();deadline=start+55
while True:
 p=b/"watch.stdout"
 if p.exists():
  new=b""
  if p.stat().st_size>state["offset"]:
   with p.open("rb") as f:
    f.seek(state["offset"]);new=f.read();state["offset"]=f.tell()
  if new:
   state["buffer"]=(state["buffer"]+new.decode("utf-8",errors="replace"))[-24000:]
  text=re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]","",state["buffer"])
  sections=text.split("\nJOBS\n")
  block=sections[-1] if len(sections)>1 else ""
  steps=[{"marker":m.group(1),"name":m.group(2)} for m in re.finditer(r"(?m)^  ([✓X*\-!]) (.+)$",block)]
  complete=(b/"watch.result.json").exists()
  sig=hashlib.sha256(json.dumps([steps,complete],sort_keys=True).encode()).hexdigest() if steps or complete else state["signature"]
  changed=sig!=state["signature"] or complete!=state["completed"]
  state.update({"signature":sig,"completed":complete})
  if new or changed:cursor.write_text(json.dumps(state,ensure_ascii=False,indent=2)+"\n")
  if changed:
   event={"observedAtUtc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"kind":"watch_completed" if complete else "stage_state_changed","steps":steps,"watchCompleted":complete,"offset":state["offset"]}
   if complete:event["watchReceipt"]=json.loads((b/"watch.result.json").read_text())
   with (b/"watch-state-events.jsonl").open("a") as f:f.write(json.dumps(event,ensure_ascii=False)+"\n")
   print(json.dumps(event,ensure_ascii=False));break
 if time.monotonic()>=deadline:
  print(json.dumps({"kind":"unchanged","waitedSeconds":round(time.monotonic()-start,2),"watchCompleted":state["completed"]}));break
 time.sleep(min(0.5,max(0,deadline-time.monotonic())))
