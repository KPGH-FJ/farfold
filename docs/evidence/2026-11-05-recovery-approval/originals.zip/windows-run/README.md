# Windows RecoveryApproval：41965725276 原始取证

固定源码 `cfd14b749d5e008359edc4901d3c6da00350f323`，attempt 1，唯一 selected job `127042164355`。原始 run/jobs 均 completed/success，job 用时16分20秒；唯一 watch 自然退出0，已关闭，未重派或重跑。记录链接：https://github.com/KPGH-FJ/farfold/actions/runs/41965725276 。此前派发输入/回执/stdout/stderr原件均保留。

实际执行：

- 四份 PowerShell Parser.ParseFile 均无错误，脚本SHA与本轮输入映射核合。
- Native --list 恰好2个原FQN；实际2 passed、0 failed、0 ignored，2474 filtered out，执行自然退出0。包括新重复ID拒绝及原始opaque参数保持用例。
- 前端 typecheck 与 Vitest 自然退出均0；固定4文件28/28，6+9+9+4，零skip/todo/fail。Node v22.22.3、pnpm9.15.0。
- List/Frontend/All 均绑定同一source/selection/input digest/test-binary/fixture哈希，All另绑定真实List回执；2312条**该CI声明输入**的原始before/after键与哈希完全一致。123项本地派生完整性断言全过，不能称为123个测试。
- 唯一 artifact `13388121703`，257448B，SHA256 `9a7a51347c687d028542fecafaaa53bc503e6aae35f7485b15e08064f9ff9364`，与服务digest/size及同run/head元数据核合。

先保存ZIP成员清单、总量、路径与symlink检查，再仅提取文本：artifact22成员1010207B，完整job-log ZIP17成员157859B；39份文本CRC读取及原始字节hash保留，0排除/不安全路径/链接。未提取或执行EXE/App/其他二进制。实际测试EXE仅在runner被哈希与执行；未上传EXE，故没有下载后本机独立重哈希证明。原ZIP字节仍保留于 artifact-original.stdout 与 logs-completed.stdout，它们是二进制ZIP容器，不是程序。

job原始15步success、14步按其他cohort范围skipped；逐项结论完整保留，不能把工作流skipped当作前端测试skip。没有该轮failed/cancelled步骤，不改写之前失败或取消记录。API/watch客户端退出0与Cargo build/libtest/前端命令的实际自然退出字段分别记录。

原始完整映射：raw/artifact/inputs-before.json、inputs-after.json；完整检查与摘要：checks.json、summary.json；ZIP安全与逐成员记录：*-zip-inventory.json、*-text-extraction.json；原始API与命令：*.stdout、*.stderr、*.result.json。manifest.json列出这些实际文件的size/SHA。所有日志/JSON按原字节保留，未作换行改写。

边界：只证明本固定源码的所选合成协议/前端路径及Windows工具链，不是当前源码完整Windows测试、安装/桌面/用户流程或真实Agent/账号/模型验收。Git blob与Windows CRLF等价、最终独立复核待主代理另做；本取证不代替它们。未运行本机Cargo、App、Agent或安装器。
