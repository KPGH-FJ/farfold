# Windows 当前源码安装与启动元数据冒烟：只读提案

结论：有条件可行，当前尚不具备直接派发的完整脚本依据。先完成当前共用缺陷与工程检查，再由主代理决定是否开展这一有限补验；本提案不新增阶段验收门槛。未安装、启动 App、执行 Agent、调用 GH/CI/网络，也未修改源码或工作流。

评估源码为 `4814cb75c49c4fbe47a0156bdea4b7f447898dc8`，功能基线为 `ea6c01a9d`。应用仍为 `ai.farfold.desktop` / `0.1.7`。完整输入字节指纹及原 P49/H18 条件见 `proposal.json`；这些是本次调查输入指纹，不是过去 CI 的逐文件源码映射。后续实现/派发应绑定届时实际固定源码，不能沿用旧 2e 安装器覆盖新代码。

## 已确认的启动行为

- `useAgents` 挂载后自动 `catalog_scan`（`src/runtime/agents.ts:793`）。后端先遍历继承 PATH、现有 USERPROFILE 下的 `.opencode/bin`、`.local/bin`、`.npm-global/bin`、nvm 目录，以及 APPDATA/npm、ProgramFiles/nodejs。发现 `opencode`、`codex`、`pi` 的可执行候选时可能真实执行 `--version`。因此“新 runner”本身不能证明不会启动 Agent。必须在启动前按同一发现规则只查文件、不执行候选，确认全部不存在；发现任何一个便停止该项，不删程序、不改 PATH/HOME、不放假程序。
- 同一自动扫描尝试 GET 官方 ACP registry，连接限 5 秒、请求限 20 秒，成功可写 `registry-cache.json`（`agent_catalog.rs:342,420`）。不能宣称启动零网络；这不是模型请求。整个 discover 也不能简单称硬 20 秒，因为已有单个版本探测可跨过开始前的总截止判断。
- `AcpManager::new` 创建空连接表与空闲回收线程；Windows `supervisor::startup_cleanup` 是空函数。正常新资料下 Agent、cwd 初始均为空，准备还需显式 intent 等条件；所读路径未发现自动连接或 prompt。这是受“资料原先不存在、无用户操作、无可发现 Agent”约束的静态结论，不是运行时零调用证明。
- 启动创建 SQLite schema、恢复 Farfold 自有草稿/准备元数据；Windows 通知 initialize 无操作，`credential_list` 只读元数据。禁止为了证明启动而调用密钥读取、认证、API 测试或任何真实 Agent。新资料应没有 agents/sessions/credential 记录；settings 可能合法初始化，不能武断要求全部零行。
- WM_CLOSE 会经正常关闭处理；renderer 已 ready 时经 save-before-exit、flush 和 `app_exit_after_save`。未 ready 时后端也可能正常退出，因此自然 exit 0 与窗口出现都不能单独证明前端就绪或保存桥验收。不得用私有 helper 参数/IPC/ready-private-exit 绕过；超时后的自有 Job 清理必须另记 forced，不能写成自然退出。

## 执行前仍须补齐的具体条件

1. 当前 Windows 配置是 NSIS `currentUser`，WebView2 为 `downloadBootstrapper` 且 `silent:false`，语言选择器为 true。本机仅有 CLI 2.11.4 的 schema，无可读 bundler NSIS 模板或生成 `.nsi`；`/S`、`/D`、是否默认安装后启动、卸载参数与保留资料语义一律尚未核实。后续先读同版本官方/生成模板并保存指纹，再写准确参数；不能凭 NSIS 常识派发。
2. 在新 hosted runner 的**现有正常用户资料**下，确认 Farfold 安装目录、精确 HKCU 登记/快捷方式、`RoamingAppData/ai.farfold.desktop` 与 `LocalAppData/ai.farfold.desktop`、任何既有 Farfold 实例均不存在；发现旧物或重解析点便停止，不能覆盖。Tauri 默认数据库位于前者 `farfold.sqlite3`，后者包含日志及默认 WebView 数据。只核对应对象，不遍历或导出其他用户资料、注册表或环境秘密。
3. 用官方 WebView2 loader/version 查询确认该 runner 用户已有可用运行时并记实际版本；注册表存在不是完整可用证明。缺失则该项缺条件，不在本轮安装/更新 WebView2。当前配置可能弹依赖安装窗；release 运行时缺失也可能弹错误窗，不能靠点击或强杀把它变成通过。
4. 先确认 runner 可创建嵌套 Job、保留原始进程句柄与枚举其顶层窗口。若无法在执行任何 App 代码之前纳入自有 Job，则阻断，不退化为“先启动后按 PID 追杀”。保持继承环境，禁止 private HOME、env_clear、新 QA/env 标志；发现无法解释的 WebView2 环境覆盖先停，不静默改值。

## 建议的最小实现边界（未实现）

可以在现有 `windows.yml` installer 作业构建当前固定源码的 NSIS 后追加独立命名的安装冒烟步骤，避免新建测试 cohort、重复完整编译或增加产品开关。保留 Rust 90 分钟现值，不扩大它。现有所选测试脚本可复用“源码前后指纹、实际命令、独立退出/错误、原件上传”的方式，不能直接拿 lib-test binary 的回执代替 release App。具体工作流和脚本须主代理另定后实施。

顺序建议：源码/构建产物归属 → 新资料与候选程序前检 → 当前 NSIS 静默安装至经模板确认的唯一自有路径 → 核安装后主 EXE 与同构建打包主 EXE 的字节对应、HKCU/快捷方式精确差异 → 不带参数启动正式入口 → 记录原始句柄、创建时间、实际镜像、Job 归属和进程退出 → 按关联 PID 枚举可见、正尺寸顶层窗口的 HWND/类/矩形等元数据 → 正常 WM_CLOSE → 退出后只读 SQLite schema、quick_check、空 Agent/对话/凭据计数 → 卸载本次安装并核登记/二进制移除。

CI 侧可用 Win32 CreateProcess suspended→AssignProcessToJob→ResumeThread，保留 Job 与原始进程句柄至清理结束。此方式尚未在 runner 测过；WebView2 与 runner 嵌套 Job 不兼容应原样报告。现有 `windows_process.rs` 私有入口面向 stdio/PTY/Git 子程序，不能作为 App 就绪接口或用来改写产品启动。窗口只在同一仍存活进程身份下关联；不读页面、窗口正文、剪贴板或屏幕，不模拟点击、焦点/按键。遇到 Job 外/归属未知的进程不按名称或数值 PID 扫杀，不冒称清理完成。

建议初始有限预算：安装 180 秒；窗口创建 60 秒；启动后元数据观察 30 秒；正常关闭 30 秒；仅自有 Job 强制清理 15 秒；卸载 120 秒；步骤总限 10 分钟。这些是未实测的 CI 控制预算，不是产品性能承诺，也不放宽生产期限、退出证明或旧断言。普通退出失败即保留失败；允许的强制回收只负责 CI 自有进程。卸载器必须先确认不删除应用资料；不显式删除任何用户资料/凭据。新建的空 Farfold 资料可随临时 runner 生命周期保留，不能把整个 profile 删除称作卸载。记录残留与清理结果，不隐去原始失败。

## 可证明与仍未证明

若实际执行成功，可新增“该固定源码的安装器在该 Windows runner 当前用户下实际安装、所安装主程序确实启动、关联顶层窗口元数据出现、正常退出/自有清理各自结果、初始 Farfold 元数据”的原始证据。每段命令、进程退出、元数据与 hash 独立记录，API/下载退出 0 不当作 App 退出 0。

仍不能证明 WebView2 页面内容/渲染、界面布局与交互、文件/浏览器/通知用户流程、凭据与真实 Agent/模型、终端、失败恢复、UNC/重解析路径、跨版本资料保持、签名分发或完整 Windows 验收。P49/H18 的原始条件和已有用户流程缺口继续开放。旧 2e run 41931045918 仍仅是完整工程成功及 unsigned NSIS 构建/下载摘要；当前提案没有升级那次结果，也不触碰正式 Mac 应用。
