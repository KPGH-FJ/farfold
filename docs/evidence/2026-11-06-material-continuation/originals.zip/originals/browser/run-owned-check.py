"""Record an explicit command and declared input endpoints; no environment overrides."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path('/Users/tw/Desktop/farfold')
BASE = Path(__file__).parent
phase, *argv = sys.argv[1:]
assert phase and '/' not in phase and argv
INPUTS = ["src/runtime/browser_tabs.ts", "src/runtime/browser_tabs.test.ts", "src/runtime/browser_workspace.ts", "src/runtime/browser_surface.ts", "src/components/BrowserWorkspace.tsx", "src/components/BrowserWorkspacePage.tsx", "src-tauri/src/browser_workspace/tab_commands.rs", "src-tauri/src/browser_workspace/page_store.rs", "src-tauri/tauri.conf.json", "src-tauri/Cargo.lock", "package.json", "pnpm-lock.yaml", "vitest.config.ts"]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs():
    return {name: digest(ROOT / name) for name in INPUTS}

def write(path, data):
    with path.open('xb') as stream:
        stream.write(data)
    path.chmod(0o600)

before = inputs()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
result = subprocess.run(argv, cwd=ROOT, capture_output=True)
finished = datetime.datetime.now(datetime.timezone.utc).isoformat()
after = inputs()
streams = {}
for name, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
    path = BASE / f'{phase}-{name}.log'
    write(path, data)
    streams[name] = {'path': str(path.relative_to(ROOT)), 'sha256': digest(path)}
receipt = {
    'command': argv, 'cwd': str(ROOT), 'startedAtUtc': started,
    'finishedAtUtc': finished, 'durationSeconds': time.monotonic() - tick,
    'naturalExitCode': result.returncode, 'inputsBefore': before,
    'inputsAfter': after, 'inputsEqual': before == after,
    'inputBoundary': 'Declared affected source/test/config inputs, not complete transitive graph',
    **streams,
}
path = BASE / f'{phase}-result.json'
write(path, (json.dumps(receipt, indent=2) + '\n').encode())
summary = {'phase': phase, 'naturalExitCode': result.returncode, 'inputsEqual': before == after}
report = BASE / f'{phase}-report.json'
if report.exists():
    report.chmod(0o600)
    value = json.loads(report.read_text())
    summary.update(passed=value['numPassedTests'], failed=value['numFailedTests'], pending=value['numPendingTests'])
    summary['failures'] = [
        {'name': test['fullName'], 'messages': test['failureMessages']}
        for suite in value['testResults'] for test in suite['assertionResults']
        if test['status'] == 'failed'
    ]
print(json.dumps(summary, ensure_ascii=False))
sys.exit(result.returncode)
