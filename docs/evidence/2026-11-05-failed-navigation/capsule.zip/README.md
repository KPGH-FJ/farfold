# Cached failed-conversation navigation: 755 static evidence

Prepared text capsule only. Root is executing a separate formal delivery interval; no formal directory, AppData, manifest, database, backup, raw UI or current user content is read or copied here. Installation and installed UI are not claimed.

755 adds one nine-line App.openRow guard: returning to an exactly matching cached failed owner only displays the original work/error. Explicit reconnect and uncached/different-owner paths remain. The existing browser hide barrier still precedes navigation.

The first mixed attempt is preserved and classified: its first case observed product session_open, while later resetHarness pollution was a harness defect. It is not the sealed product RED. With unchanged original App and the sealed c93 fixture, clean RED is7pass/6fail/natural1; same bytes then GREEN13/natural0. The associated13files140 tests include those13 and are not added as another13. The actual code independent reader is afcf1c78...16d8e,0mustfix. Tests use controlled App hooks/delegated production controller/mocked Tauri IPC; not installed GUI/full IPC or actual Agents.

The new engineering interval actually ran four frontend commands, all natural0, with715files9576. Rust3 were explicitly reused from source559/2364pass7ignored because835 declared src-tauri inputs were unchanged; this is not seven fresh commands. Source checkpoint is755568a83cffeb24ae2beea9a4e2111e4b34a713.

2385 are declared inputs, not all transitive inputs. The identical before/after map is stored once, with both source hashes. The independent2ab39f06...6c768c reader separately closes11 omitted test fixtures via fixed559 Git/current bytes+mode and the original whole-tracked status; original11 before/after were not captured and are not fabricated. Official locked local Tauri source/archive evidence establishes ordinary noncustom-protocol Cargo/devUrl does not read dist. A separate actual Release/App build remains necessary and is not claimed by these checks.

Only allowlisted UTF-8 text is archived. Necessary original command receipts/logs, patch, source pins, clean/mixed results and actual independent readers are included. Static local repository/cargo-cache prefixes or ANSI presentation escapes are removed only where recorded; transformed public copies pin original SHA and do not claim original byte identity. Source files and original receipts remain unchanged. No binary archive is embedded; no exe/dll/App/helper payload or private-user data is included.

`summary.json` states exact scope. `text-allowlist.json` pins every admitted source/copy/transformation; `safety-review.json` records strict UTF-8/NUL/control/secret checks. `capsule.zip` contains only approved text; `manifest.json` provides all member hashes/CRCs. No later formal result is awaited to finish this static package; Root may add a separate actual formal summary reference when ready. Product151/29x8 and all existing real-send constraints remain.
