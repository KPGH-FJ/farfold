import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["runtime/*.test.ts", "components/*.test.tsx"],
    environment: "node",
  },
});
